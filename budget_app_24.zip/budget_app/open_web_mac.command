#!/bin/bash
cd "$(dirname "$0")"
echo ""
echo "  Starting Budget App... your browser will open automatically."
echo "  To stop: press Ctrl+C"
echo ""
python3 run_web.py
