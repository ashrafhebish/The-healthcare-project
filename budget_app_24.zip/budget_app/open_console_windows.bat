@echo off
cd /d "%~dp0"
title Budget App - Console
if not exist "main.py" (
  echo.
  echo   ERROR: main.py not found next to this file.
  echo   Put this .bat inside the budget_app folder.
  echo.
  pause
  exit /b
)
python main.py
if errorlevel 9009 py main.py
pause
