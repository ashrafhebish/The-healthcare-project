"""
test_analysis.py
----------------
تستات لخط التحليل الإحصائي (12 مرحلة) ولدوال الاستدلال.

الفكرة: مش بنتأكد إن الكود بيشتغل من غير ما يقع — بنتأكد إن الأرقام
اللي بيطلعها **صح**، بمقارنتها بقيم من جداول إحصائية معروفة وبأمثلة
نعرف إجابتها بالورقة والقلم.

التشغيل:
    python -m unittest discover -s tests -v
"""

import math
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.analysis import (
    NotEnoughRowsError,
    phase1_prepare,
    phase2_descriptive,
    phase3_distribution,
    phase4_linear_algebra,
    phase5_probability,
    phase6_sampling,
    phase7_confidence,
    phase8_hypothesis,
    phase9_anova,
    phase10_calculus,
    quantile,
    run_pipeline,
)
from app.inference import (
    confidence_interval,
    f_p_value,
    incomplete_beta,
    kurtosis,
    linear_regression,
    one_sample_t_test,
    one_way_anova,
    quadratic_fit,
    skewness,
    solve_linear_system,
    t_critical,
    t_two_tailed_p,
)


def sample_rows(count: int = 90) -> list[dict]:
    """
    بيانات ثابتة (مش عشوائية) عشان التستات تدي نفس النتيجة كل مرة.
    التوفير أكبر من الاحتياجات أكبر من الكماليات — عشان ANOVA يلاقي فرق.
    """
    rows: list[dict] = []
    base = {"needs": 200.0, "wants": 90.0, "savings": 1000.0}

    for index in range(count):
        day = (index % 28) + 1
        category = ["needs", "wants", "savings"][index % 3]
        rows.append(
            {
                "date": f"2026-05-{day:02d}",
                "category": category,
                "amount": base[category] + (index % 7) * 10,
                "description": f"بند {index}",
            }
        )
    return rows


# ==================================================================
# 1) دوال الاستدلال مقابل الجداول الإحصائية
# ==================================================================
class TestInferenceMath(unittest.TestCase):
    """أهم تستات في الملف: الأرقام دي لازم تطابق أي جدول إحصاء."""

    def test_t_critical_matches_tables(self) -> None:
        # القيم دي من جدول t المعروف
        self.assertAlmostEqual(t_critical(10, 0.95), 2.228, places=2)
        self.assertAlmostEqual(t_critical(30, 0.95), 2.042, places=2)
        self.assertAlmostEqual(t_critical(120, 0.95), 1.980, places=2)
        # مع الأعداد الكبيرة t بتقرب من z = 1.96
        self.assertAlmostEqual(t_critical(100000, 0.95), 1.96, places=2)

    def test_t_p_value_known(self) -> None:
        """t = 2.5 مع df = 20 → p ≈ 0.0212"""
        self.assertAlmostEqual(t_two_tailed_p(2.5, 20), 0.0212, places=3)

    def test_t_symmetry(self) -> None:
        """توزيع t متماثل: نفس الـ p للقيمة وسالبها."""
        self.assertAlmostEqual(t_two_tailed_p(1.7, 15), t_two_tailed_p(-1.7, 15), places=10)

    def test_f_p_value_matches_tables(self) -> None:
        """F = 4.26 مع (2, 9) هي القيمة الحرجة عند 0.05 بالظبط."""
        self.assertAlmostEqual(f_p_value(4.26, 2, 9), 0.05, places=3)
        self.assertAlmostEqual(f_p_value(3.89, 3, 12), 0.0374, places=3)

    def test_incomplete_beta_bounds(self) -> None:
        self.assertEqual(incomplete_beta(2, 3, 0.0), 0.0)
        self.assertEqual(incomplete_beta(2, 3, 1.0), 1.0)
        # I_x(a,b) + I_(1-x)(b,a) = 1
        self.assertAlmostEqual(
            incomplete_beta(2, 5, 0.3) + incomplete_beta(5, 2, 0.7), 1.0, places=10
        )

    def test_regression_on_perfect_line(self) -> None:
        result = linear_regression([1, 2, 3, 4, 5], [3, 5, 7, 9, 11])
        self.assertAlmostEqual(result["slope"], 2.0, places=10)
        self.assertAlmostEqual(result["intercept"], 1.0, places=10)
        self.assertAlmostEqual(result["r_squared"], 1.0, places=10)

    def test_quadratic_recovers_known_curve(self) -> None:
        """y = 2x² + 3x + 1 — لازم يرجّع نفس المعاملات."""
        xs = [0, 1, 2, 3, 4, 5]
        ys = [2 * x * x + 3 * x + 1 for x in xs]
        result = quadratic_fit(xs, ys)

        self.assertAlmostEqual(result["a"], 2.0, places=6)
        self.assertAlmostEqual(result["b"], 3.0, places=6)
        self.assertAlmostEqual(result["c"], 1.0, places=6)

    def test_gaussian_elimination(self) -> None:
        """نظام معروف حله (x=2, y=3)."""
        solution = solve_linear_system([[1, 1, 5], [2, -1, 1]])
        self.assertAlmostEqual(solution[0], 2.0, places=9)
        self.assertAlmostEqual(solution[1], 3.0, places=9)

    def test_singular_system_returns_none(self) -> None:
        self.assertIsNone(solve_linear_system([[1, 1, 2], [2, 2, 4]]))

    def test_skewness_direction(self) -> None:
        self.assertAlmostEqual(skewness([1, 2, 3, 4, 5]), 0.0, places=9)   # متماثل
        self.assertGreater(skewness([1, 1, 1, 2, 10]), 1)                  # ذيل يمين
        self.assertLess(skewness([1, 9, 10, 10, 10]), -1)                  # ذيل شمال

    def test_kurtosis_of_uniform_is_negative(self) -> None:
        """التوزيع المنتظم ذيوله أخف من الطبيعي → تفلطح سالب."""
        self.assertLess(kurtosis(list(range(1, 51))), 0)


class TestStatisticalTests(unittest.TestCase):
    def test_t_test_detects_real_difference(self) -> None:
        values = [50.0] * 30
        values[0] = 51.0
        result = one_sample_t_test(values, 20)         # فرق ضخم
        self.assertTrue(result["reject_null"])
        self.assertLess(result["p_value"], 0.001)

    def test_t_test_accepts_when_no_difference(self) -> None:
        values = [10, 12, 9, 11, 10, 13, 8, 12, 11, 9]
        result = one_sample_t_test(values, 10.5)
        self.assertFalse(result["reject_null"])

    def test_anova_detects_group_difference(self) -> None:
        groups = {"أ": [5, 6, 7, 5, 6], "ب": [15, 16, 17, 15, 16], "ج": [5, 6, 5, 7, 6]}
        result = one_way_anova(groups)
        self.assertTrue(result["reject_null"])
        self.assertGreater(result["f_statistic"], 10)

    def test_anova_identical_groups(self) -> None:
        groups = {"أ": [5, 6, 7, 8], "ب": [5, 6, 7, 8], "ج": [5, 6, 7, 8]}
        result = one_way_anova(groups)
        self.assertAlmostEqual(result["f_statistic"], 0.0, places=6)
        self.assertFalse(result["reject_null"])

    def test_anova_needs_two_groups(self) -> None:
        self.assertIn("error", one_way_anova({"أ": [1, 2, 3]}))

    def test_confidence_interval_contains_mean(self) -> None:
        values = [10, 12, 14, 11, 13, 15, 9, 12]
        interval = confidence_interval(values)

        self.assertLess(interval["low"], interval["mean"])
        self.assertGreater(interval["high"], interval["mean"])
        # الفترة متماثلة حوالين المتوسط
        self.assertAlmostEqual(
            interval["mean"] - interval["low"], interval["high"] - interval["mean"], places=9
        )

    def test_bigger_sample_narrows_interval(self) -> None:
        """كل ما n كبرت، الفترة ضاقت — لأن SE = σ/√n"""
        small = confidence_interval([10, 20, 30, 40] * 3)
        large = confidence_interval([10, 20, 30, 40] * 30)
        self.assertLess(large["margin"], small["margin"])


# ==================================================================
# 2) مراحل التحليل
# ==================================================================
class TestPhase1Cleaning(unittest.TestCase):
    def test_removes_every_kind_of_bad_row(self) -> None:
        rows = sample_rows(40)
        rows.append({"date": "", "category": "needs", "amount": 100})          # ناقص
        rows.append({"date": "2026-05-01", "category": "needs", "amount": -5})  # سالب
        rows.append({"date": "2026-05-01", "category": "needs", "amount": "س"}) # مش رقم
        rows.append({"date": "2026-05-01", "category": "طيران", "amount": 50})  # تصنيف مجهول
        rows.append(dict(rows[0]))                                             # مكرر

        dataset, summary = phase1_prepare(rows)

        self.assertEqual(summary["dropped_detail"]["missing"], 1)
        self.assertEqual(summary["dropped_detail"]["invalid_amount"], 2)
        self.assertEqual(summary["dropped_detail"]["unknown_category"], 1)
        self.assertEqual(summary["dropped_detail"]["duplicate"], 1)
        self.assertEqual(len(dataset), 40)

    def test_raises_on_tiny_dataset(self) -> None:
        with self.assertRaises(NotEnoughRowsError):
            phase1_prepare(sample_rows(5))

    def test_identifies_variable_types(self) -> None:
        _, summary = phase1_prepare(sample_rows())
        self.assertTrue(summary["variables"]["numerical"])
        self.assertTrue(summary["variables"]["categorical"])


class TestPhase2Descriptive(unittest.TestCase):
    def test_known_values(self) -> None:
        """بيانات إجابتها معروفة بالورقة والقلم."""
        rows = [
            {"date": f"2026-05-{index + 1:02d}", "category": "needs", "amount": value, "description": ""}
            for index, value in enumerate([2, 4, 4, 4, 5, 5, 7, 9, 6, 6, 8, 3])
        ]
        dataset, _ = phase1_prepare(rows)
        result = phase2_descriptive(dataset)

        self.assertAlmostEqual(result["mean"], 5.25, places=2)
        self.assertEqual(result["min"], 2)
        self.assertEqual(result["max"], 9)
        self.assertEqual(result["range"], 7)

    def test_quantile_matches_manual(self) -> None:
        values = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        self.assertAlmostEqual(quantile(values, 50), 5.5, places=9)
        self.assertAlmostEqual(quantile(values, 25), 3.25, places=9)
        self.assertAlmostEqual(quantile(values, 75), 7.75, places=9)

    def test_iqr_equals_q3_minus_q1(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        result = phase2_descriptive(dataset)
        self.assertAlmostEqual(result["iqr"], result["q3"] - result["q1"], places=2)

    def test_variance_is_std_squared(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        result = phase2_descriptive(dataset)
        self.assertAlmostEqual(math.sqrt(result["variance"]), result["std"], places=1)


class TestPhase3Distribution(unittest.TestCase):
    def test_frequencies_add_up(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        result = phase3_distribution(dataset)

        total = sum(bin_data["count"] for bin_data in result["frequency"])
        self.assertEqual(total, len(dataset))
        self.assertAlmostEqual(result["frequency"][-1]["cumulative_percent"], 100.0, places=1)

    def test_box_plot_order(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        box = phase3_distribution(dataset)["box_plot"]
        self.assertLessEqual(box["q1"], box["median"])
        self.assertLessEqual(box["median"], box["q3"])

    def test_detects_planted_outlier(self) -> None:
        rows = sample_rows(60)
        rows.append(
            {"date": "2026-05-15", "category": "needs", "amount": 99999, "description": "شاذ"}
        )
        dataset, _ = phase1_prepare(rows)
        result = phase3_distribution(dataset)

        self.assertGreaterEqual(result["outliers_count"], 1)
        self.assertIn(99999, [item["amount"] for item in result["outliers"]])


class TestPhase4LinearAlgebra(unittest.TestCase):
    def test_dot_product_is_correct(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        result = phase4_linear_algebra(dataset, 15000)

        manual = sum(
            spend * weight
            for spend, weight in zip(result["spend_vector"], result["weight_vector"])
        )
        self.assertAlmostEqual(result["dot_product"], manual, places=1)

    def test_scalar_multiplication(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        result = phase4_linear_algebra(dataset)

        for original, scaled in zip(result["spend_vector"], result["scaled_vector"]):
            self.assertAlmostEqual(scaled, original * 1.1, places=1)

    def test_matrix_totals(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        matrix = phase4_linear_algebra(dataset)["matrix"]

        # مجموع مجاميع الصفوف = مجموع مجاميع الأعمدة
        self.assertAlmostEqual(sum(matrix["row_totals"]), sum(matrix["column_totals"]), places=1)

    def test_angle_is_valid(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        angle = phase4_linear_algebra(dataset, 15000)["alignment"]["angle_degrees"]
        self.assertGreaterEqual(angle, 0)
        self.assertLessEqual(angle, 180)


class TestPhase5Probability(unittest.TestCase):
    def test_probabilities_in_range(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        result = phase5_probability(dataset)

        for item in result["simple"] + result["conditional"]:
            self.assertGreaterEqual(item["probability"], 0.0)
            self.assertLessEqual(item["probability"], 1.0)

    def test_expected_value_equals_overall_mean(self) -> None:
        """
        E(X) = Σ P(فئة) × متوسط الفئة — ولازم تساوي المتوسط العام.
        دي خاصية رياضية، لو اتكسرت يبقى فيه غلط في الحساب.
        """
        dataset, _ = phase1_prepare(sample_rows())
        expected = phase5_probability(dataset)["expected_value"]["per_expense"]
        overall = phase2_descriptive(dataset)["mean"]
        self.assertAlmostEqual(expected, overall, places=1)


class TestPhase6Sampling(unittest.TestCase):
    def test_sample_smaller_than_population(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        result = phase6_sampling(dataset)
        self.assertLess(result["sample"]["n"], result["population"]["n"])

    def test_observed_se_close_to_theory(self) -> None:
        """الخطأ المعياري الفعلي لازم يقرب من σ/√n — ده جوهر الـ CLT."""
        dataset, _ = phase1_prepare(sample_rows(120))
        distribution = phase6_sampling(dataset)["sampling_distribution"]

        observed = distribution["observed_se"]
        theoretical = distribution["theoretical_se"]
        self.assertLess(abs(observed - theoretical), theoretical * 0.35)

    def test_deterministic_with_same_seed(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        first = phase6_sampling(dataset, seed=3)["sample"]["mean"]
        second = phase6_sampling(dataset, seed=3)["sample"]["mean"]
        self.assertEqual(first, second)


class TestPhase7Confidence(unittest.TestCase):
    def test_interval_brackets_the_mean(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        result = phase7_confidence(dataset)["expense_mean"]

        self.assertLess(result["low"], result["mean"])
        self.assertGreater(result["high"], result["mean"])

    def test_margin_equals_t_times_se(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        result = phase7_confidence(dataset)["expense_mean"]
        self.assertAlmostEqual(
            result["margin"], result["t_critical"] * result["standard_error"], places=1
        )


class TestPhase8And9(unittest.TestCase):
    def test_hypothesis_has_all_required_parts(self) -> None:
        """المطلوب في المشروع: H₀ و H₁ و α و الإحصائية و p و القرار."""
        dataset, _ = phase1_prepare(sample_rows())
        result = phase8_hypothesis(dataset)

        for key in ("h0", "h1", "alpha", "t_statistic", "p_value", "decision", "conclusion"):
            self.assertIn(key, result)

    def test_rejects_absurd_reference(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        result = phase8_hypothesis(dataset, claimed_mean=1)
        self.assertTrue(result["reject_null"])

    def test_anova_has_all_required_parts(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        result = phase9_anova(dataset)

        for key in ("h0", "h1", "f_statistic", "p_value", "decision", "conclusion"):
            self.assertIn(key, result)

    def test_anova_finds_the_planted_difference(self) -> None:
        """في بيانات التست التوفير أكبر بكتير من الكماليات — لازم يتاخد بالها."""
        dataset, _ = phase1_prepare(sample_rows())
        result = phase9_anova(dataset)
        self.assertTrue(result["reject_null"])

    def test_anova_sums_add_up(self) -> None:
        """SS الكلي = SS بين + SS داخل"""
        dataset, _ = phase1_prepare(sample_rows())
        result = phase9_anova(dataset)

        values = dataset.amounts
        grand = sum(values) / len(values)
        ss_total = sum((value - grand) ** 2 for value in values)

        self.assertAlmostEqual(
            result["table"]["between"]["ss"] + result["table"]["within"]["ss"],
            ss_total,
            delta=ss_total * 0.001,
        )


class TestPhase10Calculus(unittest.TestCase):
    def test_cumulative_is_increasing(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        points = phase10_calculus(dataset)["points"]

        for previous, current in zip(points, points[1:]):
            self.assertGreaterEqual(current["s"], previous["s"])

    def test_slope_is_positive(self) -> None:
        dataset, _ = phase1_prepare(sample_rows())
        result = phase10_calculus(dataset)
        self.assertGreater(result["linear"]["slope"], 0)

    def test_uses_single_month_only(self) -> None:
        """
        لو حسبنا التراكمي على كذا شهر مع بعض، الميل بيطلع غلط.
        التست ده بيتأكد إن التحليل بياخد شهر واحد بس.
        """
        rows = sample_rows(60) + [
            {"date": f"2026-06-{(index % 28) + 1:02d}", "category": "needs",
             "amount": 100.0, "description": ""}
            for index in range(40)
        ]
        dataset, _ = phase1_prepare(rows)
        result = phase10_calculus(dataset)

        self.assertIn(result["month"], ("2026-05", "2026-06"))
        self.assertLessEqual(result["days"], 31)


# ==================================================================
# 3) الخط كامل
# ==================================================================
class TestFullPipeline(unittest.TestCase):
    def test_all_twelve_phases_present(self) -> None:
        result = run_pipeline(sample_rows(120), income=15000)

        for number in range(1, 13):
            key = f"phase{number}"
            self.assertIn(key, result, f"{key} ناقصة")
            self.assertNotIn("error", result[key], f"{key} وقعت")

    def test_every_phase_has_interpretation(self) -> None:
        """المطلوب مش أرقام بس — كل مرحلة لازم تفسّر نتيجتها."""
        result = run_pipeline(sample_rows(120), income=15000)

        for number in range(1, 12):
            phase = result[f"phase{number}"]
            text = phase.get("interpretation") or phase.get("conclusion") or ""
            self.assertGreater(len(text), 40, f"phase{number} من غير تفسير كافي")

    def test_pipeline_survives_dirty_data(self) -> None:
        rows = sample_rows(100)
        rows += [{"date": "", "category": "", "amount": None}] * 5
        rows += [{"date": "2026-05-05", "category": "needs", "amount": "غلط"}] * 3

        result = run_pipeline(rows, income=15000)
        self.assertEqual(result["rows"], 100)

    def test_conclusion_mentions_findings(self) -> None:
        result = run_pipeline(sample_rows(120), income=15000)
        final = result["phase12"]

        self.assertGreaterEqual(len(final["findings"]), 4)
        self.assertTrue(final["statistical_results"])
        self.assertTrue(final["improvements"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
