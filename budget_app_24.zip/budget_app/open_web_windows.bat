@echo off
cd /d "%~dp0"
title Budget App - Web
if not exist "run_web.py" (
  echo.
  echo   ERROR: run_web.py not found next to this file.
  echo   Put this .bat inside the budget_app folder ^(the one with main.py^).
  echo.
  pause
  exit /b
)
echo.
echo   Starting Budget App... your browser will open automatically.
echo   To stop the server: close this window or press Ctrl+C
echo.
python run_web.py
if errorlevel 9009 py run_web.py
pause
