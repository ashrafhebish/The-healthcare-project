# توفير بذكاء — حاسبة الميزانية الشهرية

مشروع بايثون النهائي. البرنامج بياخد دخلك الشهري، يقسّمه تلقائي بقاعدة **50/30/20**
(احتياجات / كماليات / توفير)، وتقدر تسجّل مصاريفك الفعلية وتشوف **مقارنة حية**:
"المفروض تصرف كذا على الاحتياجات، أنت صرفت كذا لحد دلوقتي" — مع تحذير لما تقرب من
حد أي تصنيف، وتقرير آخر الشهر بيقولك التزمت بالخطة ولا لأ ووفّرت كام فعلياً.

للمشروع **واجهتين بتشتغلوا على نفس الكود**:

| الواجهة | التشغيل السريع (دبل كليك) | التشغيل من الترمينال |
|---|---|---|
| ويب — من غير أي تشغيل | **`index.html`** | — |
| ويب — بسيرفر بايثون | `open_web_windows.bat` / `open_web_mac.command` | `python run_web.py` |
| كونسول | `open_console_windows.bat` | `python main.py` |

**أسرع طريقة:** دبل كليك على `index.html` في جذر المشروع — البرنامج بيفتح
في المتصفح على طول من غير بايثون ولا تثبيت ولا انتظار.

الملف ده **شغال على الموبايل** كمان: تنزّله على التليفون وتفتحه من مدير
الملفات، أو ترفعه على أي استضافة ثابتة (GitHub Pages مثلاً) وتفتحه من
المتصفح — في الحالتين الحسابات كلها بتتعمل جوه المتصفح، فمش محتاج سيرفر. الجداول العريضة بتتزحلق باللمس، وتبويبات المراحل بتبقى شريط أفقي.

فيه **صفحتين** جاهزتين، كل واحدة ملف واحد مستقل:

| الملف | فيه إيه | مصدر البيانات |
|---|---|---|
| `index.html` | البرنامج كامل: الخطة + المصاريف + التقرير + التحليل + الـ 12 مرحلة | تكتب بإيدك |
| `analysis.html` | الـ 12 مرحلة على **أي داتاست** — بيكتشف الأعمدة لوحده | ترفع أي ملف CSV |

الاتنين متولّدين من `web/static/` بالسكريبت ده:

```bash
python tools/build_single_file.py
```

يعني تقدر تبعته لأي حد كمرفق واحد ويشتغل عنده. أي تعديل يتعمل في
`web/static/` الأول، وبعدين يتشغّل السكريبت تاني.

ملف الويب بيفتح المتصفح لوحده على `http://127.0.0.1:8000` — مش محتاج تكتب اللينك.

> واجهة الويب متبنية بمكتبات بايثون الأساسية بس (`http.server`) — **مفيش أي تثبيت مطلوب**.

---

## التشغيل

**أسهل طريقة:** دوس دبل كليك على `open_web_windows.bat` (ويندوز) أو `open_web_mac.command`
(ماك) — السيرفر هيقوم والمتصفح هيفتح لوحده.

```bash
# أو من الترمينال جوه فولدر المشروع
python run_web.py     # الويب
python main.py        # الكونسول
```

Pydantic اختيارية: لو متسطبة البرنامج بيستخدمها في التحقق من المدخلات، ولو مش متسطبة
بيشتغل عادي بتحقق يدوي.

```bash
pip install -r requirements.txt   # اختياري
```

---

## المميزات

- إدخال الدخل الشهري وتقسيمه تلقائي: **50/30/20** أو **60/20/20** أو **تقسيم مخصص**
- العمليات الستة على المصاريف: إضافة / حذف / تعديل / بحث / عرض / حساب المتبقي
- مقارنة حية بعد كل مصروف: الخطة مقابل الفعلي ونسبة الاستهلاك
- تحذير عند الوصول لـ 80٪ من أي تصنيف، وتنبيه أحمر عند تجاوز الخطة
- تقرير آخر الشهر: الالتزام بالخطة + التوفير الفعلي + أكبر المصاريف
- حفظ تلقائي في JSON + تصدير واستيراد CSV
- تسجيل كل العمليات في `logs/app.log`
- تحليل إحصائي: توقّع آخر الشهر، كشف المصاريف الشاذة، وإيقاع الصرف
- تحليل إحصائي شامل بـ 12 مرحلة (من تنظيف البيانات لحد ANOVA والتفاضل)
- الصفحة بتشتغل بالدبل كليك من غير سيرفر

---

## هيكل المشروع

```
budget_app/
├── index.html               # ← البرنامج كامل (ملف واحد مستقل، متولّد)
├── analysis.html            # ← الـ 12 مرحلة على أي داتاست (ملف واحد مستقل)
├── main.py                  # تشغيل واجهة الكونسول
├── run_web.py               # تشغيل واجهة الويب
├── requirements.txt
├── app/                     # قلب المشروع (Modules)
│   ├── config.py            # الثوابت + المسارات (pathlib) + الألوان
│   ├── exceptions.py        # Custom Exception Classes
│   ├── models.py            # Expense (dataclass) + MonthlyBudget + Pydantic
│   ├── budget_manager.py    # BudgetManager: الـ 6 عمليات + الحسابات والتحذيرات
│   ├── storage.py           # JSON + CSV
│   ├── reports.py           # بناء التقرير وعرضه
│   ├── stats_engine.py      # التوزيعات الاحتمالية على مصاريفك (تطبيق)
│   ├── inference.py         # توزيع t و F و p-value والانحدار (من غير SciPy)
│   ├── analysis.py          # خط التحليل الإحصائي — 12 مرحلة
│   ├── charts.py            # رسومات matplotlib (اختيارية)
│   ├── console_ui.py        # القائمة الملوّنة
│   └── logger_setup.py      # Logging
├── web/
│   ├── server.py            # سيرفر + API
│   └── static/              # index.html + style.css + app.js
│                            #   + offline*.js (تشغيل من غير سيرفر)
├── tests/
│   └── test_analysis.py     # 51 تست للمراحل ودوال الاستدلال
├── tools/
│   ├── make_dataset.py      # توليد داتاست تجربة (6 شهور)
│   ├── build_offline_data.py # تصدير إعدادات بايثون لنسخة المتصفح
│   └── build_single_file.py  # دمج كل حاجة في index.html واحد
├── data/                    # budget_data.json + expenses.csv
└── logs/                    # app.log
```

---

## الجزء الإحصائي (التوزيعات الاحتمالية)

المشروع بيتعامل مع مصاريفك كـ **متغيّر عشوائي**، مش أرقام ثابتة. وده بيتقسم لطبقتين:

### `stats_engine.py` — التطبيق

| السؤال | التوزيع المستخدم |
|---|---|
| المصروف ده طبيعي ولا شاذ؟ | الطبيعي + Z-score + قاعدة 68–95–99.7 |
| هخلّص الشهر على كام؟ واحتمال أعدّي دخلي؟ | مونت كارلو + CLT |
| بصرف كام مرة في اليوم؟ | بواسون |
| فاضل قد إيه على الصرفة الجاية؟ | الأسّي |
| احتمال ألتزم بالخطة الشهور الجاية؟ | ذات الحدين + بيتا |
| كام شهر لحد أول مرة أخرج عن الخطة؟ | الهندسي |

---

## التحليل الإحصائي الشامل — 12 مرحلة

`app/analysis.py` بينفّذ خط تحليل كامل على بيانات المصاريف، كل مرحلة
بترجّع أرقامها **وتفسيرها بالعربي**:

| # | المرحلة | إيه اللي بيتحسب |
|---|---|---|
| 1 | جمع البيانات وتجهيزها | تحديد المتغيرات الرقمية والفئوية، وتنظيف الناقص والمكرر والمبالغ الغلط |
| 2 | الإحصاء الوصفي | المتوسط، الوسيط، المنوال، المدى، التباين، الانحراف، الأرباع، IQR |
| 3 | تحليل التوزيع | التوزيع التكراري، الهيستوجرام، البوكس بلوت، الشواذ (قاعدة الربيعات)، الالتواء والتفلطح |
| 4 | الجبر الخطي | متجه الإنفاق، الضرب القياسي، حاصل الضرب النقطي، مصفوفة (شهور × تصنيفات)، الزاوية عن الخطة المثالية |
| 5 | الاحتمالات | احتمال بسيط، احتمال شرطي، اختبار الاستقلال، القيمة المتوقعة E(X) |
| 6 | المعاينة والاستدلال | المجتمع مقابل العيّنة، متوسط العيّنة، الخطأ المعياري، توزيع المعاينة |
| 7 | فترات الثقة | فترة 95٪ للمتوسط العام ولكل تصنيف، بـ t مش z |
| 8 | اختبار الفروض | اختبار t: H₀، H₁، α، الإحصائية، p-value، القرار، الاستنتاج |
| 9 | تحليل التباين | ANOVA أحادي: SS، df، MS، F، p-value، القرار |
| 10 | التفاضل | S(t) للإنفاق التراكمي، المشتقة الأولى (معدل الصرف)، الثانية (التسارع)، ومتى تستهلك دخلك |
| 11 | التصوّر البياني | عمود، هيستوجرام، بوكس بلوت، انتشار، خط — كل رسمة ومعاها سبب اختيارها |
| 12 | النتائج والخلاصة | تلخيص النتائج والعلاقات والقرارات + تطويرات مستقبلية |

### الرياضيات

كل حاجة متكتوبة بـ `math` بس — **من غير SciPy**:

- **دالة بيتا الناقصة** بالكسر المستمر (طريقة Lentz) → منها بيتحسب p-value لـ t و F
- **القيمة الحرجة t\*** ببحث ثنائي على 200 خطوة
- **الانحدار الخطي** بالمربعات الصغرى، و**المنحنى التربيعي** بحذف جاوس
- **الالتواء والتفلطح** من العزوم المركزية

الأرقام دي متحقق منها في التستات مقابل جداول الإحصاء المعروفة:
`t*(df=30) = 2.042` و `t*(df=10) = 2.228` و `F(4.26, 2, 9) = 0.05`.

### مصادر البيانات

```bash
python tools/make_dataset.py            # داتاست 6 شهور (فيها صفوف وسخة عن قصد)
python tools/make_dataset.py --months 12 --clean
```

التحليل بيشتغل على: مصاريف البرنامج نفسه، أو `data/dataset.csv`،
أو أي ملف CSV ترفعه من الواجهة (أعمدة: `date, category, amount, description`).

---

## تشغيل الصفحة من غير سيرفر

دبل كليك على **`index.html`** اللي في جذر المشروع (بيوديك على
`web/static/index.html`). في الحالة دي `offline.js` و `offline-analysis.js`
بيقوموا بدور بايثون جوه المتصفح: نفس المعادلات ونفس أسماء الحقول،
والبيانات بتتحفظ على جهازك وبتفضل بعد ما تقفل الصفحة.

الاتنين شغالين ومتحقق منهم: **كل أرقام الـ 12 مرحلة متطابقة بين
بايثون والمتصفح** على نفس الداتاست.

| | دبل كليك على index.html | `python run_web.py` |
|---|---|---|
| الميزانية والمصاريف | ✔ | ✔ |
| التحليل الإحصائي (توقعات وشذوذ) | ✔ | ✔ |
| الـ 12 مرحلة | ✔ (ارفع CSV أو استخدم مصاريفك) | ✔ |
| تصدير CSV | ✔ (بينزّل من المتصفح) | ✔ |
| حفظ في `data/*.json` | ✖ (بيتحفظ في المتصفح) | ✔ |
| تقارير شهور متعددة | ✖ | ✔ |
| رسومات matplotlib | ✖ | ✔ |
| قراءة `data/dataset.csv` تلقائي | ✖ (المتصفح بيمنع قراءة الملفات) | ✔ |

> نسخة بايثون هي الأصل دايماً. أي تعديل في المعادلات يتعمل في
> `app/` الأول، وبعدين يتنقل لملفات `offline*.js`.

---

## التستات

```bash
python -m unittest discover -s tests -v
```

٥١ تست بتتأكد إن الأرقام **صح**، مش إن الكود بيشتغل وبس:

- القيم الحرجة لـ t و F مطابقة للجداول الإحصائية
- الانحدار بيرجّع معاملات منحنى معروف (y = 2x² + 3x + 1) بالظبط
- E(X) المحسوبة من الاحتمالات = المتوسط العام (خاصية رياضية لازم تتحقق)
- SS الكلي = SS بين + SS داخل في ANOVA
- كل ما حجم العيّنة كبر، فترة الثقة ضاقت
- التنظيف بيمسك كل نوع صف وسخ، والتفاضل بياخد شهر واحد بس

---

## جدول تغطية المطلوب (للتسليم)

### General Requirements

| المطلوب | فين موجود |
|---|---|
| Variables / Data Types / Operators | `config.py`, `budget_manager.py` |
| Strings | `reports.py` (تنسيق التقرير)، `BudgetManager.search()` |
| Lists | `MonthlyBudget.expenses` في `models.py` |
| Dictionaries | `SPLIT_MODES`, `spent_by_category()` |
| Tuples | `CSV_HEADERS`, `CATEGORIES` في `config.py`، `validate_expense_data()` |
| Sets | `VALID_CATEGORIES` في `config.py` |
| if / elif / else | `MonthlyBudget.set_mode()`, `reports._status_of()` |
| for loop | `BudgetManager.spent_by_category()` |
| while loop | `console_ui.ask_number()`, `run_console()` |
| break | `MonthlyBudget.remove_expense()`, `run_console()` |
| continue | `console_ui.ask_number()`, `storage.import_expenses_csv()` |
| Functions + Parameters + Return | كل الملفات |
| Type Hints | كل الدوال والـ attributes |
| Classes / Objects / Attributes / Methods / self | `models.py`, `budget_manager.py` |
| `__init__()` | `MonthlyBudget`, `BudgetManager` |
| `__repr__()` | `Expense`, `MonthlyBudget`, `BudgetManager`, `BudgetError` |
| try / except / finally | `storage.py`, `console_ui.run_console()`, `web/server.py` |
| Reading / Writing Files | `storage.load_json()` / `save_json()` |
| JSON Files | `storage.py` |
| List Comprehension | `reports.build_report()`, `models.to_dict()` |
| lambda | `BudgetManager.total_spent()`, `top_expenses()` |
| sorted() | `BudgetManager.top_expenses()`, `months_list()` |
| enumerate() | `console_ui.show_menu()`, `reports.format_report_text()` |
| Modules / أكتر من ملف | 11 ملف جوه `app/` + `web/` + `tests/` |
| Unit Testing | `tests/test_analysis.py` (51 تست) |

### Bonus Features

| البونص | فين موجود |
|---|---|
| Dataclass | `Expense` في `models.py` |
| Pydantic | `ExpenseInput` في `models.py` |
| map() | `BudgetManager.total_spent()` |
| filter() | `BudgetManager.expenses_of()` |
| zip() | `BudgetManager.remaining_by_category()`, `reports.build_report()` |
| reduce() | `BudgetManager.total_spent()` |
| pathlib | `config.py`, `storage.py`, `web/server.py` |
| CSV Support | `storage.export_expenses_csv()` / `import_expenses_csv()` |
| Custom Exception Classes | `exceptions.py` (6 كلاسات) |
| Professional Console Menu | `console_ui.py` |
| Colored Console Output | `config.Color` + `paint()` |
| Logging | `logger_setup.py` → `logs/app.log` |
| NumPy (اختيارية) | `stats_engine.py` مع fallback بالبايثون الأساسية |
| Matplotlib (اختيارية) | `charts.py` — ٦ رسومات للتقرير |
| Probability Distributions | `stats_engine.py` (٩ توزيعات) |
| Statistical Inference | `inference.py` — t, F, ANOVA, CI |
| 12-Phase Analysis Pipeline | `analysis.py` |
| GitHub Repository + Multiple Commits | شوف `COMMITS_GUIDE.md` |

---

## ملاحظة عن التصميم

واجهة الويب معمولة بنفس هوية التصميم المطلوب: كحلي غامق `#071827` مع ذهبي `#d4a24c`
وخلفية كريمي `#f5f1e9`، خطوط Cairo و Tajawal، واتجاه RTL. العنصر المميز في الصفحة
هو **شريط الالتزام** لكل تصنيف: بيتملّي بالذهبي وهو تمام، أصفر لما تقرب من الحد،
وأحمر لما تتخطى الخطة.
