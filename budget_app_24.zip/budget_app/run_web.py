"""
run_web.py
----------
نقطة تشغيل واجهة الويب — بتشغّل السيرفر وتفتح المتصفح تلقائي.

    python run_web.py

أو دوس دبل كليك على:
    open_web_windows.bat   (ويندوز)
    open_web_mac.command   (ماك / لينكس)
"""

import os
import sys

# لازم البرنامج يشتغل من جوه فولدر المشروع (جنب فولدر app و web)
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

if not os.path.isdir(os.path.join(_HERE, "app")):
    print("\n" + "=" * 60)
    print("  الملف ده مش في مكانه الصح.")
    print("  لازم يكون جنب فولدر (app) و (web).")
    print(f"  مكانه الحالي: {_HERE}")
    print()
    print("  الحل: فك ضغط budget_app.zip، ادخل جوه الفولدر")
    print("  اللي فيه main.py، وشغّل من هناك.")
    print("=" * 60 + "\n")
    input("اضغط Enter للخروج...")
    sys.exit(1)

import threading
import webbrowser

from app.config import APP_NAME, APP_VERSION, WEB_HOST, WEB_PORT
from app.logger_setup import log
from web.server import start_server

URL: str = f"http://{WEB_HOST}:{WEB_PORT}"


def open_browser(delay: float = 1.2) -> None:
    """بيفتح المتصفح بعد ثانية عشان السيرفر يكون قام."""
    def _open() -> None:
        try:
            webbrowser.open(URL)
        except Exception as error:            # لو المتصفح مفتحش لأي سبب
            log.error("Could not open browser: %s", error)
            print(f"  افتح اللينك ده بنفسك: {URL}")

    threading.Timer(delay, _open).start()


def main() -> None:
    log.info("Starting %s v%s (web)", APP_NAME, APP_VERSION)

    if os.name == "nt":
        os.system("")                          # تفعيل الألوان في cmd

    open_browser()

    try:
        start_server()
    finally:
        if os.name == "nt":
            input("\nاضغط Enter للخروج...")     # عشان الشاشة متقفلش فجأة
        sys.exit(0)


if __name__ == "__main__":
    main()
