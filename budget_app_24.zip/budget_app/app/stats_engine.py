"""
stats_engine.py
---------------
المحرّك الإحصائي للمشروع — بيطبّق توزيعات الاحتمالات على مصاريفك الحقيقية.

الفكرة: مصاريفك مش أرقام ثابتة، دي **متغيّر عشوائي** (Random Variable).
لما نتعامل معاها كده نقدر نجاوب على أسئلة زي:
    • المصروف ده طبيعي ولا شاذ؟                    → Normal + Z-score
    • هخلّص الشهر على كام؟ وباحتمال إد إيه أعدّي الدخل؟ → Monte Carlo + CLT
    • بصرف كام مرة في اليوم؟                        → Poisson
    • فاضل قد إيه على الصرفة الجاية؟                 → Exponential
    • احتمال ألتزم بالخطة الشهر الجاي؟               → Binomial + Beta
    • كام شهر لحد أول مرة أخرج عن الخطة؟             → Geometric

بيوضح: Functions + Type Hints, Dictionaries, List/Dict Comprehension,
       map/filter/sorted/zip/enumerate, Custom Exceptions, Modules
       + BONUS: NumPy (اختيارية — فيه fallback بالبايثون الأساسية)
"""

from __future__ import annotations

import calendar
import math
import random
import statistics
from datetime import date, datetime
from typing import Any, Optional

from .budget_manager import BudgetManager
from .config import CATEGORIES, CATEGORY_LABELS
from .exceptions import NotEnoughDataError
from .logger_setup import log
from .models import MonthlyBudget

# ------------------------------------------------------------------
# BONUS: NumPy
# لو المكتبة متسطبة بنستخدمها (أسرع وأدق)، ولو مش متسطبة البرنامج
# بيشتغل عادي بالـ random و statistics بتوع بايثون الأساسية.
# ------------------------------------------------------------------
try:
    import numpy as np

    NUMPY_AVAILABLE: bool = True
except ImportError:  # pragma: no cover
    np = None  # type: ignore[assignment]
    NUMPY_AVAILABLE = False


# ---------------- ثوابت التحليل ----------------
MIN_SAMPLE: int = 5          # أقل عدد مصاريف عشان التحليل يبقى له معنى
Z_THRESHOLD: float = 2.0     # |Z| ≥ 2 يعتبر مصروف شاذ (قاعدة 95٪)
SIMULATIONS: int = 10_000    # عدد محاكاات مونت كارلو
CLT_SAMPLE_SIZES: tuple[int, ...] = (2, 5, 10, 30)
SE_SAMPLE_SIZES: tuple[int, ...] = (5, 10, 20, 30, 50, 75, 100)


# ==================================================================
# 1) دوال رياضية أساسية (من غير أي مكتبة — math بس)
# ==================================================================
def normal_pdf(x: float, mu: float, sigma: float) -> float:
    """دالة الكثافة الاحتمالية للتوزيع الطبيعي — PDF."""
    if sigma <= 0:
        return 0.0
    exponent: float = -0.5 * ((x - mu) / sigma) ** 2
    return (1.0 / (sigma * math.sqrt(2 * math.pi))) * math.exp(exponent)


def normal_cdf(x: float, mu: float = 0.0, sigma: float = 1.0) -> float:
    """
    الدالة التجميعية للتوزيع الطبيعي — CDF: P(X ≤ x).
    متحسبة بـ erf من مكتبة math (مفيش داعي لـ scipy).
    """
    if sigma <= 0:
        return 1.0 if x >= mu else 0.0
    return 0.5 * (1.0 + math.erf((x - mu) / (sigma * math.sqrt(2))))


def poisson_pmf(k: int, lam: float) -> float:
    """دالة الكتلة الاحتمالية لتوزيع بواسون — PMF: P(X = k)."""
    if lam <= 0 or k < 0:
        return 0.0
    return math.exp(-lam) * (lam**k) / math.factorial(k)


def binomial_pmf(k: int, n: int, p: float) -> float:
    """PMF لتوزيع ذات الحدين: احتمال k نجاح من n محاولة."""
    if k < 0 or k > n:
        return 0.0
    return math.comb(n, k) * (p**k) * ((1 - p) ** (n - k))


def geometric_pmf(k: int, p: float) -> float:
    """PMF للتوزيع الهندسي: احتمال أول نجاح يحصل في المحاولة رقم k."""
    if k < 1 or not 0 < p <= 1:
        return 0.0
    return ((1 - p) ** (k - 1)) * p


def exponential_cdf(x: float, rate: float) -> float:
    """CDF للتوزيع الأسّي: P(الانتظار ≤ x)."""
    if rate <= 0 or x < 0:
        return 0.0
    return 1.0 - math.exp(-rate * x)


def uniform_pdf(x: float, low: float, high: float) -> float:
    """PDF للتوزيع المنتظم: كل قيمة جوه المدى ليها نفس الكثافة f(x) = 1/(b−a)."""
    if high <= low:
        return 0.0
    return 1.0 / (high - low) if low <= x <= high else 0.0


def uniform_cdf(x: float, low: float, high: float) -> float:
    """CDF للتوزيع المنتظم: P(X ≤ x) بيزيد خط مستقيم من 0 لـ 1."""
    if high <= low:
        return 0.0
    if x <= low:
        return 0.0
    if x >= high:
        return 1.0
    return (x - low) / (high - low)


def exponential_pdf(x: float, rate: float) -> float:
    """PDF للتوزيع الأسّي: كثافة وقت الانتظار لحد الحدث الجاي."""
    if rate <= 0 or x < 0:
        return 0.0
    return rate * math.exp(-rate * x)


def bernoulli_pmf(k: int, p: float) -> float:
    """PMF لبرنولي: محاولة واحدة نتيجتها نجاح (1) أو فشل (0)."""
    if k == 1:
        return p
    if k == 0:
        return 1.0 - p
    return 0.0


def poisson_cdf(k: int, lam: float) -> float:
    """CDF لبواسون: P(X ≤ k) — مجموع الـ PMF من صفر لحد k. sum() + comprehension"""
    if k < 0:
        return 0.0
    return min(1.0, sum(poisson_pmf(index, lam) for index in range(int(k) + 1)))


def binomial_cdf(k: int, n: int, p: float) -> float:
    """CDF لذات الحدين: P(X ≤ k) نجاح من n محاولة."""
    if k < 0:
        return 0.0
    return min(1.0, sum(binomial_pmf(index, n, p) for index in range(min(int(k), n) + 1)))


def geometric_cdf(k: int, p: float) -> float:
    """CDF للهندسي: احتمال أول نجاح يحصل في أول k محاولة."""
    if k < 1 or not 0 < p <= 1:
        return 0.0
    return 1.0 - (1 - p) ** int(k)


def beta_pdf(x: float, alpha: float, beta_param: float) -> float:
    """
    PDF لتوزيع بيتا — بيوصف قيمة بين 0 و 1 (نسبة / احتمال).
    دالة بيتا نفسها متحسبة بـ lgamma عشان منعملش overflow.
    """
    if not 0 < x < 1 or alpha <= 0 or beta_param <= 0:
        return 0.0
    log_beta: float = (
        math.lgamma(alpha) + math.lgamma(beta_param) - math.lgamma(alpha + beta_param)
    )
    log_value: float = (
        (alpha - 1) * math.log(x) + (beta_param - 1) * math.log(1 - x) - log_beta
    )
    return math.exp(log_value)


def gamma_pdf(x: float, shape: float, scale: float) -> float:
    """
    PDF لتوزيع جاما — وقت الانتظار لحد ما يحصل عدد (shape) من الأحداث.
    الأسّي حالة خاصة منه لما shape = 1.
    """
    if x < 0 or shape <= 0 or scale <= 0:
        return 0.0
    if x == 0:
        return 0.0
    log_value: float = (
        (shape - 1) * math.log(x)
        - (x / scale)
        - math.lgamma(shape)
        - shape * math.log(scale)
    )
    return math.exp(log_value)


def _lower_gamma_regularized(shape: float, x: float) -> float:
    """
    دالة جاما الناقصة المنظّمة P(shape, x) — متحسبة بمتسلسلة أو كسر مستمر.
    دي أساس الـ CDF بتاع جاما، ومتكتبة بالإيد عشان منحتاجش scipy.
    """
    if x <= 0 or shape <= 0:
        return 0.0

    if x < shape + 1:                      # متسلسلة (بتقرب بسرعة للقيم الصغيرة)
        term: float = 1.0 / shape
        total: float = term
        index: float = shape
        for _ in range(500):
            index += 1
            term *= x / index
            total += term
            if abs(term) < abs(total) * 1e-12:
                break                      # break: وصلنا للدقة المطلوبة
        return total * math.exp(-x + shape * math.log(x) - math.lgamma(shape))

    # كسر مستمر (Lentz) للقيم الكبيرة
    tiny: float = 1e-300
    b: float = x + 1 - shape
    c: float = 1 / tiny
    d: float = 1 / b
    h: float = d
    for step in range(1, 500):
        an: float = -step * (step - shape)
        b += 2
        d = an * d + b
        if abs(d) < tiny:
            d = tiny
        c = b + an / c
        if abs(c) < tiny:
            c = tiny
        d = 1 / d
        delta: float = d * c
        h *= delta
        if abs(delta - 1.0) < 1e-12:
            break
    upper: float = math.exp(-x + shape * math.log(x) - math.lgamma(shape)) * h
    return 1.0 - upper


def gamma_cdf(x: float, shape: float, scale: float) -> float:
    """CDF لتوزيع جاما: P(وقت الانتظار ≤ x)."""
    if x <= 0 or shape <= 0 or scale <= 0:
        return 0.0
    return _lower_gamma_regularized(shape, x / scale)


def describe(values: list[float]) -> dict[str, float]:
    """
    إحصاءات وصفية لأي عيّنة أرقام.
    بتستخدم NumPy لو موجودة، وإلا statistics العادية.
    """
    count: int = len(values)
    if count == 0:
        return {"count": 0, "mean": 0.0, "median": 0.0, "std": 0.0, "min": 0.0, "max": 0.0}

    if NUMPY_AVAILABLE:
        array = np.array(values, dtype=float)
        return {
            "count": count,
            "mean": float(array.mean()),
            "median": float(np.median(array)),
            "std": float(array.std(ddof=1)) if count > 1 else 0.0,
            "min": float(array.min()),
            "max": float(array.max()),
        }

    return {
        "count": count,
        "mean": statistics.fmean(values),
        "median": statistics.median(values),
        "std": statistics.stdev(values) if count > 1 else 0.0,
        "min": min(values),
        "max": max(values),
    }


# ==================================================================
# 2) استخراج البيانات من الميزانية
# ==================================================================
def expense_amounts(manager: BudgetManager, category: Optional[str] = None) -> list[float]:
    """
    مبالغ المصاريف كـ list أرقام — دي «العيّنة» بتاعتنا.
    BONUS: map() + filter() + lambda
    """
    expenses = manager.budget.expenses
    if category is not None:
        expenses = list(filter(lambda item: item.category == category, expenses))
    return list(map(lambda item: float(item.amount), expenses))


def daily_totals(manager: BudgetManager) -> dict[str, float]:
    """
    إجمالي المصروف لكل يوم عدّى من الشهر (اليوم اللي مصرفتش فيه = 0).
    الأيام دي هي العيّنة اللي بنبني عليها توقّع آخر الشهر.
    """
    totals: dict[str, float] = {}
    for expense in manager.budget.expenses:
        totals[expense.created_at] = totals.get(expense.created_at, 0.0) + expense.amount

    year, month = month_parts(manager.current_month)
    last_day: int = elapsed_days(manager)

    # Dictionary Comprehension: كل الأيام من 1 لحد النهارده
    return {
        f"{year:04d}-{month:02d}-{day:02d}": round(
            totals.get(f"{year:04d}-{month:02d}-{day:02d}", 0.0), 2
        )
        for day in range(1, last_day + 1)
    }


def month_parts(month_key: str) -> tuple[int, int]:
    """بتحوّل '2026-08' لـ (2026, 8). Tuple + Strings"""
    try:
        year_text, month_text = month_key.split("-")
        return int(year_text), int(month_text)
    except (ValueError, AttributeError):
        today = date.today()
        return today.year, today.month


def days_in_month(month_key: str) -> int:
    """عدد أيام الشهر (بيراعي السنة الكبيسة)."""
    year, month = month_parts(month_key)
    return calendar.monthrange(year, month)[1]


def elapsed_days(manager: BudgetManager) -> int:
    """
    كام يوم عدّى من الشهر.
    لو الشهر ده هو الشهر الحالي → لحد النهارده، ولو شهر قديم → الشهر كله.
    """
    today = date.today()
    year, month = month_parts(manager.current_month)

    if (year, month) == (today.year, today.month):
        return today.day
    return days_in_month(manager.current_month)


def require_sample(values: list[float], what: str, minimum: int = MIN_SAMPLE) -> None:
    """
    Custom Exception: لو العيّنة صغيرة أوي، التحليل هيبقى كلام فاضي.
    """
    if len(values) < minimum:
        raise NotEnoughDataError(what, len(values), minimum)


# ==================================================================
# 3) Normal + Z-Score → كشف المصاريف الشاذة
# ==================================================================
def anomaly_report(manager: BudgetManager, threshold: float = Z_THRESHOLD) -> dict[str, Any]:
    """
    بيحسب Z-Score لكل مصروف:  Z = (x − μ) / σ
    وبيقارن التوزيع الفعلي بقاعدة (68 – 95 – 99.7).

    المصروف اللي |Z| ≥ 2 معناه إنه بعيد عن متوسط مصاريفك بحيث إن
    احتمال حصوله طبيعياً أقل من 5٪ → يستاهل وقفة.
    """
    amounts: list[float] = expense_amounts(manager)
    require_sample(amounts, "تحليل المصاريف الشاذة")

    overall = describe(amounts)
    mu: float = overall["mean"]
    sigma: float = overall["std"] or 1e-9

    # لكل تصنيف إحصاءاته لوحده لو عنده عيّنة كفاية
    per_category: dict[str, dict[str, float]] = {}
    for name in CATEGORIES:
        values: list[float] = expense_amounts(manager, name)
        if len(values) >= MIN_SAMPLE:
            per_category[name] = describe(values)

    flagged: list[dict[str, Any]] = []
    for expense in manager.budget.expenses:
        stats = per_category.get(expense.category, overall)
        local_mu: float = stats["mean"]
        local_sigma: float = stats["std"] or sigma
        z_value: float = (expense.amount - local_mu) / (local_sigma or 1e-9)

        if abs(z_value) < threshold:
            continue          # continue: المصروف ده طبيعي، عدّي عليه

        flagged.append(
            {
                "id": expense.expense_id,
                "amount": round(expense.amount, 2),
                "category": expense.category,
                "label": CATEGORY_LABELS[expense.category],
                "description": expense.description,
                "date": expense.created_at,
                "z": round(z_value, 2),
                "baseline_mean": round(local_mu, 2),
                "message": (
                    f"مصروف {expense.description or CATEGORY_LABELS[expense.category]} "
                    f"بـ {expense.amount:,.0f} — بعيد {abs(z_value):.1f} انحراف معياري عن "
                    f"متوسطك ({local_mu:,.0f})"
                ),
            }
        )

    # sorted() + lambda: الأغرب الأول
    flagged = sorted(flagged, key=lambda item: abs(item["z"]), reverse=True)

    # التحقق من القاعدة التجريبية 68-95-99.7 على بياناتك أنت
    within: dict[str, float] = {}
    for sigmas, expected in ((1, 68.0), (2, 95.0), (3, 99.7)):
        inside: int = len(
            [value for value in amounts if abs(value - mu) <= sigmas * sigma]
        )
        within[f"{sigmas}σ"] = round(inside / len(amounts) * 100, 1)

    log.info("Anomaly scan: %d flagged out of %d", len(flagged), len(amounts))
    return {
        "stats": {key: round(value, 2) for key, value in overall.items()},
        "threshold": threshold,
        "flagged": flagged,
        "empirical_rule": {
            "observed": within,
            "expected": {"1σ": 68.0, "2σ": 95.0, "3σ": 99.7},
        },
        "normal_range": {
            "low": round(max(mu - 2 * sigma, 0), 2),
            "high": round(mu + 2 * sigma, 2),
        },
    }


def z_score_of(manager: BudgetManager, amount: float, category: str) -> dict[str, Any]:
    """
    «لو صرفت المبلغ ده دلوقتي، هيبقى طبيعي ولا شاذ؟»
    بيستخدم توزيع التصنيف نفسه لو فيه بيانات كفاية.
    """
    values: list[float] = expense_amounts(manager, category)
    if len(values) < MIN_SAMPLE:
        values = expense_amounts(manager)
    require_sample(values, f"تقييم مصروف {CATEGORY_LABELS.get(category, category)}")

    stats = describe(values)
    sigma: float = stats["std"] or 1e-9
    z_value: float = (amount - stats["mean"]) / sigma

    # نسبة المصاريف اللي أقل من المبلغ ده (Percentile من الـ CDF)
    percentile: float = normal_cdf(amount, stats["mean"], sigma) * 100

    if abs(z_value) < 1:
        verdict = "طبيعي تماماً"
    elif abs(z_value) < 2:
        verdict = "أعلى شوية من المعتاد"
    elif abs(z_value) < 3:
        verdict = "شاذ — بره 95٪ من مصاريفك"
    else:
        verdict = "شاذ جداً — بره 99.7٪ من مصاريفك"

    return {
        "amount": round(amount, 2),
        "category": category,
        "mean": round(stats["mean"], 2),
        "std": round(sigma, 2),
        "z": round(z_value, 2),
        "percentile": round(percentile, 1),
        "verdict": verdict,
    }


# ==================================================================
# 4) Monte Carlo + CLT → توقّع آخر الشهر
# ==================================================================
def forecast(manager: BudgetManager, simulations: int = SIMULATIONS) -> dict[str, Any]:
    """
    توقّع إجمالي مصروف الشهر بطريقتين ومقارنتهم:

    (أ) محاكاة مونت كارلو: بناخد عيّنة عشوائية (Bootstrap) من الأيام اللي
        عدّت، ونعيد سحبها لباقي أيام الشهر 10,000 مرة → توزيع كامل للنتيجة.

    (ب) تقريب نظرية النهاية المركزية (CLT): مجموع أيام كتير بيقرب من
        التوزيع الطبيعي، يعني:
            μ_total = الحالي + (الأيام الباقية × متوسط اليوم)
            σ_total = σ_اليوم × √(الأيام الباقية)

    إن الطريقتين بيطلعوا نفس الرقم تقريباً = دليل عملي على الـ CLT.
    """
    manager.require_income()

    days: dict[str, float] = daily_totals(manager)
    values: list[float] = list(days.values())
    require_sample(values, "توقّع آخر الشهر", minimum=3)

    total_days: int = days_in_month(manager.current_month)
    passed: int = len(values)
    remaining: int = max(total_days - passed, 0)

    current_total: float = manager.total_spent()
    income: float = manager.budget.income

    stats = describe(values)
    mu_day: float = stats["mean"]
    sigma_day: float = stats["std"]

    # ---------- (أ) محاكاة مونت كارلو ----------
    if remaining == 0:
        projections: list[float] = [current_total]
    elif NUMPY_AVAILABLE:
        sample = np.random.choice(np.array(values), size=(simulations, remaining), replace=True)
        projections = (current_total + sample.sum(axis=1)).tolist()
    else:
        projections = [
            current_total + sum(random.choices(values, k=remaining))
            for _ in range(simulations)
        ]

    projections_sorted: list[float] = sorted(projections)
    over_income: int = len([value for value in projections if value > income])

    # ---------- (ب) تقريب CLT ----------
    clt_mean: float = current_total + remaining * mu_day
    clt_sigma: float = sigma_day * math.sqrt(remaining) if remaining else 0.0
    clt_probability: float = (
        1.0 - normal_cdf(income, clt_mean, clt_sigma) if clt_sigma > 0 else float(clt_mean > income)
    )

    result: dict[str, Any] = {
        "days_passed": passed,
        "days_remaining": remaining,
        "days_total": total_days,
        "current_total": round(current_total, 2),
        "income": round(income, 2),
        "daily_mean": round(mu_day, 2),
        "daily_std": round(sigma_day, 2),
        "simulations": len(projections),
        "expected_total": round(_mean(projections), 2),
        "p05": round(_percentile(projections_sorted, 5), 2),
        "p50": round(_percentile(projections_sorted, 50), 2),
        "p95": round(_percentile(projections_sorted, 95), 2),
        "risk_over_income": round(over_income / len(projections) * 100, 1),
        "clt_mean": round(clt_mean, 2),
        "clt_std": round(clt_sigma, 2),
        "clt_risk": round(clt_probability * 100, 1),
        "standard_error": round(sigma_day / math.sqrt(passed), 2) if passed else 0.0,
        "categories": _category_risk(manager, projections_sorted, remaining, simulations),
        "samples": projections[:2000],   # للرسم البياني
    }

    log.info(
        "Forecast: expected %.0f (risk %.1f%%)",
        result["expected_total"],
        result["risk_over_income"],
    )
    return result


def _category_risk(
    manager: BudgetManager,
    projections: list[float],
    remaining: int,
    simulations: int,
) -> list[dict[str, Any]]:
    """احتمال إن كل تصنيف يعدّي خطته لحد آخر الشهر (محاكاة لكل تصنيف)."""
    plan = manager.budget.allocation()
    spent = manager.spent_by_category()
    rows: list[dict[str, Any]] = []

    for name in CATEGORIES:
        values: list[float] = expense_amounts(manager, name)
        planned: float = plan[name]
        used: float = spent[name]

        if used > planned:
            probability: float = 100.0
        elif not values or remaining == 0:
            probability = 0.0
        else:
            # متوسط عدد مرات الصرف في اليوم على التصنيف ده
            rate: float = len(values) / max(elapsed_days(manager), 1)
            day_stats = describe(values)
            expected_extra: float = rate * remaining * day_stats["mean"]
            sigma_extra: float = day_stats["std"] * math.sqrt(max(rate * remaining, 1e-9))
            probability = (
                (1.0 - normal_cdf(planned - used, expected_extra, sigma_extra)) * 100
                if sigma_extra > 0
                else float(used + expected_extra > planned) * 100
            )

        rows.append(
            {
                "key": name,
                "label": CATEGORY_LABELS[name],
                "planned": round(planned, 2),
                "spent": round(used, 2),
                "risk": round(min(max(probability, 0.0), 100.0), 1),
            }
        )

    return rows


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _percentile(sorted_values: list[float], percent: float) -> float:
    """المئين من قائمة مرتّبة (من غير NumPy عشان تشتغل في كل الحالات)."""
    if not sorted_values:
        return 0.0
    position: float = (percent / 100) * (len(sorted_values) - 1)
    lower: int = math.floor(position)
    upper: int = math.ceil(position)
    if lower == upper:
        return sorted_values[lower]
    weight: float = position - lower
    return sorted_values[lower] * (1 - weight) + sorted_values[upper] * weight


# ==================================================================
# 5) Poisson + Exponential → إيقاع الصرف
# ==================================================================
def spending_rhythm(manager: BudgetManager) -> dict[str, Any]:
    """
    Poisson: كام عملية صرف بتحصل في اليوم؟ → P(X = k)
    Exponential: قد إيه المدة المتوقعة لحد الصرفة الجاية؟

    الاتنين مربوطين ببعض: بواسون بيعدّ الأحداث، والأسّي بيقيس
    الوقت بين الأحداث.
    """
    expenses = manager.budget.expenses
    if len(expenses) < 3:
        raise NotEnoughDataError("تحليل إيقاع الصرف", len(expenses), 3)

    passed: int = max(elapsed_days(manager), 1)
    lam: float = len(expenses) / passed      # λ = متوسط عدد العمليات في اليوم

    # جدول بواسون: احتمال أعمل k عملية صرف بكرة
    pmf_table: list[dict[str, float]] = [
        {"k": k, "probability": round(poisson_pmf(k, lam) * 100, 2)}
        for k in range(0, 9)
    ]

    # التوزيع الفعلي لعدد العمليات في اليوم (عشان نقارنه ببواسون)
    counts: dict[str, int] = {}
    for expense in expenses:
        counts[expense.created_at] = counts.get(expense.created_at, 0) + 1

    year, month = month_parts(manager.current_month)
    observed: list[int] = [
        counts.get(f"{year:04d}-{month:02d}-{day:02d}", 0) for day in range(1, passed + 1)
    ]
    observed_distribution: list[dict[str, float]] = [
        {"k": k, "days": observed.count(k), "percent": round(observed.count(k) / passed * 100, 1)}
        for k in range(0, max(observed) + 1)
    ]

    # Exponential: المدة بين أيام الصرف
    active_days: list[int] = sorted(
        {int(item.created_at.split("-")[2]) for item in expenses}
    )
    gaps: list[float] = [
        float(second - first) for first, second in zip(active_days, active_days[1:])
    ]
    mean_gap: float = _mean(gaps) if gaps else 1 / lam
    rate: float = 1 / mean_gap if mean_gap > 0 else lam

    return {
        "lambda": round(lam, 3),
        "expenses_count": len(expenses),
        "days_passed": passed,
        "no_spend_day": round(poisson_pmf(0, lam) * 100, 1),
        "poisson_table": pmf_table,
        "observed_distribution": observed_distribution,
        "mean_gap_days": round(mean_gap, 2),
        "rate": round(rate, 3),
        "within_1_day": round(exponential_cdf(1, rate) * 100, 1),
        "within_3_days": round(exponential_cdf(3, rate) * 100, 1),
        "active_days": len(active_days),
    }


# ==================================================================
# 6) Binomial + Beta + Geometric → التزامك بالخطة
# ==================================================================
def month_on_plan(budget: MonthlyBudget) -> Optional[bool]:
    """هل الشهر ده كان ملتزم بالخطة؟ (None لو الشهر مفيهوش دخل أصلاً)."""
    if budget.income <= 0:
        return None

    plan = budget.allocation()
    spent: dict[str, float] = {name: 0.0 for name in CATEGORIES}
    for expense in budget.expenses:
        spent[expense.category] += expense.amount

    return all(spent[name] <= plan[name] for name in CATEGORIES)


def commitment_report(manager: BudgetManager, horizon: int = 3) -> dict[str, Any]:
    """
    كل شهر = تجربة برنولي واحدة (ملتزم / مش ملتزم).
    منها بنطلع:
        • Binomial: احتمال تلتزم k شهر من الـ horizon الجايين
        • Beta:     تقدير أدق لمعدل التزامك الحقيقي + فترة ثقة
        • Geometric: متوسط عدد الشهور لحد أول مرة تخرج عن الخطة
    """
    results: list[tuple[str, bool]] = [
        (month, bool(status))
        for month, budget in sorted(manager.months.items())
        if (status := month_on_plan(budget)) is not None
    ]

    if not results:
        raise NotEnoughDataError("تحليل الالتزام", 0, 1)

    successes: int = len([1 for _month, status in results if status])
    trials: int = len(results)
    p_hat: float = successes / trials

    # Beta Posterior: Beta(نجاح+1, فشل+1) — بتصلّح تقدير p لما العيّنة صغيرة
    alpha: float = successes + 1
    beta_param: float = (trials - successes) + 1
    beta_mean: float = alpha / (alpha + beta_param)

    if NUMPY_AVAILABLE:
        draws = np.random.beta(alpha, beta_param, size=20_000)
        credible = (float(np.percentile(draws, 5)), float(np.percentile(draws, 95)))
    else:
        sample = sorted(random.betavariate(alpha, beta_param) for _ in range(5_000))
        credible = (_percentile(sample, 5), _percentile(sample, 95))

    p_used: float = beta_mean     # بنستخدم تقدير Beta أأمن من p̂ الخام

    binomial_table: list[dict[str, float]] = [
        {"k": k, "probability": round(binomial_pmf(k, horizon, p_used) * 100, 1)}
        for k in range(horizon + 1)
    ]

    # Geometric: أول شهر تخرج فيه عن الخطة، باحتمال فشل (1 − p)
    fail_probability: float = 1 - p_used
    expected_until_slip: float = 1 / fail_probability if fail_probability > 0 else float("inf")

    return {
        "months": [{"month": month, "on_plan": status} for month, status in results],
        "trials": trials,
        "successes": successes,
        "p_hat": round(p_hat * 100, 1),
        "beta_estimate": round(beta_mean * 100, 1),
        "credible_interval": [round(credible[0] * 100, 1), round(credible[1] * 100, 1)],
        "horizon": horizon,
        "binomial_table": binomial_table,
        "at_least_two": round(
            sum(binomial_pmf(k, horizon, p_used) for k in range(2, horizon + 1)) * 100, 1
        ),
        "expected_months_until_slip": (
            round(expected_until_slip, 1) if math.isfinite(expected_until_slip) else None
        ),
        "geometric_table": [
            {"k": k, "probability": round(geometric_pmf(k, fail_probability) * 100, 1)}
            for k in range(1, 7)
        ]
        if fail_probability > 0
        else [],
    }


# ==================================================================
# 7) نظرية النهاية المركزية — على مصاريفك أنت
# ==================================================================
def pace_report(manager: BudgetManager) -> dict[str, Any]:
    """
    إيقاع الشهر من زاويتين تانيتين:

    • Gamma:   الأسّي بيقيس الوقت لحد أول حدث، وجاما بتقيس الوقت لحد
               الحدث رقم k. فلو باقي في تصنيف مبلغ يكفي k مصروف تاني،
               نقدر نحسب توزيع «امتى التصنيف ده هيخلص» ونجاوب:
               احتمال يخلص قبل نهاية الشهر إد إيه؟

    • Uniform: لو كنت بتصرف بالتساوي على كل أيام الشهر، اليوم كان هياخد
               نفس النصيب (توزيع منتظم). بنقارن الواقع بالمثالي ده.

    • فترة ثقة 95٪ لمتوسط صرفك اليومي:  μ ± 1.96 × SE   حيث SE = σ/√n
    """
    daily: dict[str, float] = daily_totals(manager)
    require_sample(list(daily.values()), "تحليل إيقاع الشهر", minimum=3)

    passed: int = max(elapsed_days(manager), 1)
    total_days: int = days_in_month(manager.current_month)
    remaining_days: int = max(total_days - passed, 0)

    # ---------- فترة الثقة على المتوسط اليومي (SE) ----------
    day_values: list[float] = [daily.get(day, 0.0) for day in _all_day_keys(manager, passed)]
    day_stats = describe(day_values)
    sample_size: int = len(day_values)
    standard_error: float = (day_stats["std"] / math.sqrt(sample_size)) if sample_size else 0.0
    margin: float = 1.96 * standard_error

    # ---------- Uniform: بتصرف بانتظام ولا على دفعات؟ ----------
    even_share: float = day_stats["mean"]          # نصيب اليوم لو التوزيع منتظم
    deviation: float = (
        _mean([abs(value - even_share) for value in day_values]) if day_values else 0.0
    )
    # 100٪ = منتظم تماماً زي Uniform، 0٪ = كله في يوم واحد
    evenness: float = round(max(0.0, 1 - (deviation / even_share)) * 100, 1) if even_share else 0.0
    busiest_day: str = max(daily, key=lambda key: daily[key]) if daily else ""
    busiest_share: float = (
        round(daily[busiest_day] / sum(daily.values()) * 100, 1) if daily else 0.0
    )

    # ---------- Gamma: كل تصنيف هيخلص امتى؟ ----------
    plan = manager.budget.allocation()
    spent = manager.spent_by_category()
    categories: list[dict[str, Any]] = []

    for name in CATEGORIES:
        amounts: list[float] = expense_amounts(manager, name)
        remaining_money: float = plan[name] - spent[name]

        if len(amounts) < 2 or remaining_money <= 0:
            categories.append(
                {
                    "key": name,
                    "label": CATEGORY_LABELS[name],
                    "status": "over" if remaining_money <= 0 else "لسه مفيش بيانات كفاية",
                    "remaining": round(max(remaining_money, 0), 2),
                    "expected_days": None,
                    "risk_before_month_end": 100.0 if remaining_money <= 0 else None,
                }
            )
            continue                      # continue: التصنيف ده مش هيتحسبله جاما

        mean_expense: float = _mean(amounts)
        rate_per_day: float = len(amounts) / passed          # λ للتصنيف ده
        # كام مصروف تاني الباقي بيكفيهم → ده الـ shape بتاع جاما
        shape: float = max(remaining_money / mean_expense, 0.1)
        scale: float = 1 / rate_per_day if rate_per_day > 0 else float(total_days)

        expected_days: float = shape * scale                 # متوسط جاما = shape × scale
        risk: float = (
            round(gamma_cdf(remaining_days, shape, scale) * 100, 1) if remaining_days else 0.0
        )

        categories.append(
            {
                "key": name,
                "label": CATEGORY_LABELS[name],
                "status": "ok",
                "remaining": round(remaining_money, 2),
                "expenses_left": round(shape, 1),
                "shape": round(shape, 2),
                "scale": round(scale, 2),
                "expected_days": round(expected_days, 1),
                "expected_date": _shift_day(manager, expected_days),
                "risk_before_month_end": risk,
            }
        )

    log.info("Pace report: evenness=%.1f%%, %d categories", evenness, len(categories))
    return {
        "days_passed": passed,
        "days_remaining": remaining_days,
        "daily_mean": round(day_stats["mean"], 2),
        "daily_std": round(day_stats["std"], 2),
        "standard_error": round(standard_error, 2),
        "confidence_interval": [
            round(max(day_stats["mean"] - margin, 0), 2),
            round(day_stats["mean"] + margin, 2),
        ],
        "uniform_density": round(1 / total_days, 4),
        "even_share": round(even_share, 2),
        "evenness": evenness,
        "busiest_day": busiest_day,
        "busiest_share": busiest_share,
        "categories": categories,
    }


def _all_day_keys(manager: BudgetManager, passed: int) -> list[str]:
    """مفاتيح كل الأيام اللي عدّت من الشهر بصيغة YYYY-MM-DD. List Comprehension"""
    year, month = month_parts(manager.current_month)
    return [f"{year:04d}-{month:02d}-{day:02d}" for day in range(1, passed + 1)]


def _shift_day(manager: BudgetManager, days_ahead: float) -> Optional[str]:
    """اليوم المتوقع بعد عدد أيام من النهاردة — أو None لو بره الشهر."""
    year, month = month_parts(manager.current_month)
    target: int = elapsed_days(manager) + int(round(days_ahead))
    if target > days_in_month(manager.current_month):
        return None
    return f"{year:04d}-{month:02d}-{max(target, 1):02d}"


# ==================================================================
# 8) CLT → نظرية النهاية المركزية على مصاريفك
# ==================================================================
def clt_experiment(
    manager: BudgetManager, sizes: tuple[int, ...] = CLT_SAMPLE_SIZES, repeats: int = 3_000
) -> dict[str, Any]:
    """
    تجربة عملية للـ CLT: مصاريفك توزيعها ملويّ (كذا مصروف صغير وواحد كبير)،
    ومع ذلك لو سحبنا عيّنات وحسبنا متوسطها، توزيع المتوسطات بيقرب من الطبيعي
    وبيضيق كل ما حجم العيّنة زاد — والخطأ المعياري بيقل بـ σ/√n.
    """
    population: list[float] = expense_amounts(manager)
    require_sample(population, "تجربة نظرية النهاية المركزية", minimum=8)

    population_stats = describe(population)
    sigma: float = population_stats["std"]

    experiments: list[dict[str, Any]] = []
    for size in sizes:
        if NUMPY_AVAILABLE:
            array = np.array(population, dtype=float)
            draws = np.random.choice(array, size=(repeats, size), replace=True)
            means = draws.mean(axis=1)
            sample_means: list[float] = means.tolist()
        else:
            sample_means = [
                _mean(random.choices(population, k=size)) for _ in range(repeats)
            ]

        stats = describe(sample_means)
        experiments.append(
            {
                "n": size,
                "mean_of_means": round(stats["mean"], 2),
                "observed_se": round(stats["std"], 2),
                "theoretical_se": round(sigma / math.sqrt(size), 2),
                "means": sample_means[:1500],     # للرسم
            }
        )

    se_curve: list[dict[str, float]] = [
        {"n": size, "se": round(sigma / math.sqrt(size), 2)} for size in SE_SAMPLE_SIZES
    ]

    return {
        "population": {key: round(value, 2) for key, value in population_stats.items()},
        "population_sample": population,
        "experiments": experiments,
        "se_curve": se_curve,
    }


def histogram(values: list[float], bins: int = 18) -> list[dict[str, float]]:
    """
    بيقسّم أي عيّنة لأعمدة (Histogram) عشان الواجهة ترسمها.
    بيرجّع لكل عمود: بدايته، نهايته، عدد القيم فيه، ونسبتها.
    """
    if not values:
        return []

    low: float = min(values)
    high: float = max(values)
    if high == low:
        return [{"start": low, "end": high, "count": len(values), "percent": 100.0}]

    width: float = (high - low) / bins
    counts: list[int] = [0] * bins

    for value in values:
        index: int = min(int((value - low) / width), bins - 1)
        counts[index] += 1

    # enumerate() لبناء الأعمدة بترتيبها
    return [
        {
            "start": round(low + index * width, 2),
            "end": round(low + (index + 1) * width, 2),
            "count": count,
            "percent": round(count / len(values) * 100, 2),
        }
        for index, count in enumerate(counts)
    ]


def clt_lab(
    manager: BudgetManager, sample_size: int = 30, repeats: int = 2_000
) -> dict[str, Any]:
    """
    معمل الـ CLT التفاعلي: المستخدم يختار حجم العيّنة (n) وعدد التكرارات،
    والدالة بترجّع الهيستوجرام بتاع المجتمع الأصلي وبتاع متوسطات العيّنات
    مع المنحنى الطبيعي المتوقع — نفس تجربة المحاضرة بس على مصاريفه هو.
    """
    population: list[float] = expense_amounts(manager)
    require_sample(population, "معمل نظرية النهاية المركزية", minimum=8)

    sample_size = max(2, min(int(sample_size), 200))
    repeats = max(200, min(int(repeats), 20_000))

    population_stats = describe(population)
    sigma: float = population_stats["std"]

    if NUMPY_AVAILABLE:
        array = np.array(population, dtype=float)
        draws = np.random.choice(array, size=(repeats, sample_size), replace=True)
        means: list[float] = draws.mean(axis=1).tolist()
    else:
        means = [_mean(random.choices(population, k=sample_size)) for _ in range(repeats)]

    means_stats = describe(means)
    theoretical_se: float = sigma / math.sqrt(sample_size)

    # منحنى طبيعي متوقع فوق الهيستوجرام
    curve_low: float = means_stats["mean"] - 4 * (means_stats["std"] or 1)
    curve_high: float = means_stats["mean"] + 4 * (means_stats["std"] or 1)
    step: float = (curve_high - curve_low) / 60
    normal_curve: list[dict[str, float]] = [
        {
            "x": round(curve_low + index * step, 2),
            "y": round(
                normal_pdf(curve_low + index * step, means_stats["mean"], means_stats["std"] or 1),
                8,
            ),
        }
        for index in range(61)
    ]

    return {
        "sample_size": sample_size,
        "repeats": repeats,
        "population_hist": histogram(population),
        "means_hist": histogram(means),
        "normal_curve": normal_curve,
        "population": {key: round(value, 2) for key, value in population_stats.items()},
        "means": {key: round(value, 2) for key, value in means_stats.items()},
        "theoretical_se": round(theoretical_se, 2),
        "observed_se": round(means_stats["std"], 2),
        "verdict": (
            "الفرق بين SE الفعلي والنظري صغير — ده الـ CLT شغال قدامك."
            if abs(means_stats["std"] - theoretical_se) < max(theoretical_se * 0.15, 1)
            else "قرّب العدد أو كبّر n عشان الفرق يقل أكتر."
        ),
    }


# ==================================================================
# 8) التقرير الإحصائي الشامل (ده اللي الواجهات بتناديه)
# ==================================================================
def build_stats_report(manager: BudgetManager) -> dict[str, Any]:
    """
    بيجمع كل التحليلات في dictionary واحدة.
    أي جزء بياناته مش كفاية بيرجع رسالة بدل ما البرنامج يقع.
    """
    report: dict[str, Any] = {
        "month": manager.current_month,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "numpy": NUMPY_AVAILABLE,
    }

    sections: dict[str, Any] = {
        "anomalies": anomaly_report,
        "forecast": forecast,
        "rhythm": spending_rhythm,
        "pace": pace_report,
        "commitment": commitment_report,
        "clt": clt_experiment,
    }

    for key, function in sections.items():
        try:
            report[key] = function(manager)
        except NotEnoughDataError as error:
            report[key] = {"unavailable": error.message}
            log.info("Stats section %s skipped: %s", key, error.message)
        except Exception as error:  # pragma: no cover
            report[key] = {"unavailable": f"تعذّر الحساب: {error}"}
            log.exception("Stats section %s failed", key)

    return report
