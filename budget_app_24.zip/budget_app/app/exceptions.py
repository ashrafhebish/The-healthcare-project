"""
exceptions.py
-------------
BONUS: Custom Exception Classes
كل الأخطاء بتاعة البرنامج بترث من BudgetError عشان نقدر نمسكها كلها بسطر واحد.
"""


class BudgetError(Exception):
    """الأب لكل أخطاء البرنامج (Base Exception)."""

    def __init__(self, message: str = "حصل خطأ في البرنامج") -> None:
        self.message: str = message
        super().__init__(self.message)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message={self.message!r})"


class InvalidAmountError(BudgetError):
    """المبلغ مش رقم صحيح أو بالسالب أو بصفر."""

    def __init__(self, value: object) -> None:
        super().__init__(f"المبلغ غير صحيح: {value!r} — لازم يكون رقم أكبر من صفر")
        self.value = value


class InvalidCategoryError(BudgetError):
    """التصنيف مش من (needs / wants / savings)."""

    def __init__(self, category: str) -> None:
        super().__init__(
            f"تصنيف غير معروف: {category!r} — المسموح: احتياجات / كماليات / توفير"
        )
        self.category = category


class IncomeNotSetError(BudgetError):
    """المستخدم لسه مدخلش الدخل الشهري."""

    def __init__(self) -> None:
        super().__init__("لازم تحدد الدخل الشهري الأول قبل ما تسجل مصاريف.")


class ExpenseNotFoundError(BudgetError):
    """مفيش مصروف بالـ id ده."""

    def __init__(self, expense_id: int) -> None:
        super().__init__(f"مفيش مصروف بالرقم {expense_id}.")
        self.expense_id = expense_id


class NotEnoughDataError(BudgetError):
    """البيانات مش كفاية عشان نعمل تحليل إحصائي له معنى."""

    def __init__(self, what: str, available: int, needed: int) -> None:
        super().__init__(
            f"البيانات مش كفاية لـ{what}: عندك {available} والمطلوب {needed} على الأقل."
        )
        self.what = what
        self.available = available
        self.needed = needed


class DataFileError(BudgetError):
    """مشكلة في قراءة أو كتابة الملفات (JSON / CSV)."""

    def __init__(self, path: str, reason: str) -> None:
        super().__init__(f"مشكلة في الملف {path}: {reason}")
        self.path = path
        self.reason = reason
