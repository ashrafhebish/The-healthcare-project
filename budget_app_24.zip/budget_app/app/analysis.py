"""
analysis.py
-----------
خط التحليل الإحصائي الكامل — 12 مرحلة على بيانات المصاريف.

كل مرحلة دالة لوحدها بترجّع dictionary فيه النتائج + تفسير بالعربي،
و`run_pipeline()` بتشغّلهم بالترتيب:

    تجهيز البيانات → الإحصاء الوصفي → تحليل التوزيع → الجبر الخطي →
    الاحتمالات → المعاينة والاستدلال → فترات الثقة → اختبار الفروض →
    ANOVA → التفاضل → التصوّر البياني → النتائج النهائية

الفلسفة هنا: الأرقام لوحدها مش تحليل. كل مرحلة بترجّع `interpretation`
بيقول الرقم ده معناه إيه على فلوسك انت.

بيوضح: Modules, Functions, Type Hints, Dataclass, Dictionaries, Sets,
       Tuples, Comprehensions, map/filter/sorted/zip/enumerate, lambda,
       Custom Exceptions, try/except
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from datetime import date
from typing import Any, Callable, Optional

from .config import CATEGORIES, CATEGORY_LABELS, CURRENCY
from .exceptions import BudgetError
from .inference import (
    confidence_interval,
    kurtosis,
    linear_regression,
    one_sample_t_test,
    one_way_anova,
    quadratic_fit,
    shape_label,
    skewness,
    t_critical,
)
from .logger_setup import log

# أقل عدد صفوف يخلي التحليل له معنى إحصائي
MIN_ROWS: int = 12
ALPHA: float = 0.05
CONFIDENCE: float = 0.95


# جدول تحويل الأرقام العربية والفارسية لأرقام لاتينية.
# مهم لأن الداتا العربية بتيجي أحياناً بأرقام زي ٢٠٠ أو ۲۰۰،
# والفاصلة العشرية العربية ٫ مش نفس النقطة.
ARABIC_DIGITS: dict[int, str] = str.maketrans(
    "٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹٫", "01234567890123456789."
)


def to_number(raw: Any) -> Optional[float]:
    """
    بتحوّل أي قيمة لرقم، وبترجّع None لو مش رقم.
    بتشيل الفواصل الألفية والمسافات وبتحوّل الأرقام العربية.
    """
    if isinstance(raw, (int, float)):
        value = float(raw)
        return None if math.isnan(value) or math.isinf(value) else value

    text = str(raw).translate(ARABIC_DIGITS).replace(",", "").strip()
    if not text:
        return None

    try:
        value = float(text)
    except ValueError:
        return None

    return None if math.isnan(value) or math.isinf(value) else value


class NotEnoughRowsError(BudgetError):
    """Custom Exception: الداتاست أصغر من إن التحليل يبقى له معنى."""

    def __init__(self, have: int, need: int = MIN_ROWS) -> None:
        super().__init__(
            f"الداتاست فيها {have} صف بس، والتحليل محتاج {need} على الأقل "
            f"عشان النتايج تبقى ذات دلالة."
        )
        self.have = have
        self.need = need


# ==================================================================
# المرحلة 1 — جمع البيانات وتجهيزها
# ==================================================================
@dataclass
class Record:
    """صف واحد نضيف من الداتاست. BONUS: Dataclass"""

    row_id: int
    day: str                     # YYYY-MM-DD
    month: str                   # YYYY-MM
    category: str
    amount: float
    description: str = ""

    def __repr__(self) -> str:
        return f"Record(day={self.day!r}, category={self.category!r}, amount={self.amount})"


@dataclass
class Dataset:
    """الداتاست بعد التنظيف + سجل بكل حاجة اتشالت."""

    records: list[Record] = field(default_factory=list)
    dropped: dict[str, int] = field(default_factory=dict)
    raw_count: int = 0

    @property
    def amounts(self) -> list[float]:
        """List Comprehension: عمود المبالغ (المتغيّر الرقمي الأساسي)."""
        return [record.amount for record in self.records]

    def by_category(self) -> dict[str, list[float]]:
        """Dictionary Comprehension: المبالغ متجمّعة حسب التصنيف."""
        return {
            name: [record.amount for record in self.records if record.category == name]
            for name in CATEGORIES
        }

    def daily_totals(self) -> dict[str, float]:
        """إجمالي كل يوم — العيّنة اللي التفاضل والاستدلال بيشتغلوا عليها."""
        totals: dict[str, float] = {}
        for record in self.records:
            totals[record.day] = totals.get(record.day, 0.0) + record.amount
        return dict(sorted(totals.items()))

    def __len__(self) -> int:
        return len(self.records)


def phase1_prepare(rows: list[dict[str, Any]]) -> tuple[Dataset, dict[str, Any]]:
    """
    المرحلة 1: تحميل البيانات وتنظيفها.

    بنشيل: الصفوف الناقصة، المكررة، والمبالغ غير الصحيحة (سالبة/صفر/مش رقم).
    وبنحدد المتغيرات الرقمية والفئوية.
    """
    dataset = Dataset(raw_count=len(rows))
    dropped: dict[str, int] = {"missing": 0, "invalid_amount": 0, "unknown_category": 0, "duplicate": 0}

    # Set: بنستخدمها عشان نكتشف التكرار بسرعة
    seen: set[tuple[str, str, float, str]] = set()
    valid_categories: set[str] = set(CATEGORIES)

    for index, row in enumerate(rows, start=1):
        day = str(row.get("date") or row.get("day") or "").strip()
        category = str(row.get("category") or "").strip().lower()
        description = str(row.get("description") or "").strip()
        raw_amount = row.get("amount")

        # (أ) قيم ناقصة
        if not day or not category or raw_amount in (None, ""):
            dropped["missing"] += 1
            continue

        # (ب) مبلغ غير صحيح — الداتا الخام ممكن تيجي نص أو أرقام عربية
        amount = to_number(raw_amount)
        if amount is None or amount <= 0:
            dropped["invalid_amount"] += 1
            continue

        # (ج) تصنيف مش معروف
        if category not in valid_categories:
            dropped["unknown_category"] += 1
            continue

        # (د) تكرار كامل
        signature = (day, category, round(amount, 2), description)
        if signature in seen:
            dropped["duplicate"] += 1
            continue
        seen.add(signature)

        dataset.records.append(
            Record(
                row_id=index,
                day=day,
                month=day[:7],
                category=category,
                amount=round(amount, 2),
                description=description,
            )
        )

    dataset.dropped = dropped

    if len(dataset) < MIN_ROWS:
        raise NotEnoughRowsError(len(dataset))

    months = sorted({record.month for record in dataset.records})
    total_dropped = sum(dropped.values())

    summary: dict[str, Any] = {
        "raw_rows": dataset.raw_count,
        "clean_rows": len(dataset),
        "dropped_total": total_dropped,
        "dropped_detail": dropped,
        "months": months,
        "days_covered": len(dataset.daily_totals()),
        "variables": {
            "numerical": [
                {"name": "amount", "label": "مبلغ المصروف", "type": "متصل"},
                {"name": "day_index", "label": "رقم اليوم في الشهر", "type": "متقطع"},
            ],
            "categorical": [
                {
                    "name": "category",
                    "label": "التصنيف",
                    "levels": [CATEGORY_LABELS[name] for name in CATEGORIES],
                },
                {"name": "month", "label": "الشهر", "levels": months},
            ],
        },
        "interpretation": (
            f"اتحمّل {dataset.raw_count} صف، واتشال منهم {total_dropped} "
            f"({dropped['missing']} ناقص، {dropped['invalid_amount']} مبلغ غلط، "
            f"{dropped['duplicate']} مكرر، {dropped['unknown_category']} تصنيف مجهول). "
            f"باقي {len(dataset)} صف نضاف على {len(months)} شهر."
        ),
    }

    log.info("Phase 1: %d/%d rows kept", len(dataset), dataset.raw_count)
    return dataset, summary


# ==================================================================
# المرحلة 2 — الإحصاء الوصفي
# ==================================================================
def _mode_of(values: list[float], bin_width: float = 50.0) -> dict[str, Any]:
    """
    المنوال للبيانات المتصلة: بنجمّع القيم في فئات وناخد أكتر فئة تكراراً،
    لأن المبالغ نادراً ما بتتكرر بالظبط.
    """
    if not values:
        return {"value": 0.0, "count": 0, "range": "—"}

    buckets: dict[int, int] = {}
    for value in values:
        key = int(value // bin_width)
        buckets[key] = buckets.get(key, 0) + 1

    # max() + lambda
    top = max(buckets.items(), key=lambda item: item[1])
    low = top[0] * bin_width

    return {
        "value": round(low + bin_width / 2, 2),
        "count": top[1],
        "range": f"{low:,.0f} — {low + bin_width:,.0f}",
        "bin_width": bin_width,
    }


def quantile(sorted_values: list[float], percent: float) -> float:
    """الربيع/المئين بطريقة الاستيفاء الخطي."""
    if not sorted_values:
        return 0.0
    position = (len(sorted_values) - 1) * (percent / 100)
    low = math.floor(position)
    high = math.ceil(position)
    if low == high:
        return sorted_values[int(position)]
    return sorted_values[low] + (sorted_values[high] - sorted_values[low]) * (position - low)


def phase2_descriptive(dataset: Dataset) -> dict[str, Any]:
    """المرحلة 2: المتوسط والوسيط والمنوال والمدى والتباين والانحراف والأرباع."""
    values = sorted(dataset.amounts)
    count = len(values)

    mean = sum(values) / count
    median = quantile(values, 50)
    mode = _mode_of(values)
    variance = sum((value - mean) ** 2 for value in values) / (count - 1)
    std = math.sqrt(variance)

    q1 = quantile(values, 25)
    q3 = quantile(values, 75)
    iqr = q3 - q1

    # نفس الإحصاءات لكل تصنيف (زي ما هنحتاجها في ANOVA)
    per_category = [
        {
            "key": name,
            "label": CATEGORY_LABELS[name],
            "n": len(group),
            "mean": round(sum(group) / len(group), 2) if group else 0.0,
            "median": round(quantile(sorted(group), 50), 2) if group else 0.0,
            "std": round(
                math.sqrt(
                    sum((value - sum(group) / len(group)) ** 2 for value in group)
                    / (len(group) - 1)
                ),
                2,
            )
            if len(group) > 1
            else 0.0,
            "total": round(sum(group), 2),
        }
        for name, group in dataset.by_category().items()
    ]

    # المتوسط أكبر من الوسيط؟ يبقى فيه مصاريف كبيرة بتشد المتوسط
    gap = mean - median
    interpretation = (
        f"متوسط المصروف {mean:,.0f} {CURRENCY} والوسيط {median:,.0f}. "
        + (
            f"المتوسط أعلى من الوسيط بـ {gap:,.0f} — يعني فيه مصاريف كبيرة قليلة "
            f"بتشد المتوسط لفوق، والوسيط أصدق في وصف يومك العادي."
            if gap > std * 0.15
            else "المتوسط والوسيط قريبين من بعض، يعني مفيش قيم متطرفة بتشوّه الصورة."
        )
        + f" ونص مصاريفك بتقع بين {q1:,.0f} و {q3:,.0f} (المدى الربيعي = {iqr:,.0f})."
    )

    return {
        "n": count,
        "mean": round(mean, 2),
        "median": round(median, 2),
        "mode": mode,
        "min": round(values[0], 2),
        "max": round(values[-1], 2),
        "range": round(values[-1] - values[0], 2),
        "variance": round(variance, 2),
        "std": round(std, 2),
        "cv": round(std / mean * 100, 1) if mean else 0.0,
        "q1": round(q1, 2),
        "q2": round(median, 2),
        "q3": round(q3, 2),
        "iqr": round(iqr, 2),
        "per_category": per_category,
        "interpretation": interpretation,
    }


# ==================================================================
# المرحلة 3 — تحليل التوزيع
# ==================================================================
def phase3_distribution(dataset: Dataset, bins: int = 12) -> dict[str, Any]:
    """المرحلة 3: التوزيع التكراري + الهيستوجرام + البوكس بلوت + الشواذ + الشكل."""
    values = sorted(dataset.amounts)
    count = len(values)

    low, high = values[0], values[-1]
    width = (high - low) / bins if high > low else 1.0

    # التوزيع التكراري: عدد + نسبة + تراكمي
    frequency: list[dict[str, Any]] = []
    cumulative = 0
    for index in range(bins):
        start = low + index * width
        end = start + width
        # آخر فئة بتاخد الحد الأعلى نفسه
        inside = [
            value
            for value in values
            if (start <= value < end) or (index == bins - 1 and value == high)
        ]
        cumulative += len(inside)
        frequency.append(
            {
                "start": round(start, 2),
                "end": round(end, 2),
                "label": f"{start:,.0f}—{end:,.0f}",
                "count": len(inside),
                "percent": round(len(inside) / count * 100, 1),
                "cumulative_percent": round(cumulative / count * 100, 1),
            }
        )

    # بوكس بلوت + شواذ بطريقة المدى الربيعي (Tukey)
    q1 = quantile(values, 25)
    q3 = quantile(values, 75)
    iqr = q3 - q1
    lower_fence = q1 - 1.5 * iqr
    upper_fence = q3 + 1.5 * iqr

    inliers = [value for value in values if lower_fence <= value <= upper_fence]
    outliers = [
        {
            "amount": record.amount,
            "day": record.day,
            "label": CATEGORY_LABELS[record.category],
            "description": record.description,
        }
        for record in sorted(dataset.records, key=lambda item: item.amount, reverse=True)
        if record.amount > upper_fence or record.amount < lower_fence
    ]

    mean = sum(values) / count
    std = math.sqrt(sum((value - mean) ** 2 for value in values) / (count - 1))
    skew = skewness(values)
    kurt = kurtosis(values)

    return {
        "frequency": frequency,
        "box_plot": {
            "min": round(min(inliers) if inliers else low, 2),
            "q1": round(q1, 2),
            "median": round(quantile(values, 50), 2),
            "q3": round(q3, 2),
            "max": round(max(inliers) if inliers else high, 2),
            "iqr": round(iqr, 2),
            "lower_fence": round(max(lower_fence, 0), 2),
            "upper_fence": round(upper_fence, 2),
        },
        "outliers": outliers[:8],
        "outliers_count": len(outliers),
        "shape": {
            "skewness": round(skew, 3),
            "kurtosis": round(kurt, 3),
            "label": shape_label(skew),
            "tails": "ذيول تقيلة (قيم متطرفة أكتر من الطبيعي)" if kurt > 0.5 else "ذيول عادية",
        },
        "mean": round(mean, 2),
        "std": round(std, 2),
        "interpretation": (
            f"التوزيع {shape_label(skew)} (معامل التواء {skew:.2f}). "
            f"حسب قاعدة الربيعات، أي مصروف فوق {upper_fence:,.0f} يعتبر شاذ — "
            + (
                f"ولقينا {len(outliers)} مصروف زي كده."
                if outliers
                else "ومفيش ولا مصروف تعدّى الحد ده."
            )
            + (
                " الالتواء لليمين طبيعي في بيانات المصاريف: أغلب الصرف صغير ومتكرر، "
                "وفيه صرفات كبيرة نادرة."
                if skew > 0.5
                else ""
            )
        ),
    }


# ==================================================================
# المرحلة 4 — الجبر الخطي
# ==================================================================
def phase4_linear_algebra(dataset: Dataset, income: float = 0.0) -> dict[str, Any]:
    """
    المرحلة 4: المتجهات والمصفوفات والضرب القياسي وحاصل الضرب النقطي.

    الاستخدام هنا حقيقي مش شكلي:
      • متجه الإنفاق × متجه أوزان الأولوية (dot product) = درجة أولوية إنفاقك
      • مصفوفة (شهور × تصنيفات) بتوصف سلوكك الشهري كله في جدول واحد
      • الضرب القياسي بيجاوب: لو زوّدت كل حاجة 10٪ هيحصل إيه؟
    """
    by_category = dataset.by_category()

    # (أ) متجه الإنفاق
    spend_vector: list[float] = [round(sum(by_category[name]), 2) for name in CATEGORIES]

    # (ب) متجه الأوزان — الاحتياجات ضرورية، الكماليات اختيارية، التوفير استثمار
    weight_vector: list[float] = [1.0, 0.4, 1.5]

    # (ج) حاصل الضرب النقطي: Σ (إنفاق × وزن) — zip() + sum()
    dot = sum(spend * weight for spend, weight in zip(spend_vector, weight_vector))

    total_spend = sum(spend_vector)
    magnitude = math.sqrt(sum(value ** 2 for value in spend_vector))

    # (د) الضرب القياسي: سيناريو «لو زوّدت 10٪»
    scalar = 1.10
    scaled_vector = [round(value * scalar, 2) for value in spend_vector]

    # (هـ) المصفوفة: صف لكل شهر، عمود لكل تصنيف
    months = sorted({record.month for record in dataset.records})
    matrix: list[list[float]] = [
        [
            round(
                sum(
                    record.amount
                    for record in dataset.records
                    if record.month == month and record.category == name
                ),
                2,
            )
            for name in CATEGORIES
        ]
        for month in months
    ]

    # مجاميع الصفوف والأعمدة من نفس المصفوفة
    row_totals = [round(sum(row), 2) for row in matrix]
    column_totals = [round(sum(column), 2) for column in zip(*matrix)]   # zip(*) = ترانسبوز

    # (و) زاوية بين متجه إنفاقك ومتجه الخطة المثالية 50/30/20
    ideal = [0.5, 0.3, 0.2]
    ideal_vector = [income * share for share in ideal] if income else [
        total_spend * share for share in ideal
    ]
    ideal_magnitude = math.sqrt(sum(value ** 2 for value in ideal_vector))
    ideal_dot = sum(a * b for a, b in zip(spend_vector, ideal_vector))
    cosine = ideal_dot / (magnitude * ideal_magnitude) if magnitude and ideal_magnitude else 0.0
    angle = math.degrees(math.acos(max(min(cosine, 1.0), -1.0)))

    return {
        "labels": [CATEGORY_LABELS[name] for name in CATEGORIES],
        "spend_vector": spend_vector,
        "weight_vector": weight_vector,
        "dot_product": round(dot, 2),
        "magnitude": round(magnitude, 2),
        "scalar": scalar,
        "scaled_vector": scaled_vector,
        "scaled_total": round(sum(scaled_vector), 2),
        "extra_cost": round(sum(scaled_vector) - total_spend, 2),
        "matrix": {
            "rows": months,
            "columns": [CATEGORY_LABELS[name] for name in CATEGORIES],
            "values": matrix,
            "row_totals": row_totals,
            "column_totals": column_totals,
            "shape": f"{len(matrix)}×{len(CATEGORIES)}",
        },
        "alignment": {
            "ideal_vector": [round(value, 2) for value in ideal_vector],
            "cosine": round(cosine, 4),
            "angle_degrees": round(angle, 2),
        },
        "interpretation": (
            f"متجه إنفاقك {spend_vector} وطوله {magnitude:,.0f}. "
            f"حاصل الضرب النقطي مع أوزان الأولوية = {dot:,.0f} — الرقم ده بيوزن "
            f"جنيه التوفير بـ 1.5 وجنيه الكماليات بـ 0.4، فبيبقى مقياس لجودة إنفاقك مش حجمه. "
            f"الزاوية بين إنفاقك الفعلي والخطة المثالية {angle:.1f}° "
            + (
                "(قريبة من صفر = إنفاقك يوازي الخطة تقريباً)."
                if angle < 10
                else "(كل ما الزاوية كبرت، كل ما إنفاقك بعد عن شكل الخطة)."
            )
            + f" ولو زوّدت كل بند 10٪ هتدفع {sum(scaled_vector) - total_spend:,.0f} زيادة."
        ),
    }


# ==================================================================
# المرحلة 5 — الاحتمالات
# ==================================================================
def phase5_probability(dataset: Dataset, threshold: Optional[float] = None) -> dict[str, Any]:
    """
    المرحلة 5: احتمال بسيط + احتمال شرطي + القيمة المتوقعة.
    كل الأسئلة من مجال المشروع نفسه (الإنفاق).
    """
    records = dataset.records
    total = len(records)
    values = dataset.amounts

    mean = sum(values) / total
    limit = threshold if threshold else round(mean * 2, 2)

    # (أ) احتمال بسيط: P(المصروف كبير)
    large = [record for record in records if record.amount >= limit]
    p_large = len(large) / total

    # (ب) احتمال بسيط تاني: P(التصنيف = كماليات)
    wants = [record for record in records if record.category == "wants"]
    p_wants = len(wants) / total

    # (ج) احتمال شرطي: P(كبير | كماليات) — filter() + lambda
    large_wants = list(filter(lambda record: record.amount >= limit, wants))
    p_large_given_wants = len(large_wants) / len(wants) if wants else 0.0

    # (د) العكس بقاعدة بايز: P(كماليات | كبير)
    p_wants_given_large = len(large_wants) / len(large) if large else 0.0

    # (هـ) هل الحدثين مستقلين؟ لو P(A|B) = P(A) يبقى مستقلين
    independence_gap = abs(p_large_given_wants - p_large)

    # (و) القيمة المتوقعة للمصروف الواحد = Σ (قيمة الفئة × احتمالها)
    by_category = dataset.by_category()
    expected_table: list[dict[str, Any]] = []
    expected_value = 0.0

    for name in CATEGORIES:
        group = by_category[name]
        if not group:
            continue
        probability = len(group) / total
        group_mean = sum(group) / len(group)
        contribution = probability * group_mean
        expected_value += contribution
        expected_table.append(
            {
                "label": CATEGORY_LABELS[name],
                "probability": round(probability, 4),
                "mean": round(group_mean, 2),
                "contribution": round(contribution, 2),
            }
        )

    # (ز) القيمة المتوقعة لليوم = متوسط عمليات اليوم × متوسط المصروف
    days = len(dataset.daily_totals())
    per_day = total / days if days else 0.0

    return {
        "threshold": limit,
        "simple": [
            {
                "event": f"المصروف ≥ {limit:,.0f} {CURRENCY}",
                "notation": "P(A)",
                "count": len(large),
                "of": total,
                "probability": round(p_large, 4),
                "percent": round(p_large * 100, 1),
            },
            {
                "event": "المصروف من الكماليات",
                "notation": "P(B)",
                "count": len(wants),
                "of": total,
                "probability": round(p_wants, 4),
                "percent": round(p_wants * 100, 1),
            },
        ],
        "conditional": [
            {
                "event": f"مصروف كبير بشرط إنه كماليات",
                "notation": "P(A|B)",
                "count": len(large_wants),
                "of": len(wants),
                "probability": round(p_large_given_wants, 4),
                "percent": round(p_large_given_wants * 100, 1),
            },
            {
                "event": "كماليات بشرط إنه مصروف كبير",
                "notation": "P(B|A)",
                "count": len(large_wants),
                "of": len(large),
                "probability": round(p_wants_given_large, 4),
                "percent": round(p_wants_given_large * 100, 1),
            },
        ],
        "independence": {
            "p_a": round(p_large, 4),
            "p_a_given_b": round(p_large_given_wants, 4),
            "gap": round(independence_gap, 4),
            "independent": independence_gap < 0.05,
        },
        "expected_value": {
            "per_expense": round(expected_value, 2),
            "per_day": round(expected_value * per_day, 2),
            "expenses_per_day": round(per_day, 2),
            "table": expected_table,
        },
        "interpretation": (
            f"احتمال إن أي مصروف يبقى كبير (≥ {limit:,.0f}) هو {p_large * 100:.1f}٪، "
            f"لكن لو عرفنا إنه كماليات الاحتمال بيبقى {p_large_given_wants * 100:.1f}٪ — "
            + (
                "يعني التصنيف بيغيّر الاحتمال فعلاً، والحدثين مش مستقلين."
                if independence_gap >= 0.05
                else "الفرق صغير، يعني التصنيف تقريباً مش بيأثر على حجم المصروف."
            )
            + f" والقيمة المتوقعة للمصروف الواحد {expected_value:,.0f} {CURRENCY}، "
            f"يعني في اليوم متوقع تصرف حوالي {expected_value * per_day:,.0f}."
        ),
    }


# ==================================================================
# المرحلة 6 — المعاينة والاستدلال الإحصائي
# ==================================================================
def phase6_sampling(dataset: Dataset, sample_size: int = 0, seed: int = 7) -> dict[str, Any]:
    """
    المرحلة 6: المجتمع والعيّنة، متوسط العيّنة، الخطأ المعياري، والمقارنة.

    الفكرة الأساسية: لو معناش وقت نراجع كل المصاريف، عيّنة صغيرة بتدينا
    تقدير قريب — والخطأ المعياري بيقولنا قد إيه التقدير ده دقيق.
    """
    population = dataset.amounts
    size = len(population)

    if not sample_size:
        sample_size = max(10, min(size // 3, 40))
    sample_size = min(sample_size, size)

    generator = random.Random(seed)
    sample = generator.sample(population, sample_size)

    population_mean = sum(population) / size
    population_std = math.sqrt(
        sum((value - population_mean) ** 2 for value in population) / size
    )

    sample_mean = sum(sample) / sample_size
    sample_std = math.sqrt(
        sum((value - sample_mean) ** 2 for value in sample) / (sample_size - 1)
    )
    standard_error = sample_std / math.sqrt(sample_size)

    error = sample_mean - population_mean
    error_percent = abs(error) / population_mean * 100 if population_mean else 0.0
    within_se = abs(error) <= 2 * standard_error

    # توزيع المعاينة: بنكرر السحب ونشوف توزيع المتوسطات (دليل عملي على CLT)
    repeated_means = [
        sum(generator.sample(population, sample_size)) / sample_size for _ in range(400)
    ]
    means_mean = sum(repeated_means) / len(repeated_means)
    means_std = math.sqrt(
        sum((value - means_mean) ** 2 for value in repeated_means) / (len(repeated_means) - 1)
    )
    theoretical_se = population_std / math.sqrt(sample_size)

    return {
        "population": {
            "definition": "كل المصاريف المسجّلة في الداتاست بعد التنظيف",
            "n": size,
            "mean": round(population_mean, 2),
            "std": round(population_std, 2),
        },
        "sample": {
            "definition": f"عيّنة عشوائية بسيطة حجمها {sample_size} (كل مصروف له نفس فرصة الاختيار)",
            "n": sample_size,
            "mean": round(sample_mean, 2),
            "std": round(sample_std, 2),
            "standard_error": round(standard_error, 2),
            "fraction": round(sample_size / size * 100, 1),
        },
        "comparison": {
            "error": round(error, 2),
            "error_percent": round(error_percent, 2),
            "within_2se": within_se,
        },
        "sampling_distribution": {
            "repeats": len(repeated_means),
            "mean_of_means": round(means_mean, 2),
            "observed_se": round(means_std, 2),
            "theoretical_se": round(theoretical_se, 2),
        },
        "interpretation": (
            f"العيّنة ({sample_size} مصروف = {sample_size / size * 100:.0f}٪ من الداتا) "
            f"دّت متوسط {sample_mean:,.0f} مقابل {population_mean:,.0f} للمجتمع كله — "
            f"فرق {abs(error):,.0f} فقط ({error_percent:.1f}٪). "
            + (
                "الفرق ده جوه حدود الخطأ المعياري المتوقع، يعني العيّنة ممثّلة."
                if within_se
                else "الفرق أكبر من المتوقع — العيّنة دي وقعت في طرف التوزيع."
            )
            + f" ولما كررنا السحب 400 مرة، انحراف المتوسطات طلع {means_std:,.1f} "
            f"والنظري σ/√n = {theoretical_se:,.1f} — الاتنين قريبين، وده الـ CLT بيشتغل."
        ),
    }


# ==================================================================
# المرحلة 7 — فترات الثقة
# ==================================================================
def phase7_confidence(dataset: Dataset) -> dict[str, Any]:
    """المرحلة 7: فترة ثقة 95٪ لمتوسط المصروف، ولمتوسط الصرف اليومي."""
    amounts = dataset.amounts
    daily = list(dataset.daily_totals().values())

    expense_ci = confidence_interval(amounts, CONFIDENCE)
    daily_ci = confidence_interval(daily, CONFIDENCE) if len(daily) > 1 else expense_ci

    # فترات لكل تصنيف كمان
    per_category = []
    for name, group in dataset.by_category().items():
        if len(group) < 2:
            continue
        interval = confidence_interval(group, CONFIDENCE)
        per_category.append(
            {
                "label": CATEGORY_LABELS[name],
                "n": interval["n"],
                "mean": round(interval["mean"], 2),
                "low": round(interval["low"], 2),
                "high": round(interval["high"], 2),
                "margin": round(interval["margin"], 2),
            }
        )

    return {
        "expense_mean": {
            "confidence": 95,
            "n": expense_ci["n"],
            "mean": round(expense_ci["mean"], 2),
            "std": round(expense_ci["std"], 2),
            "standard_error": round(expense_ci["standard_error"], 2),
            "t_critical": round(expense_ci["t_critical"], 3),
            "margin": round(expense_ci["margin"], 2),
            "low": round(expense_ci["low"], 2),
            "high": round(expense_ci["high"], 2),
        },
        "daily_mean": {
            "n": daily_ci["n"],
            "mean": round(daily_ci["mean"], 2),
            "low": round(daily_ci["low"], 2),
            "high": round(daily_ci["high"], 2),
            "margin": round(daily_ci["margin"], 2),
        },
        "per_category": per_category,
        "interpretation": (
            f"فترة الثقة 95٪ لمتوسط المصروف هي "
            f"[{expense_ci['low']:,.0f} — {expense_ci['high']:,.0f}] {CURRENCY}. "
            f"معناها: لو كررنا الدراسة 100 مرة بنفس الطريقة، 95 مرة منهم الفترة "
            f"اللي هتطلع هتكون شايلة المتوسط الحقيقي جواها. "
            f"وهامش الخطأ ±{expected_margin(expense_ci):,.0f} — كل ما جمّعت بيانات أكتر، "
            f"كل ما الهامش ضاق (لأنه بيقسم على √n). "
            f"ومتوسط صرفك اليومي بين {daily_ci['low']:,.0f} و {daily_ci['high']:,.0f}."
        ),
    }


def expected_margin(interval: dict[str, float]) -> float:
    """helper صغير عشان النص يفضل مقروء."""
    return interval["margin"]


def show_p(value: float) -> str:
    """p الصغيرة أوي مبتتكتبش 0.00000 — بتتكتب كده عشان تفضل صادقة."""
    return "< 0.0001" if value < 0.0001 else f"= {value:.5f}"


# ==================================================================
# المرحلة 8 — اختبار الفروض
# ==================================================================
def phase8_hypothesis(
    dataset: Dataset,
    claimed_mean: Optional[float] = None,
    income_per_day: float = 0.0,
    alpha: float = ALPHA,
) -> dict[str, Any]:
    """
    المرحلة 8: اختبار t لعيّنة واحدة.

    السؤال: هل متوسط صرفك اليومي مختلف فعلاً عن الميزانية اليومية اللي
    دخلك بيسمح بيها — ولا الفرق ده مجرد تذبذب عشوائي؟
    """
    # الاختبار بيبقى له معنى لما نقارن بحاجة حقيقية من المشروع:
    # الصرف اليومي الفعلي مقابل الميزانية اليومية اللي دخلك بيسمح بيها.
    daily = list(dataset.daily_totals().values())
    subject = "متوسط الصرف اليومي"

    if claimed_mean:
        values, reference = daily, claimed_mean
    elif income_per_day > 0 and len(daily) >= 3:
        values, reference = daily, income_per_day
    else:
        values, reference = dataset.amounts, round(sum(dataset.amounts) / len(dataset.amounts), -1)
        subject = "متوسط المصروف الواحد"

    result = one_sample_t_test(values, reference, alpha)
    decision = "نرفض H₀" if result["reject_null"] else "نفشل في رفض H₀"

    return {
        "subject": subject,
        "h0": f"H₀: {subject} = {reference:,.0f} {CURRENCY} (μ = μ₀)",
        "h1": f"H₁: {subject} ≠ {reference:,.0f} {CURRENCY} (μ ≠ μ₀)",
        "test": "اختبار t لعيّنة واحدة، ذو طرفين",
        "alpha": alpha,
        "n": result["n"],
        "sample_mean": round(result["sample_mean"], 2),
        "reference": round(reference, 2),
        "std": round(result["std"], 2),
        "standard_error": round(result["standard_error"], 2),
        "t_statistic": round(result["t_statistic"], 4),
        "df": result["df"],
        "t_critical": round(t_critical(result["df"], 1 - alpha), 3),
        "p_value": round(result["p_value"], 6),
        "reject_null": result["reject_null"],
        "decision": decision,
        "conclusion": (
            f"p-value {show_p(result['p_value'])} "
            + (
                f"< α = {alpha} → {decision}. الفرق بين {subject} الفعلي "
                f"({result['sample_mean']:,.0f}) والقيمة المرجعية ({reference:,.0f}) "
                f"فرق حقيقي إحصائياً مش مجرد صدفة."
                if result["reject_null"]
                else f"> α = {alpha} → {decision}. البيانات مش بتدّينا دليل كافي إن "
                f"{subject} الحقيقي مختلف عن {reference:,.0f} — الفرق الملاحظ ممكن يكون صدفة."
            )
        ),
    }


# ==================================================================
# المرحلة 9 — تحليل التباين ANOVA
# ==================================================================
def phase9_anova(dataset: Dataset, alpha: float = ALPHA) -> dict[str, Any]:
    """
    المرحلة 9: ANOVA أحادي الاتجاه على التصنيفات التلاتة.

    السؤال: هل متوسط المصروف بيختلف فعلاً باختلاف التصنيف؟
    """
    groups = {
        CATEGORY_LABELS[name]: values
        for name, values in dataset.by_category().items()
        if len(values) >= 2
    }

    result = one_way_anova(groups, alpha)
    if "error" in result:
        return {"unavailable": result["error"]}

    decision = "نرفض H₀" if result["reject_null"] else "نفشل في رفض H₀"

    # أكبر وأصغر مجموعة (عشان نقول الفرق جاي منين)
    ordered = sorted(result["groups"], key=lambda item: item["mean"], reverse=True)
    highest, lowest = ordered[0], ordered[-1]

    return {
        "h0": "H₀: متوسطات المصروف متساوية في كل التصنيفات (μ₁ = μ₂ = μ₃)",
        "h1": "H₁: على الأقل تصنيف واحد متوسطه مختلف",
        "alpha": alpha,
        "groups": result["groups"],
        "grand_mean": result["grand_mean"],
        "table": {
            "between": {
                "ss": result["ss_between"],
                "df": result["df_between"],
                "ms": result["ms_between"],
            },
            "within": {
                "ss": result["ss_within"],
                "df": result["df_within"],
                "ms": result["ms_within"],
            },
        },
        "f_statistic": result["f_statistic"],
        "p_value": round(result["p_value"], 8),
        "reject_null": result["reject_null"],
        "decision": decision,
        "conclusion": (
            f"F = {result['f_statistic']:.2f} و p-value {show_p(result['p_value'])} "
            + (
                f"< α = {alpha} → {decision}. يعني التصنيف بيفرق فعلاً في حجم المصروف: "
                f"أعلى متوسط عند {highest['name']} ({highest['mean']:,.0f}) "
                f"وأقل متوسط عند {lowest['name']} ({lowest['mean']:,.0f})."
                if result["reject_null"]
                else f"> α = {alpha} → {decision}. مفيش دليل كافي إن متوسطات "
                f"التصنيفات مختلفة — التشتت جوه كل تصنيف أكبر من الفرق بينهم."
            )
        ),
    }


def signed(value: float, digits: int = 1) -> str:
    """
    بتكتب الحد بإشارته الصح: بدل "+ -1360" تطلع "− 1360".
    حاجة صغيرة بس بتفرق في شكل المعادلة قدام اللي بيقرأها.
    """
    sign = "−" if value < 0 else "+"
    return f"{sign} {abs(value):,.{digits}f}"


# ==================================================================
# المرحلة 10 — التفاضل
# ==================================================================
def phase10_calculus(dataset: Dataset, income: float = 0.0) -> dict[str, Any]:
    """
    المرحلة 10: العلاقة بين اليوم والإنفاق التراكمي.

    بنبني الدالة S(t) = الإنفاق التراكمي بعد t يوم، وندرس:
      • المشتقة الأولى S'(t) = معدل الصرف اليومي
      • المشتقة التانية S''(t) = هل المعدل بيتسارع ولا بيهدى؟
      • متى نتوقع الوصول لحد الدخل (حل المعادلة)
    """
    # مهم: الإنفاق التراكمي بيتصفّر كل أول شهر، فلو حسبناه على كل الشهور
    # مع بعض هنطلع بميل غلط. بناخد آخر شهر كامل بس.
    all_daily = dataset.daily_totals()
    months = sorted({day[:7] for day in all_daily})
    if not months:
        return {"unavailable": "مفيش بيانات كفاية لدراسة معدل التغير."}

    target_month = months[-1]
    daily = {day: value for day, value in all_daily.items() if day.startswith(target_month)}

    # لو آخر شهر لسه في أوله، بناخد اللي قبله
    if len(daily) < 5 and len(months) > 1:
        target_month = months[-2]
        daily = {day: value for day, value in all_daily.items() if day.startswith(target_month)}

    if len(daily) < 3:
        return {"unavailable": "محتاجين 3 أيام مختلفة على الأقل لدراسة معدل التغير."}

    days = sorted(daily)
    xs: list[float] = list(range(1, len(days) + 1))

    cumulative: list[float] = []
    running = 0.0
    for day in days:
        running += daily[day]
        cumulative.append(round(running, 2))

    # (أ) خط مستقيم: S(t) = a·t + b، والمشتقة = a (معدل ثابت)
    line = linear_regression(xs, cumulative)

    # (ب) منحنى تربيعي: S(t) = a·t² + b·t + c، والمشتقة = 2a·t + b (معدل متغيّر)
    curve = quadratic_fit(xs, cumulative)

    last_day = xs[-1]
    derivative_now = 2 * curve["a"] * last_day + curve["b"]
    derivative_start = 2 * curve["a"] * xs[0] + curve["b"]
    second_derivative = 2 * curve["a"]

    # (ج) معدل التغير المتوسط والفوري (من التعريف: Δy/Δx)
    average_rate = (cumulative[-1] - cumulative[0]) / (last_day - xs[0]) if last_day > 1 else 0.0

    # (د) متى نوصل للدخل؟ حل a·t² + b·t + c = income
    reach_day: Optional[float] = None
    if income > 0 and curve["a"] != 0:
        a, b, c = curve["a"], curve["b"], curve["c"] - income
        discriminant = b * b - 4 * a * c
        if discriminant >= 0:
            roots = [
                (-b + math.sqrt(discriminant)) / (2 * a),
                (-b - math.sqrt(discriminant)) / (2 * a),
            ]
            future = [root for root in roots if root > 0]
            if future:
                reach_day = round(min(future), 1)
    elif income > 0 and line["slope"] > 0:
        reach_day = round((income - line["intercept"]) / line["slope"], 1)

    trend = (
        "بيتسارع — معدل صرفك اليومي بيزيد مع مرور الشهر"
        if second_derivative > 0.5
        else "بيهدى — معدل صرفك اليومي بيقل مع مرور الشهر"
        if second_derivative < -0.5
        else "ثابت تقريباً — بتصرف بمعدل متساوي"
    )

    return {
        "function": "S(t) = الإنفاق التراكمي بعد t يوم",
        "month": target_month,
        "days": len(days),
        "points": [{"t": x, "s": value} for x, value in zip(xs, cumulative)],
        "linear": {
            "equation": f"S(t) = {line['slope']:,.1f}·t {signed(line['intercept'])}",
            "slope": round(line["slope"], 2),
            "intercept": round(line["intercept"], 2),
            "r_squared": round(line["r_squared"], 4),
            "derivative": f"S'(t) = {line['slope']:,.1f} (معدل ثابت)",
        },
        "quadratic": {
            "equation": (
                f"S(t) = {curve['a']:.3f}·t² {signed(curve['b'], 2)}·t {signed(curve['c'])}"
            ),
            "a": round(curve["a"], 4),
            "b": round(curve["b"], 3),
            "c": round(curve["c"], 2),
            "derivative": f"S'(t) = {2 * curve['a']:.3f}·t {signed(curve['b'], 2)}",
            "second_derivative": round(second_derivative, 4),
        },
        "rates": {
            "average": round(average_rate, 2),
            "at_start": round(derivative_start, 2),
            "at_end": round(derivative_now, 2),
            "change": round(derivative_now - derivative_start, 2),
        },
        "reach_income_day": reach_day,
        "trend": trend,
        "interpretation": (
            f"التحليل على شهر {target_month}. "
            f"دالة الإنفاق التراكمي ميلها {line['slope']:,.0f} {CURRENCY}/يوم "
            f"(R² = {line['r_squared']:.2f} — كل ما قرب من 1 كل ما الخط بيوصف بياناتك أحسن). "
            f"المشتقة الأولى هي معدل صرفك اليومي: بدأت الشهر بـ {derivative_start:,.0f} "
            f"ووصلت لـ {derivative_now:,.0f} في اليوم. "
            f"المشتقة التانية = {second_derivative:.2f}، يعني إنفاقك {trend}."
            + (
                f" وبالمعدل ده متوقع توصل لحد دخلك في اليوم {reach_day:.0f} من الشهر."
                if reach_day
                else ""
            )
        ),
    }


# ==================================================================
# المرحلة 11 — التصوّر البياني
# ==================================================================
def phase11_visuals(dataset: Dataset, phases: dict[str, Any]) -> dict[str, Any]:
    """
    المرحلة 11: بيانات جاهزة للرسم (الواجهة بترسمها SVG).
    كل رسمة معاها السبب اللي اتختارت عشانه.
    """
    by_category = dataset.by_category()
    daily = dataset.daily_totals()
    days = sorted(daily)

    return {
        "bar": {
            "title": "إجمالي الإنفاق حسب التصنيف",
            "why": "المقارنة بين فئات — العمود البياني أوضح حاجة للمقارنة الفئوية",
            "labels": [CATEGORY_LABELS[name] for name in CATEGORIES],
            "values": [round(sum(by_category[name]), 2) for name in CATEGORIES],
        },
        "histogram": {
            "title": "توزيع مبالغ المصاريف",
            "why": "بيوري شكل التوزيع: فين بتتكدس مصاريفك وفين الذيل",
            "bins": phases["phase3"]["frequency"],
        },
        "box": {
            "title": "البوكس بلوت — الأرباع والشواذ",
            "why": "بيلخّص خمس أرقام + بيحدد الشواذ بصرياً في رسمة واحدة",
            "data": phases["phase3"]["box_plot"],
            "outliers": [item["amount"] for item in phases["phase3"]["outliers"]],
        },
        "scatter": {
            "title": "اليوم مقابل إجمالي إنفاقه",
            "why": "بيكشف هل فيه علاقة بين ترتيب اليوم وحجم الصرف",
            "points": [
                {"x": index, "y": round(daily[day], 2)}
                for index, day in enumerate(days, start=1)
            ],
        },
        "line": {
            "title": "الإنفاق التراكمي عبر الشهر",
            "why": "بيوري اتجاه الصرف مع الوقت — وميل الخط هو المشتقة",
            "points": phases["phase10"].get("points", []),
        },
        "interpretation": (
            "الرسومات مختارة بحيث كل واحدة تجاوب على سؤال مختلف: العمود للمقارنة، "
            "الهيستوجرام للشكل، البوكس بلوت للشواذ، الانتشار للعلاقة، والخط للاتجاه."
        ),
    }


# ==================================================================
# المرحلة 12 — النتائج النهائية
# ==================================================================
def phase12_conclusion(phases: dict[str, Any]) -> dict[str, Any]:
    """المرحلة 12: تلخيص كل النتائج في استنتاجات واضحة."""
    descriptive = phases["phase2"]
    distribution = phases["phase3"]
    probability = phases["phase5"]
    sampling = phases["phase6"]
    interval = phases["phase7"]["expense_mean"]
    test = phases["phase8"]
    anova = phases.get("phase9", {})
    calculus = phases.get("phase10", {})

    findings: list[str] = [
        f"متوسط المصروف {descriptive['mean']:,.0f} {CURRENCY} والوسيط "
        f"{descriptive['median']:,.0f}، بمعامل اختلاف {descriptive['cv']}٪.",
        f"التوزيع {distribution['shape']['label']} وفيه "
        f"{distribution['outliers_count']} مصروف شاذ بقاعدة الربيعات.",
        f"احتمال المصروف الكبير {probability['simple'][0]['percent']}٪، "
        f"والقيمة المتوقعة للمصروف الواحد {probability['expected_value']['per_expense']:,.0f}.",
        f"عيّنة من {sampling['sample']['n']} مصروف قدّرت المتوسط بفرق "
        f"{sampling['comparison']['error_percent']}٪ عن المجتمع كله.",
        f"فترة الثقة 95٪ للمتوسط: [{interval['low']:,.0f} — {interval['high']:,.0f}].",
    ]

    statistical: list[dict[str, Any]] = [
        {
            "name": "اختبار t",
            "result": f"t = {test['t_statistic']}, p {show_p(test['p_value'])}",
            "decision": test["decision"],
        }
    ]

    if "f_statistic" in anova:
        statistical.append(
            {
                "name": "ANOVA",
                "result": f"F = {anova['f_statistic']}, p {show_p(anova['p_value'])}",
                "decision": anova["decision"],
            }
        )

    relationships: list[str] = []
    if "linear" in calculus:
        relationships.append(
            f"العلاقة بين اليوم والإنفاق التراكمي خطية بدرجة "
            f"R² = {calculus['linear']['r_squared']} وميل "
            f"{calculus['linear']['slope']:,.0f} {CURRENCY}/يوم."
        )
    if not probability["independence"]["independent"]:
        relationships.append(
            "التصنيف والمبلغ مش مستقلين — نوع المصروف بيأثر على حجمه."
        )

    improvements: list[str] = [
        "جمع بيانات لشهور أكتر عشان اختبارات الفروض تبقى أقوى إحصائياً",
        "إضافة متغيرات جديدة (يوم الأسبوع، طريقة الدفع) لتحليل أعمق",
        "استخدام اختبار Tukey بعد ANOVA لتحديد أي تصنيفين بالظبط مختلفين",
        "بناء نموذج انحدار متعدد للتنبؤ بالمصروف من أكتر من متغيّر",
    ]

    return {
        "findings": findings,
        "statistical_results": statistical,
        "relationships": relationships or ["مفيش علاقات ذات دلالة واضحة في البيانات الحالية."],
        "calculus": calculus.get("interpretation", "—"),
        "conclusion": (
            f"البيانات بتقول إن إنفاقك {distribution['shape']['label']} — "
            f"أغلبه صغير ومتكرر مع صرفات كبيرة نادرة. "
            + (
                "وتحليل التباين أثبت إن التصنيف بيفرق فعلاً في حجم المصروف، "
                if anova.get("reject_null")
                else "وتحليل التباين مالقاش فرق مؤكد بين التصنيفات، "
            )
            + (
                f"وإنفاقك {calculus.get('trend', '')}."
                if calculus.get("trend")
                else ""
            )
            + " التوصية العملية: راقب الذيل — الصرفات الكبيرة النادرة هي اللي "
            "بتكسر الميزانية، مش المصاريف اليومية الصغيرة."
        ),
        "improvements": improvements,
    }


# ==================================================================
# تشغيل الخط كامل
# ==================================================================
def run_pipeline(
    rows: list[dict[str, Any]],
    income: float = 0.0,
    claimed_mean: Optional[float] = None,
) -> dict[str, Any]:
    """
    بتشغّل الـ 12 مرحلة بالترتيب وترجّع النتيجة كلها في dictionary واحدة.
    لو أي مرحلة اتكسرت، بتتسجّل كـ error من غير ما تكسر الباقي.
    """
    dataset, prepared = phase1_prepare(rows)

    phases: dict[str, Any] = {"phase1": prepared}

    # Dictionary of functions: كل مرحلة ودالتها
    steps: list[tuple[str, str, Callable[[], dict[str, Any]]]] = [
        ("phase2", "الإحصاء الوصفي", lambda: phase2_descriptive(dataset)),
        ("phase3", "تحليل التوزيع", lambda: phase3_distribution(dataset)),
        ("phase4", "الجبر الخطي", lambda: phase4_linear_algebra(dataset, income)),
        ("phase5", "الاحتمالات", lambda: phase5_probability(dataset)),
        ("phase6", "المعاينة والاستدلال", lambda: phase6_sampling(dataset)),
        ("phase7", "فترات الثقة", lambda: phase7_confidence(dataset)),
        ("phase8", "اختبار الفروض", lambda: phase8_hypothesis(dataset, claimed_mean, income / 30 if income else 0.0)),
        ("phase9", "تحليل التباين", lambda: phase9_anova(dataset)),
        ("phase10", "التفاضل", lambda: phase10_calculus(dataset, income)),
    ]

    for key, title, function in steps:
        try:
            phases[key] = function()
        except Exception as error:                   # noqa: BLE001
            log.error("Phase %s failed: %s", key, error)
            phases[key] = {"error": f"المرحلة دي وقفت: {error}"}

    phases["phase11"] = phase11_visuals(dataset, phases)
    phases["phase12"] = phase12_conclusion(phases)

    log.info("Pipeline finished on %d rows", len(dataset))

    return {
        "generated_at": date.today().isoformat(),
        "rows": len(dataset),
        "currency": CURRENCY,
        "titles": PHASE_TITLES,
        **phases,
    }


PHASE_TITLES: dict[str, str] = {
    "phase1": "١. جمع البيانات وتجهيزها",
    "phase2": "٢. الإحصاء الوصفي",
    "phase3": "٣. تحليل التوزيع",
    "phase4": "٤. الجبر الخطي",
    "phase5": "٥. الاحتمالات",
    "phase6": "٦. المعاينة والاستدلال",
    "phase7": "٧. فترات الثقة",
    "phase8": "٨. اختبار الفروض",
    "phase9": "٩. تحليل التباين ANOVA",
    "phase10": "١٠. التفاضل",
    "phase11": "١١. التصوّر البياني",
    "phase12": "١٢. النتائج والخلاصة",
}


def rows_from_manager(manager: Any) -> list[dict[str, Any]]:
    """
    بتحوّل مصاريف البرنامج (كل الشهور) لصفوف خام جاهزة للتحليل.
    """
    rows: list[dict[str, Any]] = []
    for budget in manager.months.values():
        for expense in budget.expenses:
            rows.append(
                {
                    "date": expense.created_at,
                    "category": expense.category,
                    "amount": expense.amount,
                    "description": expense.description,
                }
            )
    return rows
