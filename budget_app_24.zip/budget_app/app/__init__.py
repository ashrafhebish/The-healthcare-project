"""
app package - Monthly Budget Manager
كل الموديولات بتاعة المشروع موجودة هنا (Project Organization / Modules).
"""

from .config import APP_NAME, APP_VERSION

__all__ = ["APP_NAME", "APP_VERSION"]
