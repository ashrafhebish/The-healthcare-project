"""
charts.py
---------
الرسومات البيانية للتحليل الإحصائي — بـ Matplotlib.

كل دالة بترسم صورة PNG في فولدر data/charts وترجّع الـ Path بتاعها.
لو matplotlib مش متسطبة، البرنامج بيكمل شغل عادي والواجهة بتعرض
الأرقام من غير رسومات (CHARTS_AVAILABLE = False).

ملحوظة: عناوين الرسومات بالإنجليزي عشان matplotlib مبيرسمش العربي
بشكل سليم من غير مكتبات إضافية (arabic-reshaper / bidi).

بيوضح: Modules, Functions + Type Hints, pathlib, try/except, enumerate, zip
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Optional

from .config import DATA_DIR
from .logger_setup import log
from .stats_engine import normal_pdf, poisson_pmf

# ------------------------------------------------------------------
# BONUS: Matplotlib (اختيارية)
# ------------------------------------------------------------------
try:
    import matplotlib

    matplotlib.use("Agg")          # مفيش شاشة — بنرسم في ملفات
    import matplotlib.pyplot as plt

    CHARTS_AVAILABLE: bool = True
except ImportError:  # pragma: no cover
    plt = None  # type: ignore[assignment]
    CHARTS_AVAILABLE = False


CHARTS_DIR: Path = DATA_DIR / "charts"          # pathlib

# ألوان الواجهة (كحلي + ذهبي) عشان الرسومات تبقى شبه الموقع
NAVY: str = "#0a2136"
GOLD: str = "#e0a54a"
BLUE: str = "#4b9fd6"
GREEN: str = "#3fb883"
RED: str = "#e2645c"
TEXT: str = "#eaf1f8"
MUTED: str = "#91a4b8"


def ensure_charts_dir() -> Path:
    """بتتأكد إن فولدر الرسومات موجود."""
    CHARTS_DIR.mkdir(parents=True, exist_ok=True)
    return CHARTS_DIR


def _new_figure(width: float = 7.2, height: float = 4.0) -> tuple[Any, Any]:
    """بتجهّز لوحة رسم بستايل داكن موحّد."""
    figure, axes = plt.subplots(figsize=(width, height), dpi=130)
    figure.patch.set_facecolor(NAVY)
    axes.set_facecolor(NAVY)
    _style_axes(axes)
    return figure, axes


def _style_axes(axes: Any) -> None:
    """ستايل موحّد لأي محور."""
    axes.tick_params(colors=MUTED, labelsize=8)
    axes.grid(True, color="#ffffff18", linewidth=0.6)
    axes.set_axisbelow(True)
    for spine in axes.spines.values():
        spine.set_color("#ffffff22")
    axes.title.set_color(TEXT)
    axes.xaxis.label.set_color(MUTED)
    axes.yaxis.label.set_color(MUTED)


def _save(figure: Any, name: str) -> Path:
    """بيحفظ الشكل في ملف ويقفل اللوحة عشان الذاكرة."""
    ensure_charts_dir()
    path: Path = CHARTS_DIR / name
    figure.tight_layout()
    figure.savefig(path, facecolor=figure.get_facecolor())
    plt.close(figure)
    log.info("Chart saved: %s", path.name)
    return path


# ==================================================================
# 1) توزيع المصاريف + المنحنى الطبيعي + حدود ±2σ
# ==================================================================
def chart_expense_distribution(anomalies: dict[str, Any], amounts: list[float]) -> Optional[Path]:
    """هيستوجرام لمصاريفك مع منحنى Normal المطابق وحدود القاعدة التجريبية."""
    if not CHARTS_AVAILABLE or not amounts:
        return None

    stats = anomalies["stats"]
    mu: float = float(stats["mean"])
    sigma: float = float(stats["std"]) or 1.0

    figure, axes = _new_figure()
    axes.hist(amounts, bins=min(20, max(6, len(amounts) // 2)),
              density=True, color=BLUE, alpha=0.75, edgecolor=NAVY)

    # منحنى التوزيع الطبيعي المقابل
    low: float = min(amounts) - 2 * sigma
    high: float = max(amounts) + 2 * sigma
    steps: int = 200
    xs: list[float] = [low + (high - low) * index / steps for index in range(steps + 1)]
    ys: list[float] = [normal_pdf(value, mu, sigma) for value in xs]
    axes.plot(xs, ys, color=GOLD, linewidth=2, label="Normal fit")

    axes.axvline(mu, color=TEXT, linestyle="--", linewidth=1.2, label=f"Mean = {mu:,.0f}")
    for sign in (-2, 2):
        axes.axvline(mu + sign * sigma, color=RED, linestyle=":", linewidth=1.2)
    axes.axvline(mu + 2 * sigma, color=RED, linestyle=":", linewidth=1.2, label="±2σ (95%)")

    axes.set_title("Expense Distribution vs. Normal Curve", fontsize=11, fontweight="bold")
    axes.set_xlabel("Expense amount")
    axes.set_ylabel("Density")
    legend = axes.legend(fontsize=8, facecolor=NAVY, edgecolor="#ffffff22")
    for text in legend.get_texts():
        text.set_color(TEXT)

    return _save(figure, "01_expense_distribution.png")


# ==================================================================
# 2) توقّع آخر الشهر (مونت كارلو) + منحنى CLT
# ==================================================================
def chart_forecast(forecast_data: dict[str, Any]) -> Optional[Path]:
    """توزيع 10,000 محاكاة لإجمالي الشهر، مع الدخل وحدود 90٪."""
    samples: list[float] = forecast_data.get("samples", [])
    if not CHARTS_AVAILABLE or len(samples) < 10:
        return None

    figure, axes = _new_figure()
    axes.hist(samples, bins=45, density=True, color=BLUE, alpha=0.7, edgecolor=NAVY)

    # منحنى CLT الطبيعي فوق الهيستوجرام
    mu: float = float(forecast_data["clt_mean"])
    sigma: float = float(forecast_data["clt_std"])
    if sigma > 0:
        low, high = mu - 4 * sigma, mu + 4 * sigma
        xs = [low + (high - low) * index / 200 for index in range(201)]
        axes.plot(xs, [normal_pdf(x, mu, sigma) for x in xs],
                  color=GOLD, linewidth=2, label="CLT normal approx.")

    income: float = float(forecast_data["income"])
    axes.axvline(income, color=RED, linewidth=2, label=f"Income = {income:,.0f}")
    axes.axvline(float(forecast_data["p05"]), color=MUTED, linestyle=":", linewidth=1.2)
    axes.axvline(float(forecast_data["p95"]), color=MUTED, linestyle=":", linewidth=1.2,
                 label="90% interval")
    axes.axvline(float(forecast_data["expected_total"]), color=GREEN, linestyle="--",
                 linewidth=1.6, label="Expected total")

    axes.set_title(
        f"Month-End Forecast — {forecast_data['risk_over_income']}% chance of exceeding income",
        fontsize=11, fontweight="bold",
    )
    axes.set_xlabel("Projected month-end spending")
    axes.set_ylabel("Density")
    legend = axes.legend(fontsize=8, facecolor=NAVY, edgecolor="#ffffff22")
    for text in legend.get_texts():
        text.set_color(TEXT)

    return _save(figure, "02_forecast.png")


# ==================================================================
# 3) بواسون: الفعلي مقابل النظري
# ==================================================================
def chart_poisson(rhythm: dict[str, Any]) -> Optional[Path]:
    """مقارنة عدد عمليات الصرف اليومية الفعلية بتوزيع بواسون."""
    if not CHARTS_AVAILABLE or not rhythm.get("observed_distribution"):
        return None

    observed = rhythm["observed_distribution"]
    lam: float = float(rhythm["lambda"])
    days: int = int(rhythm["days_passed"])

    ks: list[int] = [int(row["k"]) for row in observed]
    actual: list[float] = [float(row["days"]) for row in observed]
    expected: list[float] = [poisson_pmf(k, lam) * days for k in ks]

    figure, axes = _new_figure()
    positions = range(len(ks))
    axes.bar([p - 0.2 for p in positions], actual, width=0.4, color=BLUE, label="Observed days")
    axes.bar([p + 0.2 for p in positions], expected, width=0.4, color=GOLD,
             label=f"Poisson (λ = {lam:.2f})")

    axes.set_xticks(list(positions))
    axes.set_xticklabels([str(k) for k in ks])
    axes.set_title("Daily Number of Expenses — Observed vs. Poisson",
                   fontsize=11, fontweight="bold")
    axes.set_xlabel("Expenses in a day (k)")
    axes.set_ylabel("Number of days")
    legend = axes.legend(fontsize=8, facecolor=NAVY, edgecolor="#ffffff22")
    for text in legend.get_texts():
        text.set_color(TEXT)

    return _save(figure, "03_poisson.png")


# ==================================================================
# 4) نظرية النهاية المركزية على مصاريفك
# ==================================================================
def chart_clt(clt: dict[str, Any]) -> Optional[Path]:
    """المجتمع الأصلي (ملويّ) + توزيع المتوسطات عند أحجام عيّنة مختلفة."""
    if not CHARTS_AVAILABLE or not clt.get("experiments"):
        return None

    experiments = clt["experiments"]
    population: list[float] = clt["population_sample"]

    figure, axes_grid = plt.subplots(1, len(experiments) + 1, figsize=(12.5, 3.2), dpi=130)
    figure.patch.set_facecolor(NAVY)

    first = axes_grid[0]
    first.set_facecolor(NAVY)
    _style_axes(first)
    first.hist(population, bins=12, color=RED, alpha=0.8, edgecolor=NAVY)
    first.set_title("Population\n(your expenses)", fontsize=9, fontweight="bold")

    # zip + enumerate: كل تجربة في خانة
    for index, (axes, experiment) in enumerate(zip(axes_grid[1:], experiments), start=1):
        axes.set_facecolor(NAVY)
        _style_axes(axes)
        axes.hist(experiment["means"], bins=25, color=BLUE, alpha=0.85, edgecolor=NAVY)
        axes.set_title(
            f"n = {experiment['n']}\nSE = {experiment['observed_se']:,.0f}",
            fontsize=9, fontweight="bold",
        )

    figure.suptitle(
        "Central Limit Theorem — sample means become Normal and tighter as n grows",
        color=TEXT, fontsize=11, fontweight="bold",
    )
    return _save(figure, "04_clt.png")


# ==================================================================
# 5) الخطأ المعياري مقابل حجم العيّنة
# ==================================================================
def chart_standard_error(clt: dict[str, Any]) -> Optional[Path]:
    """منحنى SE = σ/√n — كل ما العيّنة تكبر التقدير يبقى أدق."""
    curve = clt.get("se_curve") or []
    if not CHARTS_AVAILABLE or not curve:
        return None

    ns: list[int] = [int(point["n"]) for point in curve]
    ses: list[float] = [float(point["se"]) for point in curve]

    figure, axes = _new_figure(7.2, 3.4)
    axes.plot(ns, ses, marker="o", color=GOLD, linewidth=2, markerfacecolor=TEXT)
    for x_value, y_value in zip(ns, ses):
        axes.annotate(f"{y_value:,.0f}", (x_value, y_value), textcoords="offset points",
                      xytext=(0, 8), ha="center", color=MUTED, fontsize=7)

    axes.set_title("Standard Error vs. Sample Size  (SE = σ / √n)",
                   fontsize=11, fontweight="bold")
    axes.set_xlabel("Sample size (n)")
    axes.set_ylabel("Standard Error")
    return _save(figure, "05_standard_error.png")


# ==================================================================
# 6) احتمال تجاوز الخطة لكل تصنيف
# ==================================================================
def chart_category_risk(forecast_data: dict[str, Any]) -> Optional[Path]:
    """أعمدة أفقية باحتمال تجاوز كل تصنيف لخطته آخر الشهر."""
    rows = forecast_data.get("categories") or []
    if not CHARTS_AVAILABLE or not rows:
        return None

    names: list[str] = [str(row["key"]).title() for row in rows]
    risks: list[float] = [float(row["risk"]) for row in rows]
    colors: list[str] = [GREEN if value < 40 else GOLD if value < 70 else RED for value in risks]

    figure, axes = _new_figure(7.2, 3.0)
    bars = axes.barh(names, risks, color=colors, height=0.55)
    for bar, value in zip(bars, risks):
        axes.text(min(value + 2, 96), bar.get_y() + bar.get_height() / 2,
                  f"{value:.0f}%", va="center", color=TEXT, fontsize=9, fontweight="bold")

    axes.set_xlim(0, 100)
    axes.set_title("Probability of Exceeding Each Category Plan by Month End",
                   fontsize=11, fontweight="bold")
    axes.set_xlabel("Probability (%)")
    return _save(figure, "06_category_risk.png")


# ==================================================================
# توليد كل الرسومات مرة واحدة
# ==================================================================
def build_all_charts(stats: dict[str, Any], amounts: list[float]) -> dict[str, str]:
    """
    بيولّد كل الرسومات المتاحة حسب البيانات الموجودة.
    بيرجّع dictionary: اسم الرسمة → اسم الملف (عشان الويب يعرضها).
    """
    if not CHARTS_AVAILABLE:
        log.warning("Matplotlib not installed — charts skipped")
        return {}

    charts: dict[str, str] = {}

    jobs: list[tuple[str, Any, tuple[Any, ...]]] = [
        ("distribution", chart_expense_distribution, (stats.get("anomalies", {}), amounts)),
        ("forecast", chart_forecast, (stats.get("forecast", {}),)),
        ("category_risk", chart_category_risk, (stats.get("forecast", {}),)),
        ("poisson", chart_poisson, (stats.get("rhythm", {}),)),
        ("clt", chart_clt, (stats.get("clt", {}),)),
        ("standard_error", chart_standard_error, (stats.get("clt", {}),)),
    ]

    for key, function, arguments in jobs:
        section = arguments[0]
        if not isinstance(section, dict) or section.get("unavailable"):
            continue        # القسم ده بياناته مش كفاية → مفيش رسمة
        try:
            path: Optional[Path] = function(*arguments)
        except Exception as error:  # pragma: no cover
            log.exception("Chart %s failed: %s", key, error)
            continue
        if path is not None:
            charts[key] = path.name

    log.info("Generated %d charts", len(charts))
    return charts
