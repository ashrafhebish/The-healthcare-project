"""
storage.py
----------
حفظ وقراءة البيانات.
بيوضح: File Handling (Reading / Writing / JSON) + try/except/finally
       + BONUS: pathlib, CSV Support
"""

import csv
import json
from pathlib import Path
from typing import Any

from .config import CSV_FILE, CSV_HEADERS, DATA_DIR, DATA_FILE
from .exceptions import DataFileError
from .logger_setup import log


def ensure_data_dir() -> Path:
    """بتتأكد إن فولدر data موجود. pathlib"""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    return DATA_DIR


def save_json(data: dict[str, Any], path: Path = DATA_FILE) -> Path:
    """
    Writing Files + JSON Files
    try / except / finally
    """
    ensure_data_dir()
    file_handle = None
    try:
        file_handle = open(path, "w", encoding="utf-8")
        json.dump(data, file_handle, ensure_ascii=False, indent=2)
        log.info("Saved data to %s", path.name)
        return path
    except OSError as error:
        log.error("Failed to save %s: %s", path, error)
        raise DataFileError(str(path), str(error)) from error
    finally:
        if file_handle is not None:
            file_handle.close()   # finally: بنقفل الملف في كل الحالات


def load_json(path: Path = DATA_FILE) -> dict[str, Any]:
    """
    Reading Files + JSON Files
    لو الملف مش موجود بترجّع dictionary فاضية (أول تشغيل).
    """
    if not path.exists():
        log.info("No data file yet at %s", path.name)
        return {}

    try:
        with open(path, "r", encoding="utf-8") as file_handle:
            content: dict[str, Any] = json.load(file_handle)
        log.info("Loaded data from %s", path.name)
        return content
    except json.JSONDecodeError as error:
        log.error("Corrupted JSON in %s: %s", path, error)
        raise DataFileError(str(path), "الملف تالف أو مش JSON صحيح") from error
    except OSError as error:
        raise DataFileError(str(path), str(error)) from error


def export_expenses_csv(expenses: list[Any], path: Path = CSV_FILE) -> Path:
    """
    BONUS: CSV Support — بيصدّر المصاريف في ملف Excel.
    """
    ensure_data_dir()
    try:
        with open(path, "w", encoding="utf-8-sig", newline="") as file_handle:
            writer = csv.writer(file_handle)
            writer.writerow(CSV_HEADERS)     # Tuple كـ header

            # enumerate() مطلوبة في الـ requirements
            for index, expense in enumerate(expenses, start=1):
                writer.writerow(
                    [
                        expense.expense_id,
                        expense.created_at,
                        expense.category,
                        f"{expense.amount:.2f}",
                        expense.description,
                    ]
                )

        log.info("Exported %d expenses to %s", len(expenses), path.name)
        return path
    except OSError as error:
        raise DataFileError(str(path), str(error)) from error


def import_expenses_csv(path: Path = CSV_FILE) -> list[dict[str, Any]]:
    """
    BONUS: CSV Support — بيقرا مصاريف من ملف CSV ويرجّعها list of dicts.
    """
    if not path.exists():
        raise DataFileError(str(path), "الملف مش موجود")

    rows: list[dict[str, Any]] = []
    try:
        with open(path, "r", encoding="utf-8-sig", newline="") as file_handle:
            reader = csv.DictReader(file_handle)
            for row in reader:
                if not row.get("amount"):
                    continue     # continue: بنتخطى السطور الفاضية
                rows.append(
                    {
                        "amount": float(row["amount"]),
                        "category": row.get("category", "needs"),
                        "description": row.get("description", ""),
                    }
                )
        log.info("Imported %d rows from %s", len(rows), path.name)
        return rows
    except (OSError, ValueError) as error:
        raise DataFileError(str(path), str(error)) from error
