"""
logger_setup.py
---------------
BONUS: Logging
بيسجل كل حاجة بتحصل في ملف logs/app.log (مش في الشاشة عشان ميوحشش الـ menu).
"""

import logging
from pathlib import Path

from .config import LOG_DIR, LOG_FILE


def setup_logger(name: str = "budget_app") -> logging.Logger:
    """
    بيجهز الـ logger مرة واحدة ويرجّعه.
    Type Hints + Return Value.
    """
    logger: logging.Logger = logging.getLogger(name)

    # لو اتظبط قبل كده منكررش الـ handlers
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)

    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)  # pathlib
        file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except OSError:
        # لو مقدرناش نكتب ملف، نكمل شغل من غير logging بدل ما البرنامج يقع
        logger.addHandler(logging.NullHandler())

    logger.debug("Logger ready. Log file: %s", Path(LOG_FILE).as_posix())
    return logger


log: logging.Logger = setup_logger()
