"""
models.py
---------
الكلاسات الأساسية للمشروع.
بيوضح: OOP (Classes, Objects, Attributes, Methods, self, __init__, __repr__)
       + BONUS: dataclass, Pydantic
"""

from dataclasses import dataclass, field, asdict
from datetime import date, datetime
from typing import Any, Optional

from .config import (
    CATEGORIES,
    CATEGORY_LABELS,
    CUSTOM_MODE,
    DEFAULT_MODE,
    SPLIT_MODES,
    VALID_CATEGORIES,
    WARNING_THRESHOLD,
)
from .exceptions import (
    ExpenseNotFoundError,
    InvalidAmountError,
    InvalidCategoryError,
)

# ------------------------------------------------------------------
# BONUS: Pydantic
# لو المكتبة متسطبة بنستخدمها في التحقق من المدخلات،
# ولو مش متسطبة البرنامج بيشتغل عادي بتحقق يدوي (عشان ميقعش عند الدكتور).
# ------------------------------------------------------------------
try:
    from pydantic import BaseModel, Field, field_validator

    PYDANTIC_AVAILABLE: bool = True

    class ExpenseInput(BaseModel):
        """Pydantic model للتحقق من بيانات المصروف قبل ما نعملها Expense."""

        amount: float = Field(gt=0, description="المبلغ لازم يكون أكبر من صفر")
        category: str = Field(min_length=3)
        description: str = Field(default="", max_length=100)

        @field_validator("category")
        @classmethod
        def check_category(cls, value: str) -> str:
            normalized: str = value.strip().lower()
            if normalized not in VALID_CATEGORIES:
                raise ValueError(f"category must be one of {sorted(VALID_CATEGORIES)}")
            return normalized

        @field_validator("description")
        @classmethod
        def clean_description(cls, value: str) -> str:
            return value.strip()

except ImportError:  # pragma: no cover
    PYDANTIC_AVAILABLE = False
    ExpenseInput = None  # type: ignore[assignment]


def validate_expense_data(
    amount: Any, category: str, description: str = ""
) -> tuple[float, str, str]:
    """
    بترجع Tuple فيه البيانات بعد التحقق: (amount, category, description)
    بتستخدم Pydantic لو موجودة، وإلا بتتحقق يدوي.
    """
    if PYDANTIC_AVAILABLE:
        try:
            model = ExpenseInput(amount=amount, category=category, description=description)
            return (float(model.amount), model.category, model.description)
        except Exception as error:  # ValidationError
            message: str = str(error).lower()
            if "category" in message:
                raise InvalidCategoryError(str(category)) from error
            raise InvalidAmountError(amount) from error

    # التحقق اليدوي (fallback)
    try:
        value: float = float(amount)
    except (TypeError, ValueError) as error:
        raise InvalidAmountError(amount) from error

    if value <= 0:
        raise InvalidAmountError(amount)

    clean_category: str = str(category).strip().lower()
    if clean_category not in VALID_CATEGORIES:
        raise InvalidCategoryError(clean_category)

    return (value, clean_category, str(description).strip()[:100])


# ------------------------------------------------------------------
# BONUS: Dataclass
# ------------------------------------------------------------------
@dataclass(repr=False)  # قفلنا الـ repr التلقائي عشان نكتب __repr__ بنفسنا
class Expense:
    """مصروف واحد فعلي."""

    expense_id: int
    amount: float
    category: str
    description: str = ""
    created_at: str = field(default_factory=lambda: date.today().isoformat())

    # ---------- Methods ----------
    def label(self) -> str:
        """اسم التصنيف بالعربي."""
        return CATEGORY_LABELS.get(self.category, self.category)

    def to_dict(self) -> dict[str, Any]:
        """تحويل الكائن لـ dictionary عشان نحفظه في JSON."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Expense":
        """بناء Expense من dictionary جاي من ملف JSON."""
        return cls(
            expense_id=int(data["expense_id"]),
            amount=float(data["amount"]),
            category=str(data["category"]),
            description=str(data.get("description", "")),
            created_at=str(data.get("created_at", date.today().isoformat())),
        )

    def __repr__(self) -> str:
        """__repr__ مطلوب في الـ requirements."""
        return (
            f"Expense(id={self.expense_id}, amount={self.amount:.2f}, "
            f"category={self.category!r}, description={self.description!r})"
        )


class MonthlyBudget:
    """
    ميزانية شهر واحد: الدخل + طريقة التقسيم + كل المصاريف بتاعة الشهر ده.
    كلاس عادي (مش dataclass) عشان يبان فيه __init__ و self والـ methods بوضوح.
    """

    def __init__(
        self,
        month: str,
        income: float = 0.0,
        mode: str = DEFAULT_MODE,
        split: Optional[dict[str, float]] = None,
    ) -> None:
        # Attributes
        self.month: str = month                       # مثال: "2026-08"
        self.income: float = float(income)
        self.mode: str = mode
        self.split: dict[str, float] = split or dict(SPLIT_MODES[DEFAULT_MODE])
        self.expenses: list[Expense] = []
        self._next_id: int = 1

    # ---------------- الدخل والتقسيم ----------------
    def set_income(self, income: Any) -> float:
        """بتحدد الدخل الشهري بعد التحقق منه."""
        try:
            value: float = float(income)
        except (TypeError, ValueError) as error:
            raise InvalidAmountError(income) from error

        if value <= 0:
            raise InvalidAmountError(income)

        self.income = value
        return self.income

    def set_mode(self, mode: str, custom: Optional[dict[str, float]] = None) -> dict[str, float]:
        """
        بتغيّر طريقة التقسيم: 50/30/20 أو 60/20/20 أو تقسيم مخصص.
        if / elif / else
        """
        if mode in SPLIT_MODES:
            self.mode = mode
            self.split = dict(SPLIT_MODES[mode])
        elif mode == CUSTOM_MODE and custom:
            total: float = sum(custom.values())
            if round(total, 2) != 100.0 and round(total, 4) != 1.0:
                raise InvalidAmountError(f"نسب التقسيم مجموعها {total} والمفروض 100")
            # لو المستخدم كتب 50 و30 و20 نحولها لكسور
            divisor: float = 100.0 if total > 1.5 else 1.0
            self.mode = CUSTOM_MODE
            self.split = {key: float(custom[key]) / divisor for key in CATEGORIES}
        else:
            raise InvalidCategoryError(mode)

        return self.split

    def allocation(self) -> dict[str, float]:
        """
        الخطة: كل تصنيف يستحق كام جنيه.
        Dictionary Comprehension
        """
        return {name: round(self.income * ratio, 2) for name, ratio in self.split.items()}

    # ---------------- المصاريف ----------------
    def add_expense(self, amount: Any, category: str, description: str = "") -> Expense:
        """بتضيف مصروف جديد وترجّع الكائن بتاعه."""
        clean_amount, clean_category, clean_description = validate_expense_data(
            amount, category, description
        )
        expense = Expense(
            expense_id=self._next_id,
            amount=clean_amount,
            category=clean_category,
            description=clean_description,
            created_at=datetime.now().strftime("%Y-%m-%d"),
        )
        self.expenses.append(expense)
        self._next_id += 1
        return expense

    def remove_expense(self, expense_id: int) -> Expense:
        """بتمسح مصروف بالـ id بتاعه. for loop + break."""
        target: Optional[Expense] = None

        for expense in self.expenses:
            if expense.expense_id != expense_id:
                continue          # continue
            target = expense
            break                 # break

        if target is None:
            from .exceptions import ExpenseNotFoundError

            raise ExpenseNotFoundError(expense_id)

        self.expenses.remove(target)
        return target

    # ---------------- تحويل / تخزين ----------------
    def to_dict(self) -> dict[str, Any]:
        return {
            "month": self.month,
            "income": self.income,
            "mode": self.mode,
            "split": self.split,
            "next_id": self._next_id,
            "expenses": [expense.to_dict() for expense in self.expenses],  # List Comprehension
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MonthlyBudget":
        budget = cls(
            month=str(data.get("month", "")),
            income=float(data.get("income", 0.0)),
            mode=str(data.get("mode", DEFAULT_MODE)),
            split=dict(data.get("split", SPLIT_MODES[DEFAULT_MODE])),
        )
        budget.expenses = [Expense.from_dict(item) for item in data.get("expenses", [])]
        budget._next_id = int(data.get("next_id", len(budget.expenses) + 1))
        return budget

    def __repr__(self) -> str:
        return (
            f"MonthlyBudget(month={self.month!r}, income={self.income:.2f}, "
            f"mode={self.mode!r}, expenses={len(self.expenses)})"
        )

    def __len__(self) -> int:
        """عدد المصاريف — عشان نقدر نعمل len(budget)."""
        return len(self.expenses)


# ثابت مساعد بيتستخدم في التقارير
WARN_AT: float = WARNING_THRESHOLD
