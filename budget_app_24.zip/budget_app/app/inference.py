"""
inference.py
------------
الدوال الرياضية اللي التحليل الإحصائي الشامل محتاجها ومش موجودة في
`stats_engine.py`: توزيع t، وتوزيع F، والدالة اللي بيتحسب منهم الاتنين
(دالة بيتا الناقصة)، والانحدار الخطي بطريقة المربعات الصغرى.

كل حاجة هنا متكتوبة بـ `math` بس — من غير SciPy. NumPy لو متسطبة بتتستخدم
للسرعة في الانحدار، ولو مش موجودة البرنامج بيشتغل عادي.

بيوضح: Functions, Type Hints, try/except, while loop, break, tuples
"""

from __future__ import annotations

import math
from typing import Any, Optional

try:
    import numpy as np
    NUMPY_AVAILABLE: bool = True
except ImportError:
    NUMPY_AVAILABLE = False


# ==================================================================
# 1) دالة بيتا الناقصة (Incomplete Beta) — أساس p-value
# ==================================================================
def _beta_continued_fraction(a: float, b: float, x: float) -> float:
    """
    الكسر المستمر بتاع دالة بيتا الناقصة (طريقة Lentz).
    ده الجزء التقيل اللي بيخلينا نحسب p-value من غير مكتبات.
    """
    tiny: float = 1e-30
    qab: float = a + b
    qap: float = a + 1.0
    qam: float = a - 1.0

    c: float = 1.0
    d: float = 1.0 - qab * x / qap
    if abs(d) < tiny:
        d = tiny
    d = 1.0 / d
    result: float = d

    # while loop + break: بنكرر لحد ما القيمة تستقر
    step: int = 1
    while step <= 300:
        even: int = 2 * step
        numerator: float = step * (b - step) * x / ((qam + even) * (a + even))

        d = 1.0 + numerator * d
        if abs(d) < tiny:
            d = tiny
        c = 1.0 + numerator / c
        if abs(c) < tiny:
            c = tiny
        d = 1.0 / d
        result *= d * c

        numerator = -(a + step) * (qab + step) * x / ((a + even) * (qap + even))
        d = 1.0 + numerator * d
        if abs(d) < tiny:
            d = tiny
        c = 1.0 + numerator / c
        if abs(c) < tiny:
            c = tiny
        d = 1.0 / d
        delta: float = d * c
        result *= delta

        if abs(delta - 1.0) < 3e-16:
            break
        step += 1

    return result


def incomplete_beta(a: float, b: float, x: float) -> float:
    """
    I_x(a, b) — دالة بيتا الناقصة المنظّمة. قيمتها بين 0 و 1.
    منها بنحسب احتمالات t و F.
    """
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0

    front: float = math.exp(
        math.lgamma(a + b)
        - math.lgamma(a)
        - math.lgamma(b)
        + a * math.log(x)
        + b * math.log(1.0 - x)
    )

    # التقارب أسرع من الناحية دي
    if x < (a + 1.0) / (a + b + 2.0):
        return front * _beta_continued_fraction(a, b, x) / a
    return 1.0 - front * _beta_continued_fraction(b, a, 1.0 - x) / b


# ==================================================================
# 2) توزيع t (اختبار الفروض)
# ==================================================================
def t_cdf(t_value: float, df: float) -> float:
    """P(T ≤ t) لتوزيع t بدرجات حرية df."""
    if df <= 0:
        return 0.5
    x: float = df / (df + t_value * t_value)
    tail: float = 0.5 * incomplete_beta(df / 2.0, 0.5, x)
    return 1.0 - tail if t_value > 0 else tail


def t_two_tailed_p(t_value: float, df: float) -> float:
    """p-value للاختبار ذو الطرفين: احتمال نشوف فرق بالحجم ده أو أكبر بالصدفة."""
    if df <= 0:
        return 1.0
    x: float = df / (df + t_value * t_value)
    return min(1.0, incomplete_beta(df / 2.0, 0.5, x))


def t_critical(df: float, confidence: float = 0.95) -> float:
    """
    القيمة الحرجة t* لفترة الثقة (بحث ثنائي، دقة عالية).
    مثال: df = 30 و 95٪ → ≈ 2.042
    """
    if df <= 0:
        return 1.96

    target: float = 1.0 - confidence          # مجموع الطرفين
    low, high = 0.0, 100.0

    for _ in range(200):                      # بحث ثنائي
        middle: float = (low + high) / 2
        if t_two_tailed_p(middle, df) > target:
            low = middle
        else:
            high = middle

    return round((low + high) / 2, 6)


# ==================================================================
# 3) توزيع F (تحليل التباين ANOVA)
# ==================================================================
def f_cdf(f_value: float, df1: float, df2: float) -> float:
    """P(F ≤ f) لتوزيع F بدرجتي حرية."""
    if f_value <= 0 or df1 <= 0 or df2 <= 0:
        return 0.0
    x: float = df1 * f_value / (df1 * f_value + df2)
    return incomplete_beta(df1 / 2.0, df2 / 2.0, x)


def f_p_value(f_value: float, df1: float, df2: float) -> float:
    """p-value لاختبار ANOVA — الذيل الأيمن من توزيع F."""
    return max(0.0, min(1.0, 1.0 - f_cdf(f_value, df1, df2)))


# ==================================================================
# 4) الانحدار الخطي (المربعات الصغرى)
# ==================================================================
def linear_regression(xs: list[float], ys: list[float]) -> dict[str, float]:
    """
    بتلاقي أحسن خط y = a·x + b بيمثّل العلاقة بين متغيرين.

    الميل a هو **معدل التغير**: كل ما x يزيد بواحد، y بيزيد بـ a.
    ودي نفسها المشتقة الأولى للدالة الخطية — أساس مرحلة التفاضل.
    """
    count: int = len(xs)
    if count < 2 or count != len(ys):
        return {"slope": 0.0, "intercept": 0.0, "r": 0.0, "r_squared": 0.0, "n": count}

    mean_x: float = sum(xs) / count
    mean_y: float = sum(ys) / count

    # zip() + sum() + comprehension
    covariance: float = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
    variance_x: float = sum((x - mean_x) ** 2 for x in xs)
    variance_y: float = sum((y - mean_y) ** 2 for y in ys)

    slope: float = covariance / variance_x if variance_x else 0.0
    intercept: float = mean_y - slope * mean_x

    denominator: float = math.sqrt(variance_x * variance_y)
    correlation: float = covariance / denominator if denominator else 0.0

    return {
        "slope": slope,
        "intercept": intercept,
        "r": correlation,
        "r_squared": correlation ** 2,
        "n": count,
    }


def quadratic_fit(xs: list[float], ys: list[float]) -> dict[str, float]:
    """
    بتلاقي منحنى y = a·x² + b·x + c (بيحل معادلات المربعات الصغرى).

    ليه تربيعي؟ عشان المشتقة بتاعته (2a·x + b) **بتتغير مع الوقت** —
    يعني نقدر نقول: معدل صرفك بيتسارع ولا بيهدى.
    """
    count: int = len(xs)
    if count < 3:
        return {"a": 0.0, "b": 0.0, "c": 0.0, "n": count}

    if NUMPY_AVAILABLE:
        a, b, c = np.polyfit(np.array(xs, dtype=float), np.array(ys, dtype=float), 2)
        return {"a": float(a), "b": float(b), "c": float(c), "n": count}

    # مجاميع القوى المطلوبة للمصفوفة الطبيعية
    s0: float = float(count)
    s1: float = sum(xs)
    s2: float = sum(x ** 2 for x in xs)
    s3: float = sum(x ** 3 for x in xs)
    s4: float = sum(x ** 4 for x in xs)

    t0: float = sum(ys)
    t1: float = sum(x * y for x, y in zip(xs, ys))
    t2: float = sum(x * x * y for x, y in zip(xs, ys))

    matrix: list[list[float]] = [[s4, s3, s2, t2], [s3, s2, s1, t1], [s2, s1, s0, t0]]
    solution: Optional[list[float]] = solve_linear_system(matrix)

    if solution is None:
        return {"a": 0.0, "b": 0.0, "c": 0.0, "n": count}

    return {"a": solution[0], "b": solution[1], "c": solution[2], "n": count}


def solve_linear_system(matrix: list[list[float]]) -> Optional[list[float]]:
    """
    حل نظام معادلات خطية بطريقة حذف جاوس (Gaussian Elimination).
    المصفوفة بتيجي موسّعة: كل صف = المعاملات + الناتج.
    """
    size: int = len(matrix)
    rows: list[list[float]] = [list(row) for row in matrix]

    for column in range(size):
        # نختار أكبر عنصر عشان الحساب يبقى مستقر رقمياً (Partial Pivoting)
        pivot_row: int = max(range(column, size), key=lambda index: abs(rows[index][column]))
        if abs(rows[pivot_row][column]) < 1e-12:
            return None

        rows[column], rows[pivot_row] = rows[pivot_row], rows[column]

        for target in range(size):
            if target == column:
                continue
            factor: float = rows[target][column] / rows[column][column]
            for position in range(column, size + 1):
                rows[target][position] -= factor * rows[column][position]

    return [rows[index][size] / rows[index][index] for index in range(size)]


# ==================================================================
# 5) شكل التوزيع
# ==================================================================
def skewness(values: list[float]) -> float:
    """
    معامل الالتواء: موجب = ذيل ناحية اليمين (مصاريف كبيرة نادرة)،
    سالب = ذيل ناحية الشمال، وقريب من صفر = متماثل.
    """
    count: int = len(values)
    if count < 3:
        return 0.0

    mean: float = sum(values) / count
    variance: float = sum((value - mean) ** 2 for value in values) / count
    std: float = math.sqrt(variance)
    if std == 0:
        return 0.0

    return sum(((value - mean) / std) ** 3 for value in values) / count


def kurtosis(values: list[float]) -> float:
    """
    معامل التفلطح الزائد: موجب = ذيول تقيلة (قيم متطرفة أكتر من الطبيعي)،
    وصفر = زي التوزيع الطبيعي بالظبط.
    """
    count: int = len(values)
    if count < 4:
        return 0.0

    mean: float = sum(values) / count
    variance: float = sum((value - mean) ** 2 for value in values) / count
    if variance == 0:
        return 0.0

    return sum(((value - mean) ** 4) for value in values) / (count * variance ** 2) - 3.0


def shape_label(skew: float) -> str:
    """وصف بالعربي لشكل التوزيع حسب الالتواء (if / elif / else)."""
    if skew > 1:
        return "ملتوي بشدة ناحية اليمين"
    elif skew > 0.5:
        return "ملتوي ناحية اليمين"
    elif skew < -1:
        return "ملتوي بشدة ناحية الشمال"
    elif skew < -0.5:
        return "ملتوي ناحية الشمال"
    return "متماثل تقريباً"


# ==================================================================
# 6) اختبارات جاهزة
# ==================================================================
def one_sample_t_test(
    values: list[float], population_mean: float, alpha: float = 0.05
) -> dict[str, Any]:
    """
    اختبار t لعيّنة واحدة: هل متوسط العيّنة يختلف فعلاً عن قيمة مرجعية،
    ولا الفرق ده مجرد صدفة؟
    """
    count: int = len(values)
    if count < 2:
        return {"error": "محتاج قيمتين على الأقل"}

    mean: float = sum(values) / count
    variance: float = sum((value - mean) ** 2 for value in values) / (count - 1)
    std: float = math.sqrt(variance)
    standard_error: float = std / math.sqrt(count) if count else 0.0

    t_statistic: float = (mean - population_mean) / standard_error if standard_error else 0.0
    df: int = count - 1
    p_value: float = t_two_tailed_p(t_statistic, df)

    return {
        "n": count,
        "sample_mean": mean,
        "population_mean": population_mean,
        "std": std,
        "standard_error": standard_error,
        "t_statistic": t_statistic,
        "df": df,
        "p_value": p_value,
        "alpha": alpha,
        "reject_null": p_value < alpha,
    }


def one_way_anova(groups: dict[str, list[float]], alpha: float = 0.05) -> dict[str, Any]:
    """
    تحليل التباين الأحادي: هل متوسطات المجموعات دي مختلفة فعلاً؟

    الفكرة: بنقارن التشتت **بين** المجموعات بالتشتت **جوه** كل مجموعة.
    لو الأول أكبر بكتير (F كبيرة)، يبقى فيه فرق حقيقي.
    """
    usable: dict[str, list[float]] = {
        name: values for name, values in groups.items() if len(values) >= 2
    }

    if len(usable) < 2:
        return {"error": "محتاج مجموعتين على الأقل، كل واحدة فيها قيمتين"}

    all_values: list[float] = [value for values in usable.values() for value in values]
    total_count: int = len(all_values)
    grand_mean: float = sum(all_values) / total_count

    # SSB: التباين بين المجموعات · SSW: التباين جوه المجموعات
    ss_between: float = 0.0
    ss_within: float = 0.0
    group_stats: list[dict[str, Any]] = []

    for name, values in usable.items():
        count: int = len(values)
        mean: float = sum(values) / count
        ss_between += count * (mean - grand_mean) ** 2
        ss_within += sum((value - mean) ** 2 for value in values)

        group_stats.append(
            {
                "name": name,
                "n": count,
                "mean": round(mean, 2),
                "std": round(
                    math.sqrt(sum((value - mean) ** 2 for value in values) / (count - 1)), 2
                ),
            }
        )

    df_between: int = len(usable) - 1
    df_within: int = total_count - len(usable)

    ms_between: float = ss_between / df_between if df_between else 0.0
    ms_within: float = ss_within / df_within if df_within else 0.0

    f_statistic: float = ms_between / ms_within if ms_within else 0.0
    p_value: float = f_p_value(f_statistic, df_between, df_within)

    return {
        "groups": group_stats,
        "grand_mean": round(grand_mean, 2),
        "ss_between": round(ss_between, 2),
        "ss_within": round(ss_within, 2),
        "df_between": df_between,
        "df_within": df_within,
        "ms_between": round(ms_between, 2),
        "ms_within": round(ms_within, 2),
        "f_statistic": round(f_statistic, 4),
        "p_value": p_value,
        "alpha": alpha,
        "reject_null": p_value < alpha,
    }


def confidence_interval(
    values: list[float], confidence: float = 0.95
) -> dict[str, float]:
    """
    فترة ثقة للمتوسط: المدى اللي بنتوقع المتوسط الحقيقي يقع جواه.
    بنستخدم t مش z لأن الانحراف الحقيقي للمجتمع مش معروف.
    """
    count: int = len(values)
    if count < 2:
        return {"low": 0.0, "high": 0.0, "mean": values[0] if values else 0.0, "margin": 0.0}

    mean: float = sum(values) / count
    std: float = math.sqrt(sum((value - mean) ** 2 for value in values) / (count - 1))
    standard_error: float = std / math.sqrt(count)
    critical: float = t_critical(count - 1, confidence)
    margin: float = critical * standard_error

    return {
        "mean": mean,
        "std": std,
        "standard_error": standard_error,
        "t_critical": critical,
        "margin": margin,
        "low": mean - margin,
        "high": mean + margin,
        "confidence": confidence * 100,
        "n": count,
    }
