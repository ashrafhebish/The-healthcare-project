"""
config.py
---------
كل الثوابت والإعدادات بتاعة البرنامج.
بيوضح: Variables, Data Types, Dictionaries, Sets, Tuples, pathlib
"""

from pathlib import Path
from typing import Final

# ---------------- App info (Variables + Strings) ----------------
APP_NAME: Final[str] = "توفير بذكاء"
APP_NAME_EN: Final[str] = "Monthly Budget Manager"
APP_TAGLINE: Final[str] = "قسّم دخلك، سجّل مصاريفك، واعرف التزمت بالخطة ولا لأ"
APP_VERSION: Final[str] = "1.0.0"
AUTHOR: Final[str] = "Your Name Here"

# ---------------- Paths (BONUS: pathlib) ----------------
BASE_DIR: Final[Path] = Path(__file__).resolve().parent.parent
DATA_DIR: Final[Path] = BASE_DIR / "data"
LOG_DIR: Final[Path] = BASE_DIR / "logs"
WEB_DIR: Final[Path] = BASE_DIR / "web" / "static"

DATA_FILE: Final[Path] = DATA_DIR / "budget_data.json"
CSV_FILE: Final[Path] = DATA_DIR / "expenses.csv"
LOG_FILE: Final[Path] = LOG_DIR / "app.log"

# ---------------- التصنيفات الثلاثة ----------------
CATEGORIES: Final[tuple[str, ...]] = ("needs", "wants", "savings")   # Tuple
VALID_CATEGORIES: Final[set[str]] = set(CATEGORIES)                  # Set

CATEGORY_LABELS: Final[dict[str, str]] = {                           # Dictionary
    "needs": "احتياجات",
    "wants": "كماليات",
    "savings": "توفير",
}

# ---------------- طرق التقسيم (زي اللي في التصميم) ----------------
SPLIT_MODES: Final[dict[str, dict[str, float]]] = {
    "50/30/20": {"needs": 0.50, "wants": 0.30, "savings": 0.20},
    "60/20/20": {"needs": 0.60, "wants": 0.20, "savings": 0.20},
}
DEFAULT_MODE: Final[str] = "50/30/20"
CUSTOM_MODE: Final[str] = "custom"

# النسبة اللي لو المستخدم وصلها في تصنيف يطلعله تحذير
WARNING_THRESHOLD: Final[float] = 0.80  # 80%

CURRENCY: Final[str] = "جنيه"

# Tuple: أعمدة ملف الـ CSV (ثابتة ومش بتتغير)
CSV_HEADERS: Final[tuple[str, ...]] = ("id", "date", "category", "amount", "description")

# إعدادات سيرفر الويب
WEB_HOST: Final[str] = "127.0.0.1"
WEB_PORT: Final[int] = 8000


class Color:
    """BONUS: Colored Console Output — ألوان ANSI من غير أي مكتبة خارجية."""

    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"

    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    GREY = "\033[90m"


def paint(text: str, color: str, bold: bool = False) -> str:
    """Function مع Parameters و Return Value و Type Hints — بترجع النص ملوّن."""
    prefix: str = (Color.BOLD + color) if bold else color
    return f"{prefix}{text}{Color.RESET}"
