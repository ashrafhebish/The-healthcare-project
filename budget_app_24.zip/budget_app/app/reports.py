"""
reports.py
----------
تقرير المقارنة الحية وتقرير آخر الشهر.
بيوضح: zip(), enumerate(), List Comprehension, lambda, sorted()
"""

from typing import Any

from .budget_manager import BudgetManager
from .config import CATEGORIES, CATEGORY_LABELS, CURRENCY, Color, paint
from .logger_setup import log


def build_report(manager: BudgetManager) -> dict[str, Any]:
    """
    بترجّع dictionary فيها كل أرقام التقرير.
    الواجهتين (كونسول + ويب) بيستخدموا نفس الدالة دي.
    """
    plan = manager.budget.allocation()
    spent = manager.spent_by_category()
    remaining = manager.remaining_by_category()
    ratios = manager.usage_ratio()

    # BONUS: zip() — بنلزّق أسماء التصنيفات مع أرقامها في صف واحد
    lines: list[dict[str, Any]] = [
        {
            "key": name,
            "label": CATEGORY_LABELS[name],
            "percent_of_income": round(manager.budget.split[name] * 100),
            "planned": planned,
            "spent": used,
            "remaining": left,
            "ratio": ratio,
            "status": _status_of(ratio),
        }
        for name, planned, used, left, ratio in zip(
            CATEGORIES, plan.values(), spent.values(), remaining.values(), ratios.values()
        )
    ]

    report: dict[str, Any] = {
        "month": manager.current_month,
        "income": manager.budget.income,
        "mode": manager.budget.mode,
        "currency": CURRENCY,
        "lines": lines,
        "total_spent": manager.total_spent(),
        "actual_savings": manager.actual_savings(),
        "planned_savings": plan["savings"],
        "on_plan": manager.is_on_plan(),
        "warnings": manager.warnings(),
        "expenses_count": len(manager.budget),
        "top_expenses": [
            {"description": item.description or item.label(), "amount": item.amount}
            for item in manager.top_expenses(3)
        ],
    }

    log.info("Report built for %s (on_plan=%s)", report["month"], report["on_plan"])
    return report


def _status_of(ratio: float) -> str:
    """if / elif / else — حالة التصنيف."""
    if ratio > 1.0:
        return "over"      # عدّى الخطة
    elif ratio >= 0.8:
        return "near"      # قرب يخلص
    else:
        return "ok"        # تمام


def format_report_text(report: dict[str, Any], width: int = 60) -> str:
    """
    نفس التقرير بس كنص ملوّن للكونسول.
    enumerate() + Strings formatting
    """
    currency: str = report["currency"]
    parts: list[str] = []

    parts.append(paint("=" * width, Color.GREY))
    parts.append(paint(f"  تقرير شهر {report['month']}  |  طريقة التقسيم {report['mode']}", Color.CYAN, bold=True))
    parts.append(paint("=" * width, Color.GREY))
    parts.append(f"  الدخل الشهري : {report['income']:.2f} {currency}")
    parts.append(f"  إجمالي المصروف: {report['total_spent']:.2f} {currency}")
    parts.append(paint("-" * width, Color.GREY))

    # enumerate() لترقيم البنود
    for index, line in enumerate(report["lines"], start=1):
        bar: str = _progress_bar(line["ratio"])
        color: str = {"ok": Color.GREEN, "near": Color.YELLOW, "over": Color.RED}[line["status"]]
        header: str = f"  {index}. {line['label']} ({line['percent_of_income']}٪)"
        numbers: str = (
            f"الخطة {line['planned']:.0f} | صرفت {line['spent']:.0f} | "
            f"باقي {line['remaining']:.0f}"
        )
        parts.append(paint(header, color, bold=True))
        parts.append(f"     {bar} {line['ratio'] * 100:5.1f}٪")
        parts.append(paint(f"     {numbers}", Color.GREY))

    parts.append(paint("-" * width, Color.GREY))

    if report["on_plan"]:
        parts.append(paint("  ✔ ملتزم بالخطة", Color.GREEN, bold=True))
    else:
        parts.append(paint("  ✘ خرجت عن الخطة في تصنيف أو أكتر", Color.RED, bold=True))

    saved: float = report["actual_savings"]
    target: float = report["planned_savings"]
    saved_color: str = Color.GREEN if saved >= target else Color.YELLOW
    parts.append(
        paint(f"  وفّرت فعلياً {saved:.2f} {currency} من أصل {target:.2f}", saved_color)
    )

    for warning in report["warnings"]:
        icon: str = "⚠" if warning["level"] == "warning" else "✖"
        warn_color: str = Color.YELLOW if warning["level"] == "warning" else Color.RED
        parts.append(paint(f"  {icon} {warning['message']}", warn_color))

    parts.append(paint("=" * width, Color.GREY))
    return "\n".join(parts)


def _progress_bar(ratio: float, size: int = 20) -> str:
    """شريط تقدم نصّي بسيط."""
    filled: int = min(int(ratio * size), size)
    empty: int = size - filled
    return "█" * filled + "░" * empty


# ==================================================================
# التقرير الإحصائي (التوزيعات الاحتمالية) في الكونسول
# ==================================================================
def format_stats_text(stats: dict[str, Any], width: int = 60) -> str:
    """
    بيحوّل مخرجات stats_engine.build_stats_report لنص ملوّن للكونسول.
    كل قسم بياناته مش كفاية بيتعرض كسطر رمادي بدل ما يختفي.
    """
    parts: list[str] = []

    def title(text: str) -> None:
        parts.append("")
        parts.append(paint(f"  ▸ {text}", Color.CYAN, bold=True))
        parts.append(paint("  " + "─" * (width - 4), Color.GREY))

    def skipped(section: dict[str, Any]) -> bool:
        if section.get("unavailable"):
            parts.append(paint(f"     {section['unavailable']}", Color.GREY))
            return True
        return False

    parts.append(paint("=" * width, Color.GREY))
    parts.append(
        paint(f"  التحليل الإحصائي — شهر {stats['month']}", Color.YELLOW, bold=True)
    )
    engine: str = "NumPy" if stats.get("numpy") else "بايثون الأساسية"
    parts.append(paint(f"  المحرك: {engine}  |  {stats['generated_at']}", Color.GREY))
    parts.append(paint("=" * width, Color.GREY))

    # ---------- 1. توقّع آخر الشهر ----------
    forecast = stats.get("forecast", {})
    title("توقّع آخر الشهر (مونت كارلو + CLT)")
    if not skipped(forecast):
        risk: float = forecast["risk_over_income"]
        risk_color: str = Color.GREEN if risk < 30 else Color.YELLOW if risk < 60 else Color.RED
        parts.append(
            f"     عدّى من الشهر {forecast['days_passed']} يوم، فاضل "
            f"{forecast['days_remaining']} يوم"
        )
        parts.append(
            f"     متوسط صرفك اليومي: {forecast['daily_mean']:,.0f} "
            f"± {forecast['daily_std']:,.0f}"
        )
        parts.append(
            paint(
                f"     المتوقع تخلّص الشهر على: {forecast['expected_total']:,.0f}",
                Color.WHITE,
                bold=True,
            )
        )
        parts.append(
            f"     نطاق 90٪: من {forecast['p05']:,.0f} إلى {forecast['p95']:,.0f}"
        )
        parts.append(
            paint(f"     احتمال تعدّي دخلك: {risk:.1f}٪", risk_color, bold=True)
        )
        parts.append(
            paint(
                f"     (تقريب CLT: {forecast['clt_mean']:,.0f} ± "
                f"{forecast['clt_std']:,.0f} → {forecast['clt_risk']:.1f}٪)",
                Color.GREY,
            )
        )
        for row in forecast["categories"]:
            row_color = (
                Color.GREEN if row["risk"] < 40 else Color.YELLOW if row["risk"] < 70 else Color.RED
            )
            parts.append(
                paint(
                    f"     • {row['label']:<10} احتمال تجاوز الخطة {row['risk']:>5.1f}٪",
                    row_color,
                )
            )

    # ---------- 2. المصاريف الشاذة ----------
    anomalies = stats.get("anomalies", {})
    title("المصاريف الشاذة (Z-Score)")
    if not skipped(anomalies):
        info = anomalies["stats"]
        normal = anomalies["normal_range"]
        parts.append(
            f"     متوسط المصروف {info['mean']:,.0f} وانحراف معياري {info['std']:,.0f}"
        )
        parts.append(
            f"     المدى الطبيعي (±2σ): من {normal['low']:,.0f} إلى {normal['high']:,.0f}"
        )

        observed = anomalies["empirical_rule"]["observed"]
        parts.append(
            paint(
                f"     القاعدة التجريبية — عندك: 1σ={observed['1σ']}٪ "
                f"2σ={observed['2σ']}٪ 3σ={observed['3σ']}٪  "
                f"(المتوقع 68 / 95 / 99.7)",
                Color.GREY,
            )
        )

        if not anomalies["flagged"]:
            parts.append(paint("     ✔ مفيش أي مصروف شاذ — كل حاجة في المدى الطبيعي", Color.GREEN))
        else:
            for index, item in enumerate(anomalies["flagged"][:5], start=1):
                parts.append(
                    paint(f"     {index}. {item['message']}  (Z = {item['z']:+.2f})", Color.RED)
                )

    # ---------- 3. إيقاع الصرف ----------
    rhythm = stats.get("rhythm", {})
    title("إيقاع الصرف (Poisson + Exponential)")
    if not skipped(rhythm):
        parts.append(
            f"     بتصرف في المتوسط {rhythm['lambda']:.2f} مرة في اليوم "
            f"({rhythm['expenses_count']} عملية في {rhythm['days_passed']} يوم)"
        )
        parts.append(f"     احتمال يعدّي يوم من غير أي صرف: {rhythm['no_spend_day']}٪")
        parts.append(
            f"     متوسط المدة بين الصرفة والتانية: {rhythm['mean_gap_days']} يوم — "
            f"احتمال تصرف خلال 24 ساعة: {rhythm['within_1_day']}٪"
        )

    # ---------- 3.5 إيقاع الشهر ----------
    pace = stats.get("pace", {})
    title("إيقاع الشهر (Gamma + Uniform + SE)")
    if not skipped(pace):
        interval = pace["confidence_interval"]
        parts.append(
            f"     متوسط صرفك اليومي: {pace['daily_mean']:,.0f} "
            f"(خطأ معياري {pace['standard_error']:,.0f})"
        )
        parts.append(
            f"     فترة ثقة 95٪ للمتوسط اليومي: من {interval[0]:,.0f} إلى {interval[1]:,.0f}"
        )
        parts.append(
            f"     انتظام الصرف مقارنة بالتوزيع المنتظم: {pace['evenness']:.0f}٪ "
            f"(أكبر يوم أخد {pace['busiest_share']:.0f}٪ من صرف الشهر)"
        )
        for row in pace["categories"]:
            if row.get("expected_days") is None:
                parts.append(
                    paint(f"     • {row['label']:<10} {row['status']}", Color.GREY)
                )
                continue
            row_color = (
                Color.GREEN if row["risk_before_month_end"] < 40
                else Color.YELLOW if row["risk_before_month_end"] < 70
                else Color.RED
            )
            date_note: str = f" (حوالي {row['expected_date']})" if row["expected_date"] else ""
            parts.append(
                paint(
                    f"     • {row['label']:<10} متوقع تخلص بعد {row['expected_days']:>5.1f} يوم"
                    f"{date_note} — احتمال قبل نهاية الشهر "
                    f"{row['risk_before_month_end']:.0f}٪",
                    row_color,
                )
            )

    # ---------- 4. الالتزام بالخطة ----------
    commitment = stats.get("commitment", {})
    title("التزامك بالخطة (Binomial + Beta + Geometric)")
    if not skipped(commitment):
        parts.append(
            f"     التزمت في {commitment['successes']} شهر من {commitment['trials']} "
            f"({commitment['p_hat']}٪)"
        )
        interval = commitment["credible_interval"]
        parts.append(
            f"     تقدير Beta لمعدل التزامك: {commitment['beta_estimate']}٪ "
            f"(فترة ثقة 90٪: {interval[0]}٪ – {interval[1]}٪)"
        )
        parts.append(
            paint(
                f"     احتمال تلتزم في شهرين على الأقل من الـ{commitment['horizon']} "
                f"الجايين: {commitment['at_least_two']}٪",
                Color.CYAN,
            )
        )
        if commitment["expected_months_until_slip"]:
            parts.append(
                f"     متوسط عدد الشهور لحد أول مرة تخرج عن الخطة: "
                f"{commitment['expected_months_until_slip']} شهر"
            )

    # ---------- 5. CLT ----------
    clt = stats.get("clt", {})
    title("نظرية النهاية المركزية على مصاريفك")
    if not skipped(clt):
        parts.append(
            paint(f"     {'n':>4} {'متوسط المتوسطات':>18} {'SE فعلي':>10} {'SE نظري':>10}", Color.GREY)
        )
        for experiment in clt["experiments"]:
            parts.append(
                f"     {experiment['n']:>4} {experiment['mean_of_means']:>18,.0f} "
                f"{experiment['observed_se']:>10,.0f} {experiment['theoretical_se']:>10,.0f}"
            )
        parts.append(
            paint(
                "     كل ما n كبرت، توزيع المتوسطات قرب من الطبيعي وضاق (SE = σ/√n).",
                Color.GREY,
            )
        )

    parts.append(paint("=" * width, Color.GREY))
    return "\n".join(parts)


# ==================================================================
# القسم التعليمي في الكونسول — رسم المنحنى بالحروف
# ==================================================================
def sparkline(points: list[dict[str, float]], height: int = 8, width: int = 48) -> list[str]:
    """
    رسم منحنى التوزيع في الترمينال من غير أي مكتبة رسم.
    بياخد نقاط (x, y) ويطلّع أعمدة بالحروف — نفس شكل الـ PMF/PDF.
    """
    if not points:
        return []

    values: list[float] = [float(point["y"]) for point in points]
    peak: float = max(values) or 1.0

    # لو النقاط أكتر من عرض الشاشة بناخد عيّنة منها
    step: int = max(1, len(values) // width)
    sampled: list[float] = values[::step][:width]

    rows: list[str] = []
    for level in range(height, 0, -1):
        cutoff: float = peak * level / height
        row: str = "".join("█" if value >= cutoff else " " for value in sampled)
        rows.append("   │" + row)

    rows.append("   └" + "─" * len(sampled))
    return rows


def format_distribution_text(info: dict[str, Any], personal: str = "") -> str:
    """صفحة توزيع واحد في الكونسول: الشرح + المعادلة + المنحنى."""
    parts: list[str] = []
    kind: str = "متقطع" if info["kind"] == "discrete" else "متصل"

    parts.append("")
    parts.append(paint(f"  {info['name']} — {info['name_en']}  ({kind})", Color.YELLOW, bold=True))
    parts.append(paint(f"  {info['question']}", Color.WHITE))
    parts.append(paint(f"  {info['formula']}", Color.CYAN))
    parts.append("")
    parts.append(paint(f"  في البرنامج: {info['in_app']}", Color.GREY))
    parts.append(paint(f"  مثال: {info['example']}", Color.GREY))

    if personal:
        parts.append(paint(f"  على بياناتك: {personal}", Color.GREEN))

    parts.append("")
    parts.append(paint(f"  منحنى الـ {info['function']}:", Color.GREY))
    parts.extend(paint(row, Color.MAGENTA) for row in sparkline(info["points"]))

    params: str = " · ".join(f"{key} = {value}" for key, value in info["params"].items())
    parts.append(paint(f"   المعاملات: {params}", Color.GREY))
    parts.append(
        paint(
            f"   المتوسط = {info['mean']:,.3f}   |   الانحراف المعياري = {info['std']:,.3f}",
            Color.WHITE,
        )
    )
    return "\n".join(parts)


# ===================================================================
# التحليل الإحصائي الشامل (12 مرحلة) — عرض في الكونسول
# ===================================================================
def format_pipeline_text(result: dict[str, Any], width: int = 60) -> str:
    """
    بتحوّل نتيجة `analysis.run_pipeline()` لنص منسّق للترمينال.
    كل مرحلة بتتعرض بعنوانها وأهم أرقامها والتفسير بتاعها.
    """
    lines: list[str] = []
    titles: dict[str, str] = result.get("titles", {})

    def header(text: str) -> None:
        lines.append("")
        lines.append(paint("  " + "─" * (width - 4), Color.GREY))
        lines.append(paint(f"  {text}", Color.CYAN, bold=True))

    def row(label: str, value: Any) -> None:
        lines.append(f"    {label:.<32} {value}")

    def explain(text: str) -> None:
        """التفسير بيتلف على السطر عشان ميخرجش بره الشاشة."""
        lines.append("")
        for chunk in _wrap_arabic(text, width - 6):
            lines.append(paint(f"    {chunk}", Color.WHITE))

    lines.append("")
    lines.append(paint(f"  التحليل الإحصائي الشامل — {result['rows']} صف", Color.YELLOW, bold=True))

    # ---------- 1 ----------
    phase = result["phase1"]
    header(titles.get("phase1", "المرحلة 1"))
    row("صفوف خام", phase["raw_rows"])
    row("صفوف نضيفة", phase["clean_rows"])
    row("اتشال", phase["dropped_total"])
    for reason, count in phase["dropped_detail"].items():
        row(f"  ↳ {reason}", count)
    explain(phase["interpretation"])

    # ---------- 2 ----------
    phase = result["phase2"]
    header(titles.get("phase2", "المرحلة 2"))
    for label, key in (
        ("المتوسط", "mean"), ("الوسيط", "median"), ("المدى", "range"),
        ("التباين", "variance"), ("الانحراف المعياري", "std"),
        ("Q1", "q1"), ("Q3", "q3"), ("المدى الربيعي", "iqr"),
    ):
        row(label, f"{phase[key]:,.2f}")
    row("المنوال", f"{phase['mode']['value']:,.0f} ({phase['mode']['range']})")
    explain(phase["interpretation"])

    # ---------- 3 ----------
    phase = result["phase3"]
    header(titles.get("phase3", "المرحلة 3"))
    lines.append("")
    lines.append(_ascii_histogram(phase["frequency"]))
    row("الالتواء", phase["shape"]["skewness"])
    row("التفلطح", phase["shape"]["kurtosis"])
    row("الشكل", phase["shape"]["label"])
    row("عدد الشواذ", phase["outliers_count"])
    explain(phase["interpretation"])

    # ---------- 4 ----------
    phase = result["phase4"]
    header(titles.get("phase4", "المرحلة 4"))
    row("متجه الإنفاق", phase["spend_vector"])
    row("متجه الأوزان", phase["weight_vector"])
    row("الضرب النقطي", f"{phase['dot_product']:,.2f}")
    row("طول المتجه", f"{phase['magnitude']:,.2f}")
    row("الزاوية عن الخطة", f"{phase['alignment']['angle_degrees']}°")
    row("شكل المصفوفة", phase["matrix"]["shape"])
    explain(phase["interpretation"])

    # ---------- 5 ----------
    phase = result["phase5"]
    header(titles.get("phase5", "المرحلة 5"))
    for item in phase["simple"] + phase["conditional"]:
        row(f"{item['notation']} {item['event']}", f"{item['percent']}%")
    row("E(X) للمصروف", f"{phase['expected_value']['per_expense']:,.2f}")
    row("E(X) لليوم", f"{phase['expected_value']['per_day']:,.2f}")
    explain(phase["interpretation"])

    # ---------- 6 ----------
    phase = result["phase6"]
    header(titles.get("phase6", "المرحلة 6"))
    row("المجتمع n", phase["population"]["n"])
    row("متوسط المجتمع", f"{phase['population']['mean']:,.2f}")
    row("العيّنة n", phase["sample"]["n"])
    row("متوسط العيّنة", f"{phase['sample']['mean']:,.2f}")
    row("الخطأ المعياري", f"{phase['sample']['standard_error']:,.2f}")
    row("نسبة الخطأ", f"{phase['comparison']['error_percent']}%")
    explain(phase["interpretation"])

    # ---------- 7 ----------
    phase = result["phase7"]["expense_mean"]
    header(titles.get("phase7", "المرحلة 7"))
    row("مستوى الثقة", f"{phase['confidence']}%")
    row("المتوسط", f"{phase['mean']:,.2f}")
    row("t الحرجة", phase["t_critical"])
    row("هامش الخطأ", f"± {phase['margin']:,.2f}")
    row("الفترة", f"[{phase['low']:,.2f} — {phase['high']:,.2f}]")
    explain(result["phase7"]["interpretation"])

    # ---------- 8 ----------
    phase = result["phase8"]
    header(titles.get("phase8", "المرحلة 8"))
    lines.append(paint(f"    {phase['h0']}", Color.YELLOW))
    lines.append(paint(f"    {phase['h1']}", Color.YELLOW))
    lines.append("")
    row("α", phase["alpha"])
    row("t", phase["t_statistic"])
    row("df", phase["df"])
    row("t الحرجة", f"± {phase['t_critical']}")
    row("p-value", _format_p(phase["p_value"]))
    lines.append("")
    lines.append(paint(f"    ← {phase['decision']}",
                       Color.GREEN if phase["reject_null"] else Color.GREY, bold=True))
    explain(phase["conclusion"])

    # ---------- 9 ----------
    phase = result["phase9"]
    header(titles.get("phase9", "المرحلة 9"))
    if phase.get("unavailable"):
        explain(phase["unavailable"])
    else:
        lines.append(paint(f"    {phase['h0']}", Color.YELLOW))
        lines.append(paint(f"    {phase['h1']}", Color.YELLOW))
        lines.append("")
        for group in phase["groups"]:
            row(f"{group['name']} (n={group['n']})", f"متوسط {group['mean']:,.2f}")
        row("SS بين", f"{phase['table']['between']['ss']:,.2f}")
        row("SS داخل", f"{phase['table']['within']['ss']:,.2f}")
        row("F", phase["f_statistic"])
        row("p-value", _format_p(phase["p_value"]))
        lines.append("")
        lines.append(paint(f"    ← {phase['decision']}",
                           Color.GREEN if phase["reject_null"] else Color.GREY, bold=True))
        explain(phase["conclusion"])

    # ---------- 10 ----------
    phase = result["phase10"]
    header(titles.get("phase10", "المرحلة 10"))
    if phase.get("unavailable"):
        explain(phase["unavailable"])
    else:
        row("الشهر", phase["month"])
        row("الدالة", phase["linear"]["equation"])
        row("المشتقة", phase["linear"]["derivative"])
        row("R²", phase["linear"]["r_squared"])
        row("المشتقة الثانية", phase["quadratic"]["second_derivative"])
        row("معدل أول الشهر", f"{phase['rates']['at_start']:,.2f}/يوم")
        row("معدل آخر الشهر", f"{phase['rates']['at_end']:,.2f}/يوم")
        explain(phase["interpretation"])

    # ---------- 12 ----------
    phase = result["phase12"]
    header(titles.get("phase12", "المرحلة 12"))
    for index, finding in enumerate(phase["findings"], start=1):
        for chunk in _wrap_arabic(f"{index}. {finding}", width - 6):
            lines.append(f"    {chunk}")
        lines.append("")
    explain(phase["conclusion"])
    lines.append("")
    lines.append(paint("    تطويرات مستقبلية:", Color.CYAN))
    for item in phase["improvements"]:
        lines.append(f"      • {item}")

    lines.append("")
    return "\n".join(lines)


def _format_p(value: float) -> str:
    """p الصغيرة أوي بتتكتب كده بدل 0.0"""
    return "< 0.0001" if value < 0.0001 else f"{value:.4f}"


def _wrap_arabic(text: str, width: int) -> list[str]:
    """لف النص على عرض الشاشة من غير ما يقطع كلمة."""
    words = text.split()
    lines: list[str] = []
    current = ""

    for word in words:
        if len(current) + len(word) + 1 <= width:
            current = f"{current} {word}".strip()
        else:
            lines.append(current)
            current = word

    if current:
        lines.append(current)
    return lines


def _ascii_histogram(bins: list[dict[str, Any]], height: int = 8) -> str:
    """هيستوجرام بالرموز للترمينال."""
    counts = [bin_data["count"] for bin_data in bins]
    peak = max(counts) or 1
    rows: list[str] = []

    for level in range(height, 0, -1):
        threshold = peak * level / height
        row = "".join("██" if count >= threshold else "  " for count in counts)
        rows.append(f"    │{row}")

    rows.append("    └" + "──" * len(counts))
    rows.append(f"     {bins[0]['start']:,.0f}" + " " * max(len(counts) * 2 - 12, 1) + f"{bins[-1]['end']:,.0f}")
    return "\n".join(rows)
