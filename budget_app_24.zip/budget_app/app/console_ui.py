"""
console_ui.py
-------------
الواجهة النصية.
بيوضح: while loop, break, continue, if/elif/else, enumerate(), try/except
       + BONUS: Professional Console Menu, Colored Console Output
"""

import csv
from typing import Any, Callable, Optional

from .budget_manager import BudgetManager
from .config import (
    APP_NAME,
    DATA_DIR,
    APP_TAGLINE,
    APP_VERSION,
    CATEGORIES,
    CATEGORY_LABELS,
    CURRENCY,
    CUSTOM_MODE,
    SPLIT_MODES,
    Color,
    paint,
)
from .charts import CHARTS_AVAILABLE, CHARTS_DIR, build_all_charts
from .analysis import run_pipeline, rows_from_manager
from .exceptions import BudgetError
from .logger_setup import log
from .reports import (
    build_report,
    format_pipeline_text,
    format_report_text,
    format_stats_text,
)
from .stats_engine import build_stats_report, clt_lab, expense_amounts, z_score_of
from .storage import export_expenses_csv, import_expenses_csv, load_json, save_json

WIDTH: int = 60

# قائمة الأوامر: list of tuples (Tuples + Lists)
MENU_ITEMS: list[tuple[str, str]] = [
    ("تحديد الدخل وطريقة التقسيم", "set_income"),
    ("عرض الخطة (50/30/20)", "show_plan"),
    ("تسجيل مصروف جديد", "add_expense"),
    ("عرض كل المصاريف", "list_expenses"),
    ("تعديل مصروف", "update_expense"),
    ("حذف مصروف", "delete_expense"),
    ("بحث في المصاريف", "search"),
    ("تقرير الشهر", "report"),
    ("التحليل الإحصائي (توقعات وشذوذ)", "stats"),
    ("تقييم مصروف قبل ما تصرفه", "check_expense"),
    ("التحليل الإحصائي الشامل (12 مرحلة)", "pipeline"),
    ("توليد الرسومات البيانية", "charts"),
    ("حفظ البيانات", "save"),
    ("تصدير CSV", "export"),
    ("استيراد CSV", "import"),
    ("خروج", "exit"),
]


# ---------------------------------------------------------------
# أدوات مساعدة للعرض
# ---------------------------------------------------------------
def line(char: str = "─") -> str:
    return paint(char * WIDTH, Color.GREY)


def header() -> None:
    print()
    print(paint("╔" + "═" * (WIDTH - 2) + "╗", Color.YELLOW))
    print(paint(f"║{APP_NAME.center(WIDTH - 4)}  ║", Color.YELLOW, bold=True))
    print(paint(f"║{APP_TAGLINE.center(WIDTH - 6)}    ║", Color.GREY))
    print(paint("╚" + "═" * (WIDTH - 2) + "╝", Color.YELLOW))


def show_menu(manager: BudgetManager) -> None:
    """عرض القائمة. enumerate() للترقيم."""
    print()
    print(line())
    status: str = f" الشهر: {manager.current_month} | الدخل: {manager.budget.income:.0f} {CURRENCY} | مصاريف: {len(manager.budget)}"
    print(paint(status, Color.CYAN))
    print(line())

    for index, (title, _key) in enumerate(MENU_ITEMS, start=1):
        number: str = paint(f"[{index:>2}]", Color.YELLOW, bold=True)
        print(f" {number} {title}")

    print(line())


def ask(prompt: str) -> str:
    """
    قراءة نص من المستخدم.
    try/except: لو المدخلات خلصت (تشغيل بـ pipe أو Ctrl+D) بنرجّع "خروج"
    بدل ما البرنامج يقع بـ Traceback قدام الدكتور.
    """
    try:
        return input(paint(f" ‹ {prompt}: ", Color.WHITE)).strip()
    except EOFError:
        print()
        return "exit"


def ask_number(prompt: str, allow_empty: bool = False) -> Optional[float]:
    """
    while loop + try/except + break + continue
    بتفضل تسأل لحد ما يدخل رقم صحيح.
    """
    while True:
        raw: str = ask(prompt)

        if not raw and allow_empty:
            return None

        try:
            value: float = float(raw)
        except ValueError:
            print(paint("   لازم تكتب رقم. جرّب تاني.", Color.RED))
            continue          # continue

        if value <= 0:
            print(paint("   الرقم لازم يكون أكبر من صفر.", Color.RED))
            continue

        return value          # الخروج من اللوب


def ask_category() -> str:
    """اختيار تصنيف من الثلاثة."""
    while True:
        print(paint("   التصنيفات:", Color.GREY))
        for index, name in enumerate(CATEGORIES, start=1):
            print(f"     {index}. {CATEGORY_LABELS[name]} ({name})")

        choice: str = ask("اختار رقم التصنيف")

        if choice.isdigit() and 1 <= int(choice) <= len(CATEGORIES):
            return CATEGORIES[int(choice) - 1]

        print(paint("   اختيار غلط، جرّب تاني.", Color.RED))


def print_expenses_table(expenses: list[Any]) -> None:
    """جدول المصاريف. enumerate()"""
    if not expenses:
        print(paint("   مفيش مصاريف مسجلة لسه. ابدأ بتسجيل أول مصروف.", Color.GREY))
        return

    print(line())
    print(paint(f" {'#':<3} {'ID':<4} {'التاريخ':<12} {'التصنيف':<10} {'المبلغ':>10}  الوصف", Color.CYAN))
    print(line())

    for index, expense in enumerate(expenses, start=1):
        color: str = {
            "needs": Color.GREEN,
            "wants": Color.YELLOW,
            "savings": Color.BLUE,
        }[expense.category]
        row: str = (
            f" {index:<3} {expense.expense_id:<4} {expense.created_at:<12} "
            f"{expense.label():<10} {expense.amount:>10.2f}  {expense.description}"
        )
        print(paint(row, color))

    print(line())


# ---------------------------------------------------------------
# الأوامر
# ---------------------------------------------------------------
def action_set_income(manager: BudgetManager) -> None:
    income: Optional[float] = ask_number(f"الدخل الشهري بالـ{CURRENCY}")

    print(paint("\n   طريقة التقسيم:", Color.GREY))
    modes: list[str] = list(SPLIT_MODES.keys()) + [CUSTOM_MODE]
    for index, mode_name in enumerate(modes, start=1):
        title: str = "تقسيم مخصص" if mode_name == CUSTOM_MODE else f"{mode_name} (قاعدة كلاسيكية)"
        print(f"     {index}. {title}")

    choice: str = ask("اختار رقم")
    mode: str = modes[int(choice) - 1] if choice.isdigit() and 1 <= int(choice) <= len(modes) else "50/30/20"

    custom: Optional[dict[str, float]] = None
    if mode == CUSTOM_MODE:
        custom = {}
        for name in CATEGORIES:
            percent: Optional[float] = ask_number(f"نسبة {CATEGORY_LABELS[name]} ٪")
            custom[name] = float(percent or 0)

    allocation: dict[str, float] = manager.set_income(income, mode, custom)
    print(paint("\n   ✔ اتحفظ. الخطة بتاعتك:", Color.GREEN, bold=True))
    for name, amount in allocation.items():
        percent: int = round(manager.budget.split[name] * 100)
        print(f"     {CATEGORY_LABELS[name]:<10} {percent:>3}٪  =  {amount:,.2f} {CURRENCY}")


def action_show_plan(manager: BudgetManager) -> None:
    manager.require_income()
    allocation = manager.budget.allocation()
    spent = manager.spent_by_category()

    print(line())
    for name, planned in allocation.items():
        print(
            f" {CATEGORY_LABELS[name]:<10} الخطة {planned:>10,.2f} | "
            f"صرفت {spent[name]:>10,.2f}"
        )
    print(line())


def action_add_expense(manager: BudgetManager) -> None:
    manager.require_income()
    amount: Optional[float] = ask_number(f"المبلغ بالـ{CURRENCY}")
    category: str = ask_category()
    description: str = ask("وصف المصروف (اختياري)")

    expense = manager.add_expense(amount, category, description)
    print(paint(f"   ✔ اتسجل: {expense}", Color.GREEN))

    # المقارنة الحية بعد كل مصروف
    ratios = manager.usage_ratio()
    planned = manager.budget.allocation()[category]
    spent = manager.spent_by_category()[category]
    print(
        paint(
            f"   المفروض تصرف {planned:,.0f} على {CATEGORY_LABELS[category]}، "
            f"أنت صرفت {spent:,.0f} لحد دلوقتي ({ratios[category] * 100:.0f}٪)",
            Color.CYAN,
        )
    )

    for warning in manager.warnings():
        warn_color = Color.YELLOW if warning["level"] == "warning" else Color.RED
        print(paint(f"   ⚠ {warning['message']}", warn_color, bold=True))


def action_list_expenses(manager: BudgetManager) -> None:
    print_expenses_table(manager.budget.expenses)


def action_update_expense(manager: BudgetManager) -> None:
    print_expenses_table(manager.budget.expenses)
    if not manager.budget.expenses:
        return

    expense_id: Optional[float] = ask_number("اكتب ID المصروف اللي عايز تعدّله")
    print(paint("   سيب أي حاجة فاضية عشان تفضل زي ما هي:", Color.GREY))

    amount: Optional[float] = ask_number("المبلغ الجديد [Enter تخطي]", allow_empty=True)
    change_category: str = ask("تغيير التصنيف؟ (y/n)").lower()
    category: Optional[str] = ask_category() if change_category == "y" else None
    description: Optional[str] = ask("الوصف الجديد [Enter تخطي]") or None

    updated = manager.update_expense(int(expense_id or 0), amount, category, description)
    print(paint(f"   ✔ اتعدّل: {updated}", Color.GREEN))


def action_delete_expense(manager: BudgetManager) -> None:
    print_expenses_table(manager.budget.expenses)
    if not manager.budget.expenses:
        return
    expense_id: Optional[float] = ask_number("اكتب ID المصروف اللي عايز تمسحه")
    removed = manager.delete_expense(int(expense_id or 0))
    print(paint(f"   ✔ اتمسح: {removed}", Color.GREEN))


def action_search(manager: BudgetManager) -> None:
    keyword: str = ask("اكتب كلمة للبحث")
    results = manager.search(keyword)
    print(paint(f"   لقيت {len(results)} نتيجة", Color.CYAN))
    print_expenses_table(results)


def action_report(manager: BudgetManager) -> None:
    manager.require_income()
    report = build_report(manager)
    print()
    print(format_report_text(report, WIDTH))


def action_stats(manager: BudgetManager) -> None:
    """التحليل الإحصائي الكامل — التوزيعات الاحتمالية على مصاريفك."""
    manager.require_income()
    print(paint("\n   بحسب التوزيعات وبعمل 10,000 محاكاة… ثانية واحدة.", Color.GREY))

    stats = build_stats_report(manager)
    print()
    print(format_stats_text(stats, WIDTH))


def action_check_expense(manager: BudgetManager) -> None:
    """«لو صرفت المبلغ ده، هيبقى طبيعي ولا شاذ؟» — Z-Score قبل الصرف."""
    manager.require_income()
    amount: Optional[float] = ask_number(f"المبلغ اللي ناوي تصرفه بالـ{CURRENCY}")
    category: str = ask_category()

    result = z_score_of(manager, float(amount or 0), category)
    verdict_color: str = (
        Color.GREEN if abs(result["z"]) < 1
        else Color.YELLOW if abs(result["z"]) < 2
        else Color.RED
    )

    print(line())
    print(f"   متوسط مصاريفك في {CATEGORY_LABELS[category]}: {result['mean']:,.2f} "
          f"± {result['std']:,.2f}")
    print(f"   الـ Z-Score للمبلغ ده: {result['z']:+.2f}")
    print(f"   أكبر من {result['percentile']:.0f}٪ من مصاريفك في التصنيف ده")
    print(paint(f"   التقييم: {result['verdict']}", verdict_color, bold=True))
    print(line())






def action_pipeline(manager: BudgetManager) -> None:
    """
    التحليل الإحصائي الشامل: 12 مرحلة من تنظيف البيانات لحد الخلاصة.
    بيشتغل على مصاريف البرنامج، أو على data/dataset.csv لو اخترت كده.
    """
    print(paint("\n   مصدر البيانات:", Color.CYAN))
    print("     1) مصاريف البرنامج")
    print("     2) داتاست التجربة (data/dataset.csv)")
    choice: str = ask("اختار (Enter = 1)")

    if choice.strip() == "2":
        path = DATA_DIR / "dataset.csv"
        if not path.exists():
            print(paint("\n   ملف dataset.csv مش موجود.", Color.RED))
            print(paint("   شغّل الأول: python tools/make_dataset.py", Color.GREY))
            return

        with path.open(encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.DictReader(handle))
    else:
        rows = rows_from_manager(manager)

    print(paint(f"\n   بشغّل الـ 12 مرحلة على {len(rows)} صف… ثانية واحدة.", Color.GREY))

    try:
        result = run_pipeline(rows, income=manager.budget.income)
    except BudgetError as error:
        print(paint(f"\n   {error}", Color.RED))
        return

    print(format_pipeline_text(result, WIDTH))


def action_charts(manager: BudgetManager) -> None:
    """توليد الرسومات البيانية في فولدر data/charts."""
    if not CHARTS_AVAILABLE:
        print(paint("   Matplotlib مش متسطبة. سطّبها بـ: pip install matplotlib", Color.YELLOW))
        return

    manager.require_income()
    print(paint("   بحسب وبرسم… (أول مرة بتاخد شوية)", Color.GREY))

    stats = build_stats_report(manager)
    charts = build_all_charts(stats, expense_amounts(manager))

    if not charts:
        print(paint("   مفيش بيانات كفاية لأي رسمة لسه.", Color.GREY))
        return

    print(paint(f"   ✔ اتولّد {len(charts)} رسمة في: {CHARTS_DIR}", Color.GREEN, bold=True))
    for index, (key, filename) in enumerate(charts.items(), start=1):
        print(f"     {index}. {filename}")


def action_save(manager: BudgetManager) -> None:
    path = save_json(manager.to_dict())
    print(paint(f"   ✔ البيانات اتحفظت في {path.name}", Color.GREEN))


def action_export(manager: BudgetManager) -> None:
    path = export_expenses_csv(manager.budget.expenses)
    print(paint(f"   ✔ التصدير تم: {path}", Color.GREEN))


def action_import(manager: BudgetManager) -> None:
    rows = import_expenses_csv()
    added: int = 0
    for row in rows:
        try:
            manager.add_expense(row["amount"], row["category"], row["description"])
            added += 1
        except BudgetError as error:
            log.error("Skipped row: %s", error)
            continue
    print(paint(f"   ✔ اتضاف {added} مصروف من ملف CSV", Color.GREEN))


# ربط الأوامر بالدوال: Dictionary of functions
ACTIONS: dict[str, Callable[[BudgetManager], None]] = {
    "set_income": action_set_income,
    "show_plan": action_show_plan,
    "add_expense": action_add_expense,
    "list_expenses": action_list_expenses,
    "update_expense": action_update_expense,
    "delete_expense": action_delete_expense,
    "search": action_search,
    "report": action_report,
    "stats": action_stats,
    "check_expense": action_check_expense,
    "pipeline": action_pipeline,
    "charts": action_charts,
    "save": action_save,
    "export": action_export,
    "import": action_import,
}


def run_console() -> None:
    """
    اللوب الرئيسي للبرنامج.
    while True + break + try/except/finally
    """
    manager = BudgetManager()

    # تحميل البيانات القديمة لو موجودة
    try:
        saved_data = load_json()
        if saved_data:
            manager.load_dict(saved_data)
            print(paint(" تم تحميل بياناتك المحفوظة.", Color.GREEN))
    except BudgetError as error:
        print(paint(f" تحذير: {error.message}", Color.YELLOW))

    header()

    while True:
        show_menu(manager)
        choice: str = ask("اختار رقم من القائمة")

        if not choice.isdigit():
            print(paint("   اكتب رقم من القائمة.", Color.RED))
            continue

        index: int = int(choice)
        if index < 1 or index > len(MENU_ITEMS):
            print(paint("   الرقم مش موجود في القائمة.", Color.RED))
            continue

        _title, key = MENU_ITEMS[index - 1]

        if key == "exit":
            try:
                save_json(manager.to_dict())
                print(paint("\n مع السلامة، بياناتك اتحفظت. 👋", Color.CYAN, bold=True))
            except BudgetError as error:
                print(paint(f" مقدرناش نحفظ: {error.message}", Color.RED))
            finally:
                log.info("App closed by user")
            break            # break: خروج من اللوب

        try:
            ACTIONS[key](manager)
        except BudgetError as error:
            # كل أخطاء البرنامج المخصصة بتتمسك هنا
            print(paint(f"   ✖ {error.message}", Color.RED, bold=True))
            log.error("%r", error)
        except KeyboardInterrupt:
            print(paint("\n   اتلغى الأمر.", Color.YELLOW))
        except Exception as error:  # أي خطأ غير متوقع
            print(paint(f"   ✖ خطأ غير متوقع: {error}", Color.RED))
            log.exception("Unexpected error")
