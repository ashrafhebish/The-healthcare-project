"""
budget_manager.py
-----------------
المخ بتاع البرنامج: بيدير الشهور، الحسابات، المقارنة الحية، والتحذيرات.
بيوضح: OOP + Functions + BONUS: map(), filter(), reduce(), zip(), lambda, sorted()
"""

from datetime import date
from functools import reduce
from typing import Any, Optional

from .config import CATEGORIES, CATEGORY_LABELS, DEFAULT_MODE, WARNING_THRESHOLD
from .exceptions import IncomeNotSetError, InvalidCategoryError
from .logger_setup import log
from .models import Expense, MonthlyBudget


def current_month_key() -> str:
    """بترجّع مفتاح الشهر الحالي بصيغة YYYY-MM."""
    return date.today().strftime("%Y-%m")


class BudgetManager:
    """
    بيمسك كل الشهور مع بعض ويشتغل على الشهر الحالي.
    ده الكلاس اللي الواجهات (الكونسول والويب) بتكلمه.
    """

    def __init__(self, month: Optional[str] = None) -> None:
        self.months: dict[str, MonthlyBudget] = {}          # Dictionary of objects
        self.current_month: str = month or current_month_key()
        self.months[self.current_month] = MonthlyBudget(self.current_month)
        log.info("BudgetManager started for month %s", self.current_month)

    # ---------------- إدارة الشهور ----------------
    @property
    def budget(self) -> MonthlyBudget:
        """الميزانية بتاعة الشهر الحالي."""
        return self.months[self.current_month]

    def switch_month(self, month: str) -> MonthlyBudget:
        """بتفتح شهر تاني، ولو مش موجود بتعمله جديد."""
        if month not in self.months:
            self.months[month] = MonthlyBudget(month)
            log.info("Created new month %s", month)
        self.current_month = month
        return self.budget

    def months_list(self) -> list[str]:
        """كل الشهور مرتبة. sorted()"""
        return sorted(self.months.keys())

    # ---------------- الدخل ----------------
    def set_income(
        self, income: Any, mode: str = DEFAULT_MODE, custom: Optional[dict[str, float]] = None
    ) -> dict[str, float]:
        """بتحدد الدخل وطريقة التقسيم وترجّع الخطة (كل تصنيف كام)."""
        self.budget.set_income(income)
        self.budget.set_mode(mode, custom)
        log.info("Income set to %.2f with mode %s", self.budget.income, self.budget.mode)
        return self.budget.allocation()

    def require_income(self) -> float:
        """بترمي Exception لو الدخل لسه مش متحدد."""
        if self.budget.income <= 0:
            raise IncomeNotSetError()
        return self.budget.income

    # ---------------- المصاريف ----------------
    def add_expense(self, amount: Any, category: str, description: str = "") -> Expense:
        self.require_income()
        expense: Expense = self.budget.add_expense(amount, category, description)
        log.info("Added %r", expense)
        return expense

    def delete_expense(self, expense_id: int) -> Expense:
        expense: Expense = self.budget.remove_expense(expense_id)
        log.warning("Deleted %r", expense)
        return expense

    def get_expense(self, expense_id: int) -> Expense:
        """بتدوّر على مصروف بالـ id، ولو مش موجود بترمي Exception."""
        for expense in self.budget.expenses:
            if expense.expense_id == int(expense_id):
                return expense

        from .exceptions import ExpenseNotFoundError

        raise ExpenseNotFoundError(int(expense_id))

    def update_expense(
        self,
        expense_id: int,
        amount: Optional[Any] = None,
        category: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Expense:
        """
        بتعدّل مصروف موجود. أي parameter تسيبه None يفضل زي ما هو.
        """
        from .models import validate_expense_data

        expense: Expense = self.get_expense(expense_id)

        new_amount = expense.amount if amount is None else amount
        new_category = expense.category if category is None else category
        new_description = expense.description if description is None else description

        clean_amount, clean_category, clean_description = validate_expense_data(
            new_amount, new_category, new_description
        )

        expense.amount = clean_amount
        expense.category = clean_category
        expense.description = clean_description

        log.info("Updated %r", expense)
        return expense

    def expenses_of(self, category: str) -> list[Expense]:
        """
        كل المصاريف بتاعة تصنيف معين.
        BONUS: filter() + lambda
        """
        if category not in CATEGORY_LABELS:
            raise InvalidCategoryError(category)
        return list(filter(lambda item: item.category == category, self.budget.expenses))

    def search(self, keyword: str) -> list[Expense]:
        """
        بحث في وصف المصاريف.
        List Comprehension + Strings (lower / in)
        """
        needle: str = keyword.strip().lower()
        return [
            expense
            for expense in self.budget.expenses
            if needle in expense.description.lower() or needle in expense.category
        ]

    def top_expenses(self, count: int = 5) -> list[Expense]:
        """أكبر المصاريف. BONUS: sorted() + lambda"""
        ordered: list[Expense] = sorted(
            self.budget.expenses, key=lambda item: item.amount, reverse=True
        )
        return ordered[:count]

    # ---------------- الحسابات ----------------
    def total_spent(self) -> float:
        """
        إجمالي المصروف.
        BONUS: map() + reduce() + lambda
        """
        amounts = map(lambda item: item.amount, self.budget.expenses)
        return round(reduce(lambda first, second: first + second, amounts, 0.0), 2)

    def spent_by_category(self) -> dict[str, float]:
        """كل تصنيف اتصرف فيه كام. for loop + dictionary"""
        totals: dict[str, float] = {name: 0.0 for name in CATEGORIES}
        for expense in self.budget.expenses:
            totals[expense.category] += expense.amount
        return {name: round(value, 2) for name, value in totals.items()}

    def remaining_by_category(self) -> dict[str, float]:
        """المتبقي في كل تصنيف = الخطة - المصروف. BONUS: zip()"""
        plan: dict[str, float] = self.budget.allocation()
        spent: dict[str, float] = self.spent_by_category()

        remaining: dict[str, float] = {}
        for name, planned, used in zip(CATEGORIES, plan.values(), spent.values()):
            remaining[name] = round(planned - used, 2)
        return remaining

    def usage_ratio(self) -> dict[str, float]:
        """نسبة الاستهلاك من 0 لـ 1 (أو أكتر لو عدّى الخطة)."""
        plan: dict[str, float] = self.budget.allocation()
        spent: dict[str, float] = self.spent_by_category()

        ratios: dict[str, float] = {}
        for name in CATEGORIES:
            planned: float = plan[name]
            if planned <= 0:
                ratios[name] = 0.0
                continue          # continue
            ratios[name] = round(spent[name] / planned, 4)
        return ratios

    def actual_savings(self) -> float:
        """التوفير الفعلي = الدخل - كل اللي اتصرف."""
        return round(self.budget.income - self.total_spent(), 2)

    # ---------------- التحذيرات (المقارنة الحية) ----------------
    def warnings(self) -> list[dict[str, Any]]:
        """
        بترجّع تحذيرات لكل تصنيف قرب أو عدّى حده.
        if / elif / else
        """
        alerts: list[dict[str, Any]] = []
        plan = self.budget.allocation()
        spent = self.spent_by_category()
        ratios = self.usage_ratio()

        for name in CATEGORIES:
            ratio: float = ratios[name]
            label: str = CATEGORY_LABELS[name]

            if ratio > 1.0:
                level, text = "danger", (
                    f"عدّيت خطة {label}: صرفت {spent[name]:.0f} والخطة {plan[name]:.0f}"
                )
            elif ratio >= WARNING_THRESHOLD:
                level, text = "warning", (
                    f"قربت تخلّص ميزانية {label} — استهلكت {ratio * 100:.0f}٪"
                )
            else:
                continue

            alerts.append({"category": name, "level": level, "message": text})
            log.warning("Alert [%s] %s", level, text)

        return alerts

    def is_on_plan(self) -> bool:
        """هل ملتزم بالخطة في كل التصنيفات؟ (Operators + all)"""
        return all(ratio <= 1.0 for ratio in self.usage_ratio().values())

    # ---------------- تحويل للتخزين ----------------
    def to_dict(self) -> dict[str, Any]:
        return {
            "current_month": self.current_month,
            "months": {key: value.to_dict() for key, value in self.months.items()},
        }

    def load_dict(self, data: dict[str, Any]) -> None:
        """بيملأ المدير من dictionary جاي من ملف JSON."""
        months_data: dict[str, Any] = data.get("months", {})
        if not months_data:
            return

        self.months = {
            key: MonthlyBudget.from_dict(value) for key, value in months_data.items()
        }
        self.current_month = str(data.get("current_month", current_month_key()))

        if self.current_month not in self.months:
            self.months[self.current_month] = MonthlyBudget(self.current_month)

        log.info("Loaded %d month(s) from file", len(self.months))

    def __repr__(self) -> str:
        return (
            f"BudgetManager(month={self.current_month!r}, "
            f"income={self.budget.income:.2f}, expenses={len(self.budget)})"
        )
