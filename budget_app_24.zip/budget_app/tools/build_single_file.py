"""
build_single_file.py
--------------------
بيبني `index.html` في جذر المشروع كملف **واحد مستقل** فيه كل حاجة:
الـ HTML والـ CSS وكل ملفات الـ JavaScript متلزقين جوه بعض.

ليه ملف واحد؟
    عشان دبل كليك واحد يفتح البرنامج فوراً. ملف واحد يعني مفيش ملفات
    خارجية ممكن المتصفح يرفض يحمّلها من `file://`، ومفيش صفحة تحويل،
    ومفيش سيرفر. تقدر كمان تبعته لأي حد كمرفق واحد ويشتغل عنده.

الملفات في `web/static/` تفضل هي **الأصل** — الملف المدموج بيتولّد منها.
يعني أي تعديل يتعمل هناك، وبعدين يتشغّل السكريبت ده تاني.

التشغيل من فولدر المشروع:
    python tools/build_single_file.py
"""

from __future__ import annotations

import json

import sys
from datetime import date
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

STATIC_DIR: Path = BASE_DIR / "web" / "static"
# كل صفحة: (المصدر في web/static, الناتج في الجذر, ملفات الـ JS بترتيبها)
PAGES: tuple[tuple[str, str, tuple[str, ...]], ...] = (
    (
        "index.html",
        "index.html",
        ("offline-data.js", "offline-analysis.js", "offline.js", "app.js"),
    ),
    (
        "analysis.html",
        "analysis.html",
        (
            "offline-data.js",
            "offline-analysis.js",
            "offline.js",
            "generic-analysis.js",
            "app.js",
            "themes.js",
            "views-en.js",
            "analysis-page.js",
        ),
    ),
)

OUTPUT_FILE: Path = BASE_DIR / "index.html"

# الداتاست اللي بتتلزق جوه صفحة التحليل عشان تشتغل من غير رفع ملفات
DATASET_FILE: Path = BASE_DIR / "data" / "dataset.csv"

# رقم النسخة + تاريخها — بيتطبع في آخر الصفحة
BUILD_ID: str = f"build {date.today().isoformat()}"

# ترتيب ملفات الـ JS مهم: البيانات الأول، بعدين التحليل، بعدين المحرك،
# وفي الآخر app.js اللي بينادي عليهم كلهم.
BANNER: str = f"""<!--
  ⚠ الملف ده متولّد تلقائياً — متعدلوش بالإيد!

  الأصل في: web/static/  (index.html + style.css + *.js)
  لإعادة توليده:  python tools/build_single_file.py
  آخر توليد:      {date.today().isoformat()}

  ده نسخة «ملف واحد» من البرنامج: كل الـ CSS والـ JS متلزقين جوه
  الملف ده عشان دبل كليك واحد يفتح البرنامج فوراً من غير سيرفر.
-->
"""


def read(name: str) -> str:
    """بيقرا ملف من web/static ويطمّن إنه موجود."""
    path = STATIC_DIR / name
    if not path.exists():
        raise SystemExit(f"✖ الملف {path.relative_to(BASE_DIR)} مش موجود")
    return path.read_text(encoding="utf-8")


def embedded_dataset() -> str:
    """
    بترجّع سكريبت فيه محتوى data/dataset.csv كنص.

    ليه؟ المتصفح مبيسمحش لصفحة مفتوحة كملف إنها تقرا ملف تاني من الجهاز،
    فلو الداتاست مش متلزقة جوه الصفحة، المستخدم هيبقى مجبور يرفع ملف
    كل مرة. اللزق ده بيخلي الصفحة تشتغل بضغطة واحدة.
    """
    if not DATASET_FILE.exists():
        print("  ⚠ data/dataset.csv مش موجودة — الصفحة هتشتغل بالرفع بس")
        return ""

    csv_text: str = DATASET_FILE.read_text(encoding="utf-8-sig")
    # JSON بيهرب علامات التنصيص والأسطر الجديدة صح
    return (
        "<script>\n"
        "  /* الداتاست التجريبية متلزقة هنا وقت البناء — من data/dataset.csv */\n"
        f"  window.EMBEDDED_DATASET = {json.dumps(csv_text, ensure_ascii=False)};\n"
        "</script>"
    )


def build(source: str, script_order: tuple[str, ...]) -> str:
    html: str = read(source)

    # (1) الستايل جوه <style> بدل <link>
    css: str = read("style.css")
    html = html.replace(
        '<link rel="stylesheet" href="style.css" />',
        f"<style>\n{css}\n</style>",
    )

    # (2) كل سكريبت جوه <script> بدل src — بالترتيب الصح
    #
    # قبلهم بنحط علم بيقول للصفحة إنها نسخة بدون سيرفر. ده مهم لما
    # الملف يترفع على استضافة ثابتة (GitHub Pages مثلاً): البروتوكول
    # هيبقى https مش file، ومن غير العلم ده الصفحة هتحاول تنادي API
    # مش موجود وترجع صفحة 404 فيقع الكود.
    flag: str = (
        "<script>\n"
        "  /* نسخة الملف الواحد: الحسابات كلها بتتعمل في المتصفح،\n"
        "     مهما كانت مرفوعة فين. */\n"
        "  window.FORCE_OFFLINE = true;\n"
        "</script>"
    )

    dataset: list[str] = (
        [embedded_dataset()] if "analysis-page.js" in script_order else []
    )

    scripts: list[str] = [flag] + dataset + [
        f"<script>\n/* ===== {name} ===== */\n{read(name)}\n</script>"
        for name in script_order
    ]

    # بنشيل وسوم <script src=...> القديمة كلها
    for name in script_order:
        html = html.replace(f'<script src="{name}"></script>\n', "")
        html = html.replace(f'<script src="{name}"></script>', "")

    html = html.replace(
        "<!-- offline-data.js متولّد من بايثون · offline.js بيشتغل بس لما تفتح الملف مباشرة -->",
        "\n".join(scripts),
    )

    # لو التعليق مش موجود لأي سبب، بنحط السكريبتات قبل </body>
    if f"/* ===== {script_order[-1]} ===== */" not in html:
        html = html.replace("</body>", "\n".join(scripts) + "\n</body>")

    # (3) ختم النسخة — بيظهر في آخر الصفحة.
    #     فايدته: لما ترفع الملف على استضافة وتشك إن اللي ظاهر قدامك هو
    #     النسخة القديمة المحفوظة في المتصفح، تبص على الختم وتعرف فوراً.
    html = html.replace(
        '<span class="foot__build" id="buildStamp"></span>',
        f'<span class="foot__build" id="buildStamp">'
        f'نسخة ملف واحد · {BUILD_ID}</span>',
    )

    # (4) البانر في أول الملف بعد <!DOCTYPE html>
    html = html.replace("<!DOCTYPE html>", "<!DOCTYPE html>\n" + BANNER, 1)

    return html


def main() -> list[Path]:
    written: list[Path] = []

    for source, target, script_order in PAGES:
        html = build(source, script_order)
        path = BASE_DIR / target
        path.write_text(html, encoding="utf-8")
        written.append(path)

        size_kb = path.stat().st_size / 1024
        missing = [n for n in script_order if f"/* ===== {n} ===== */" not in html]

        print(f"✔ {target}  ({size_kb:,.0f} كيلوبايت)")
        if missing or "<style>" not in html:
            print(f"  ⚠ ناقص: {missing or 'الستايل'}")
        else:
            print(f"  الستايل + {len(script_order)} ملفات JavaScript")

    print("\nدبل كليك على أي منهم يفتح على طول — من غير سيرفر ولا ملفات تانية.")
    return written


if __name__ == "__main__":
    main()
