"""
make_dataset.py
---------------
بيولّد داتاست مصاريف واقعية لـ 6 شهور في `data/dataset.csv`.

ليه؟ التحليل الإحصائي (اختبار الفروض، ANOVA، فترات الثقة) محتاج بيانات
كفاية عشان يبقى له معنى. لو عندك مصاريفك الحقيقية استخدمها — الملف ده
للتجربة والعرض.

البيانات مش عشوائية بالساوي، متبنية عشان تعكس سلوك حقيقي:
  • الاحتياجات: مصاريف متوسطة متكررة (إيجار، أكل، مواصلات)
  • الكماليات: أصغر وأكتر عدداً، وفيها صرفات كبيرة نادرة (الذيل)
  • التوفير: مبالغ كبيرة قليلة العدد (مرة أو مرتين في الشهر)
  • آخر الشهر بيشهد صرف أكتر (سلوك حقيقي)

وكمان بيحط **صفوف وسخة عن قصد** (ناقصة، مكررة، مبالغ غلط) عشان
المرحلة الأولى من التحليل — تنظيف البيانات — يكون ليها شغل حقيقي.

التشغيل:
    python tools/make_dataset.py
    python tools/make_dataset.py --months 12 --seed 5
"""

from __future__ import annotations

import argparse
import csv
import random
import sys
from calendar import monthrange
from datetime import date
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

OUTPUT_FILE = BASE_DIR / "data" / "dataset.csv"

# (التصنيف, الوصف, أقل مبلغ, أكبر مبلغ, احتمال الظهور في اليوم)
PATTERNS: list[tuple[str, str, float, float, float]] = [
    ("needs", "أكل وبقالة", 60, 260, 0.75),
    ("needs", "مواصلات", 25, 90, 0.55),
    ("needs", "فاتورة كهرباء", 180, 420, 0.04),
    ("needs", "فاتورة مياه", 60, 150, 0.04),
    ("needs", "إنترنت", 200, 320, 0.04),
    ("needs", "دواء", 70, 300, 0.10),
    ("wants", "قهوة", 30, 85, 0.60),
    ("wants", "مطعم", 120, 400, 0.25),
    ("wants", "اشتراك ترفيه", 90, 200, 0.05),
    ("wants", "هدوم", 250, 900, 0.07),
    ("wants", "خروجة", 100, 350, 0.18),
    ("savings", "تحويل للتوفير", 800, 2200, 0.06),
    ("savings", "شهادة ادخار", 1500, 3500, 0.02),
]


def month_keys(count: int) -> list[tuple[int, int]]:
    """آخر `count` شهر منتهيين بالشهر الحالي. Tuples + list"""
    today = date.today()
    result: list[tuple[int, int]] = []
    year, month = today.year, today.month

    for _ in range(count):
        result.append((year, month))
        month -= 1
        if month == 0:
            month = 12
            year -= 1

    return list(reversed(result))


def generate(months: int, seed: int) -> list[dict[str, object]]:
    """بيبني الصفوف النضيفة."""
    generator = random.Random(seed)
    rows: list[dict[str, object]] = []
    today = date.today()

    for year, month in month_keys(months):
        days = monthrange(year, month)[1]
        # لو الشهر ده هو الحالي، منكملش لبعد النهارده
        if (year, month) == (today.year, today.month):
            days = today.day

        for day in range(1, days + 1):
            # آخر الشهر بيزيد فيه الصرف شوية (سلوك حقيقي)
            pressure = 1.25 if day > days - 7 else 1.0

            for category, description, low, high, chance in PATTERNS:
                if generator.random() > chance * pressure:
                    continue

                amount = generator.uniform(low, high)

                # صرفات كبيرة نادرة — دي اللي بتعمل الذيل الأيمن
                if category == "wants" and generator.random() < 0.03:
                    amount *= generator.uniform(2.5, 4.0)

                rows.append(
                    {
                        "date": f"{year:04d}-{month:02d}-{day:02d}",
                        "category": category,
                        "amount": round(amount, 2),
                        "description": description,
                    }
                )

    return rows


def add_dirty_rows(rows: list[dict[str, object]], seed: int) -> list[dict[str, object]]:
    """
    بيضيف صفوف وسخة عن قصد عشان مرحلة التنظيف يبقى ليها معنى:
    ناقصة، مبالغ غلط، تصنيف مجهول، ومكررة.
    """
    generator = random.Random(seed + 99)
    dirty: list[dict[str, object]] = list(rows)

    # (أ) صفوف ناقصة
    for _ in range(6):
        source = generator.choice(rows)
        dirty.append({**source, "amount": ""})
        dirty.append({**source, "category": ""})

    # (ب) مبالغ غير صحيحة
    for bad_value in (-150, 0, "كتير", "٢٠٠", ""):
        source = generator.choice(rows)
        dirty.append({**source, "amount": bad_value})

    # (ج) تصنيف مجهول
    for _ in range(3):
        source = generator.choice(rows)
        dirty.append({**source, "category": "غير مصنف"})

    # (د) تكرار كامل
    for _ in range(8):
        dirty.append(dict(generator.choice(rows)))

    generator.shuffle(dirty)
    return dirty


def main() -> None:
    parser = argparse.ArgumentParser(description="توليد داتاست مصاريف للتحليل")
    parser.add_argument("--months", type=int, default=6, help="عدد الشهور (افتراضي 6)")
    parser.add_argument("--seed", type=int, default=42, help="بذرة العشوائية")
    parser.add_argument("--clean", action="store_true", help="من غير صفوف وسخة")
    args = parser.parse_args()

    rows = generate(args.months, args.seed)
    final = rows if args.clean else add_dirty_rows(rows, args.seed)

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT_FILE.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["date", "category", "amount", "description"])
        writer.writeheader()
        writer.writerows(final)

    print(f"✔ اتكتب {OUTPUT_FILE.relative_to(BASE_DIR)}")
    print(f"  {len(rows)} صف نضيف + {len(final) - len(rows)} صف وسخ = {len(final)} إجمالي")
    print(f"  {args.months} شهور")


if __name__ == "__main__":
    main()
