"""
build_offline_data.py
---------------------
بيولّد ملف `web/static/offline-data.js` من إعدادات بايثون نفسها.

ليه؟ صفحة `index.html` بتشتغل بالدبل كليك من غير سيرفر، ومحتاجة تعرف
التصنيفات وطرق التقسيم. بدل ما نكتبهم تاني في JS (ونسيبهم يبوظوا مع أول
تعديل)، **`app/config.py` هو مصدر الحقيقة الوحيد** والسكريبت ده بيصدّره.

التشغيل من فولدر المشروع:
    python tools/build_offline_data.py

لازم يتشغّل تاني بعد أي تعديل في `app/config.py`.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from app.config import (  # noqa: E402
    APP_NAME,
    CATEGORIES,
    CATEGORY_LABELS,
    CURRENCY,
    DEFAULT_MODE,
    SPLIT_MODES,
    WARNING_THRESHOLD,
)

OUTPUT_FILE: Path = BASE_DIR / "web" / "static" / "offline-data.js"


def main() -> Path:
    payload: dict = {
        "app_name": APP_NAME,
        "currency": CURRENCY,
        # List Comprehension: التصنيفات بأسمائها المعروضة
        "categories": [{"key": name, "label": CATEGORY_LABELS[name]} for name in CATEGORIES],
        "split_modes": SPLIT_MODES,
        "default_mode": DEFAULT_MODE,
        "warning_threshold": WARNING_THRESHOLD,
    }

    body: str = json.dumps(payload, ensure_ascii=False, indent=2)
    content: str = (
        "/* =========================================================\n"
        "   offline-data.js — متولّد تلقائياً، متعدلوش بالإيد!\n"
        "   المصدر: app/config.py\n"
        "   لإعادة توليده:  python tools/build_offline_data.py\n"
        "   ========================================================= */\n\n"
        f"window.OFFLINE_DATA = {body};\n"
    )

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_FILE.write_text(content, encoding="utf-8")

    print(f"✔ اتكتب {OUTPUT_FILE.relative_to(BASE_DIR)}")
    print(f"  {len(payload['categories'])} تصنيفات · {len(SPLIT_MODES)} طرق تقسيم")
    return OUTPUT_FILE


if __name__ == "__main__":
    main()
