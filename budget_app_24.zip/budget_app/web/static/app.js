/* =========================================================
   app.js — بيكلّم الـ API بتاع بايثون ويرسم النتيجة
   ========================================================= */

const $ = (id) => document.getElementById(id);

/* ربط حدث بعنصر لو موجود.
   لازم كده عشان نفس الملف بيتستخدم في أكتر من صفحة (الصفحة الكاملة،
   وصفحة التحليل لوحدها)، وكل صفحة فيها عناصر مختلفة. */
function on(id, event, handler) {
  const element = $(id);
  if (element) element.addEventListener(event, handler);
  return Boolean(element);
}


const money = (value) =>
  Number(value || 0).toLocaleString("en-US", { maximumFractionDigits: 2 });

/* ------------ نداء الـ API ------------ */
async function callApi(route, payload) {
  /* لو الصفحة مفتوحة بالدبل كليك (file://) مفيش سيرفر يرد،
     فبننادي المحرك اللي في offline.js بدل fetch. */
  if (window.IS_OFFLINE && window.OfflineAPI) {
    return window.OfflineAPI.call(route, payload);
  }

  const options = payload
    ? {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }
    : { method: "GET" };

  let result;
  try {
    const response = await fetch(route, options);
    result = await response.json();
  } catch (error) {
    /* شبكة أمان: لو مفيش سيرفر بايثون على الطرف التاني (مثلاً الصفحة
       مرفوعة على استضافة ثابتة)، الرد بيبقى صفحة HTML مش JSON فالقراءة
       بتقع. بدل ما نطلّع الخطأ للمستخدم، بنكمّل بالمحرك اللي في المتصفح. */
    if (window.OfflineAPI) {
      window.IS_OFFLINE = true;
      return window.OfflineAPI.call(route, payload);
    }
    throw new Error("مقدرتش أوصل للسيرفر — تأكد إن python run_web.py شغال.");
  }

  if (!result.ok) {
    throw new Error(result.error || "حصل خطأ غير متوقع");
  }
  return result.data;
}

function showMessage(element, text, isError) {
  element.textContent = text;
  element.className = "msg " + (isError ? "bad" : "ok");
  if (!isError) {
    setTimeout(() => {
      element.textContent = "";
    }, 4000);
  }
}

/* ------------ الرسم ------------ */
function renderHero(state) {
  const ring = $("heroRing");
  const value = $("heroIncome");
  if (!ring || !value) return;

  if (!state.income) {
    value.textContent = "—";
    return;
  }

  value.textContent = `${money(state.income)} ${state.currency}`;

  // الحلقة بتتقسم بنسب الخطة الحقيقية
  const shares = state.lines.map((line) => line.percent_of_income / 100);
  const stops = [];
  let cursor = 0;
  const colors = ["var(--gold)", "#4b9fd6", "#3fb883"];

  shares.forEach((share, index) => {
    const next = cursor + share;
    stops.push(`${colors[index]} ${cursor}turn ${next}turn`);
    cursor = next;
  });

  ring.style.background = `conic-gradient(${stops.join(", ")})`;
}

function renderTiles(state) {
  const tiles = $("tiles");
  /* الصفحة اللي مفيهاش قسم الخطة (زي صفحة التحليل) بتعدّي من غير رسم */
  if (!tiles) return;
  const empty = $("resultEmpty");
  const foot = $("panelFoot");

  if (!state.income) {
    tiles.hidden = true;
    foot.hidden = true;
    empty.hidden = false;
    $("panelMeta").textContent = "";
    return;
  }

  empty.hidden = true;
  tiles.hidden = false;
  foot.hidden = false;

  $("panelMeta").textContent = `شهر ${state.month} • دخل ${money(state.income)} ${state.currency} • ${state.mode}`;

  tiles.innerHTML = state.lines
    .map((line) => {
      const percent = Math.min(line.ratio * 100, 100);
      const statusClass = line.status === "over" ? "is-over" : line.status === "near" ? "is-near" : "is-ok";
      return `
        <article class="tile">
          <div class="tile__top">
            <span class="tile__name">${line.label}</span>
            <span class="tile__share">${line.percent_of_income}٪</span>
          </div>
          <div class="tile__amount">${money(line.planned)} ${state.currency}</div>
          <div class="track">
            <div class="track__fill ${statusClass}" style="width:${percent}%"></div>
          </div>
          <div class="tile__meta">
            <span>صرفت <strong>${money(line.spent)}</strong></span>
            <span>${line.remaining >= 0 ? "باقي" : "زيادة"} <strong>${money(Math.abs(line.remaining))}</strong></span>
          </div>
        </article>`;
    })
    .join("");

  $("statSpent").textContent = money(state.total_spent);
  $("statSaved").textContent = money(state.actual_savings);
  $("statStatus").textContent = state.on_plan ? "ملتزم ✔" : "خارج الخطة ✖";
}

function renderAlerts(state) {
  if (!$("alerts")) return;
  $("alerts").innerHTML = state.warnings
    .map((item) => `<div class="alert alert--${item.level}">${item.message}</div>`)
    .join("");
}

function renderExpenses(state) {
  if (!$("expenseTable")) return;
  const table = $("expenseTable");
  $("expCount").textContent = state.expenses.length;

  if (state.expenses.length === 0) {
    table.innerHTML = '<p class="empty-line">لسه مفيش مصاريف. سجّل أول مصروف من جنب.</p>';
    return;
  }

  table.innerHTML = state.expenses
    .map(
      (expense) => `
      <div class="row">
        <span class="tag tag--${expense.category}">${expense.label}</span>
        <span class="row__desc">${expense.description || "—"}</span>
        <span class="row__amount">${money(expense.amount)}</span>
        <button class="row__edit" type="button" data-id="${expense.id}"
                data-amount="${expense.amount}" data-desc="${expense.description}" title="تعديل">✎</button>
        <button class="row__del" type="button" data-id="${expense.id}" title="حذف">✕</button>
      </div>`
    )
    .join("");

  table.querySelectorAll(".row__edit").forEach((button) => {
    button.addEventListener("click", async () => {
      const newAmount = prompt("المبلغ الجديد:", button.dataset.amount);
      if (newAmount === null) return;
      const newDesc = prompt("الوصف الجديد:", button.dataset.desc);
      if (newDesc === null) return;
      try {
        render(
          await callApi("/api/expense/update", {
            id: Number(button.dataset.id),
            amount: Number(newAmount),
            description: newDesc,
          })
        );
        showMessage($("expenseMsg"), "اتعدّل المصروف.", false);
      } catch (error) {
        showMessage($("expenseMsg"), error.message, true);
      }
    });
  });

  table.querySelectorAll(".row__del").forEach((button) => {
    button.addEventListener("click", async () => {
      try {
        render(await callApi("/api/expense/delete", { id: Number(button.dataset.id) }));
      } catch (error) {
        showMessage($("expenseMsg"), error.message, true);
      }
    });
  });
}

function renderReport(state) {
  if (!$("reportBody")) return;
  const body = $("reportBody");

  if (!state.income) {
    body.innerHTML = '<p class="empty-line">التقرير هيظهر بعد ما تحدد الدخل وتسجل مصاريفك.</p>';
    return;
  }

  const verdict = state.on_plan
    ? '<div class="report__verdict good">✔ ملتزم بالخطة في كل التصنيفات</div>'
    : '<div class="report__verdict bad">✖ خرجت عن الخطة في تصنيف أو أكتر</div>';

  const rows = state.lines
    .map(
      (line) => `
      <li>
        <span>${line.label} — المفروض ${money(line.planned)}</span>
        <strong>${money(line.spent)} (${Math.round(line.ratio * 100)}%)</strong>
      </li>`
    )
    .join("");

  const top = state.top_expenses
    .map((item) => `<li><span>${item.description}</span><strong>${money(item.amount)}</strong></li>`)
    .join("");

  body.innerHTML = `
    ${verdict}
    <ul class="report__list">
      ${rows}
      <li><span>عدد المصاريف المسجلة</span><strong>${state.expenses_count}</strong></li>
      <li><span>التوفير المخطط</span><strong>${money(state.planned_savings)}</strong></li>
      <li><span>التوفير الفعلي</span><strong>${money(state.actual_savings)}</strong></li>
      ${top ? '<li><span>أكبر المصاريف</span><strong></strong></li>' + top : ""}
    </ul>`;
}

function render(state) {
  renderHero(state);
  renderTiles(state);
  renderAlerts(state);
  renderExpenses(state);
  renderReport(state);

  const incomeField = $("incomeInput");
  if (incomeField && state.income && !incomeField.value) {
    incomeField.value = state.income;
  }
  if (state.message && $("expenseMsg")) {
    showMessage($("expenseMsg"), state.message, false);
  }
}

/* ------------ الأحداث ------------ */
function selectedMode() {
  return document.querySelector('input[name="mode"]:checked').value;
}

function customSplit() {
  return {
    needs: Number($("cNeeds").value || 0),
    wants: Number($("cWants").value || 0),
    savings: Number($("cSavings").value || 0),
  };
}

document.querySelectorAll('input[name="mode"]').forEach((radio) => {
  radio.addEventListener("change", () => {
    $("customBox").hidden = selectedMode() !== "custom";
  });
});

["cNeeds", "cWants", "cSavings"].forEach((id) => {
  /* on() بترجع false لو العنصر مش موجود — صفحة التحليل مفيهاش
     حقول التقسيم المخصص، ومن غير الحماية دي الكود كان بيقع كله. */
  on(id, "input", () => {
    const split = customSplit();
    const total = split.needs + split.wants + split.savings;
    const hint = $("customHint");
    hint.textContent = `المجموع الحالي ${total}٪ — لازم يساوي 100٪`;
    hint.className = "custom__hint" + (total === 100 ? "" : " bad");
  });
});

on("calcBtn", "click", async () => {
  const mode = selectedMode();
  try {
    const state = await callApi("/api/income", {
      income: Number($("incomeInput").value),
      mode,
      custom: mode === "custom" ? customSplit() : null,
    });
    render(state);
    showMessage($("incomeMsg"), "اتحسبت الخطة، شوف النتيجة تحت.", false);
  } catch (error) {
    showMessage($("incomeMsg"), error.message, true);
  }
});

on("resetBtn", "click", async () => {
  if (!confirm("هيتمسح دخل الشهر ده وكل مصاريفه. تكمل؟")) return;
  try {
    $("incomeInput").value = "";
    render(await callApi("/api/reset", {}));
    showMessage($("incomeMsg"), "اتعمل إعادة تعيين للشهر.", false);
  } catch (error) {
    showMessage($("incomeMsg"), error.message, true);
  }
});

on("addExpenseBtn", "click", async () => {
  try {
    const state = await callApi("/api/expense", {
      amount: Number($("expAmount").value),
      category: $("expCategory").value,
      description: $("expDesc").value,
    });
    $("expAmount").value = "";
    $("expDesc").value = "";
    render(state);
    showMessage($("expenseMsg"), "اتسجل المصروف.", false);
  } catch (error) {
    showMessage($("expenseMsg"), error.message, true);
  }
});

on("exportBtn", "click", async () => {
  try {
    render(await callApi("/api/export", {}));
  } catch (error) {
    showMessage($("expenseMsg"), error.message, true);
  }
});


/* =========================================================
   التحليل الإحصائي — بينادي /api/stats ويرسم النتيجة
   ========================================================= */

const CHART_TITLES = {
  distribution: "توزيع مصاريفك مقابل المنحنى الطبيعي",
  forecast: "محاكاة مونت كارلو لإجمالي الشهر",
  category_risk: "احتمال تجاوز كل تصنيف لخطته",
  poisson: "عدد عمليات الصرف اليومية مقابل بواسون",
  clt: "نظرية النهاية المركزية على مصاريفك",
  standard_error: "الخطأ المعياري وحجم العيّنة",
};

function statsCard(title, badge, rows, tone) {
  const items = rows
    .filter(Boolean)
    .map((row) =>
      Array.isArray(row)
        ? `<li><span>${row[0]}</span><strong>${row[1]}</strong></li>`
        : `<li class="wide">${row}</li>`
    )
    .join("");

  return `
    <article class="scard ${tone ? "scard--" + tone : ""}">
      <div class="scard__head">
        <h3>${title}</h3>
        ${badge ? `<span class="scard__badge">${badge}</span>` : ""}
      </div>
      <ul class="scard__list">${items}</ul>
    </article>`;
}

function unavailableCard(title, text) {
  return `
    <article class="scard scard--muted">
      <div class="scard__head"><h3>${title}</h3></div>
      <p class="scard__empty">${text}</p>
    </article>`;
}

function renderForecastCard(data, currency) {
  if (data.unavailable) return unavailableCard("توقّع آخر الشهر", data.unavailable);

  const risk = data.risk_over_income;
  const tone = risk < 30 ? "ok" : risk < 60 ? "warn" : "bad";
  const categories = data.categories
    .map((row) => `${row.label} <b>${row.risk}٪</b>`)
    .join(" · ");

  return statsCard(
    "توقّع آخر الشهر",
    `${data.simulations.toLocaleString("en-US")} محاكاة`,
    [
      ["المتوقع تخلّص الشهر على", `${money(data.expected_total)} ${currency}`],
      ["نطاق 90٪", `${money(data.p05)} — ${money(data.p95)}`],
      ["احتمال تعدّي دخلك", `${risk}٪`],
      ["متوسط الصرف اليومي", `${money(data.daily_mean)} ± ${money(data.daily_std)}`],
      ["فاضل من الشهر", `${data.days_remaining} يوم`],
      `تقريب CLT بيدّي ${money(data.clt_mean)} ± ${money(data.clt_std)} (${data.clt_risk}٪) — قريب جداً من المحاكاة.`,
      `احتمال تجاوز الخطة: ${categories}`,
    ],
    tone
  );
}

function renderAnomalyCard(data, currency) {
  if (data.unavailable) return unavailableCard("المصاريف الشاذة", data.unavailable);

  const observed = data.empirical_rule.observed;
  const flagged = data.flagged.length
    ? data.flagged
        .slice(0, 4)
        .map((item) => `<span class="flag">${item.message} <b>Z = ${item.z}</b></span>`)
        .join("")
    : '<span class="flag flag--ok">مفيش أي مصروف شاذ — كله جوه المدى الطبيعي ✔</span>';

  return statsCard(
    "المصاريف الشاذة (Z-Score)",
    `${data.flagged.length} مصروف`,
    [
      ["متوسط المصروف", `${money(data.stats.mean)} ± ${money(data.stats.std)}`],
      ["المدى الطبيعي ±2σ", `${money(data.normal_range.low)} — ${money(data.normal_range.high)}`],
      [
        "القاعدة التجريبية (المتوقع 68/95/99.7)",
        `${observed["1σ"]}٪ / ${observed["2σ"]}٪ / ${observed["3σ"]}٪`,
      ],
      `<div class="flags">${flagged}</div>`,
    ],
    data.flagged.length ? "warn" : "ok"
  );
}

function renderRhythmCard(data) {
  if (data.unavailable) return unavailableCard("إيقاع الصرف", data.unavailable);

  return statsCard(
    "إيقاع الصرف (Poisson + Exponential)",
    `λ = ${data.lambda}`,
    [
      ["متوسط عمليات الصرف في اليوم", data.lambda],
      ["احتمال يوم من غير صرف", `${data.no_spend_day}٪`],
      ["متوسط المدة بين صرفتين", `${data.mean_gap_days} يوم`],
      ["احتمال تصرف خلال 24 ساعة", `${data.within_1_day}٪`],
      ["احتمال تصرف خلال 3 أيام", `${data.within_3_days}٪`],
    ]
  );
}

function renderCommitmentCard(data) {
  if (data.unavailable) return unavailableCard("التزامك بالخطة", data.unavailable);

  return statsCard(
    "التزامك بالخطة (Binomial + Beta)",
    `${data.successes} / ${data.trials} شهر`,
    [
      ["معدل الالتزام المرصود", `${data.p_hat}٪`],
      ["تقدير Beta", `${data.beta_estimate}٪`],
      ["فترة ثقة 90٪", `${data.credible_interval[0]}٪ — ${data.credible_interval[1]}٪`],
      [`احتمال الالتزام في شهرين+ من ${data.horizon}`, `${data.at_least_two}٪`],
      data.expected_months_until_slip
        ? ["متوسط الشهور لحد أول خروج عن الخطة", `${data.expected_months_until_slip} شهر`]
        : null,
    ]
  );
}

function renderCltCard(data) {
  if (data.unavailable) return unavailableCard("نظرية النهاية المركزية", data.unavailable);

  const rows = data.experiments
    .map(
      (item) =>
        `<tr><td>${item.n}</td><td>${money(item.mean_of_means)}</td>` +
        `<td>${money(item.observed_se)}</td><td>${money(item.theoretical_se)}</td></tr>`
    )
    .join("");

  return statsCard(
    "نظرية النهاية المركزية",
    `μ = ${money(data.population.mean)}`,
    [
      /* الحاوية عشان الجدول ميتقصّش على الشاشات الضيقة */
      `<div class="mini-wrap">
         <table class="mini-table">
           <thead><tr><th>n</th><th>متوسط المتوسطات</th><th>SE فعلي</th><th>SE نظري</th></tr></thead>
           <tbody>${rows}</tbody>
         </table>
       </div>`,
      "كل ما حجم العيّنة كبر، توزيع المتوسطات قرب من الطبيعي وضاق — والخطأ المعياري نزل بـ σ/√n.",
    ]
  );
}

function renderStats(stats, currency) {
  const grid = $("statsGrid");
  grid.hidden = false;
  grid.innerHTML = [
    renderForecastCard(stats.forecast || {}, currency),
    renderAnomalyCard(stats.anomalies || {}, currency),
    renderRhythmCard(stats.rhythm || {}),
    renderCommitmentCard(stats.commitment || {}),
    renderCltCard(stats.clt || {}),
  ].join("");

  /* الشارة لازم تقول الحقيقة: في وضع الملف الحسابات بتتعمل في المتصفح */
  $("statsEngine").textContent = stats.offline
    ? "المتصفح"
    : stats.numpy
    ? "NumPy"
    : "Python core";

  const charts = $("charts");
  const entries = Object.entries(stats.charts || {});

  if (entries.length === 0) {
    charts.hidden = true;
    return;
  }

  const stamp = Date.now();   // عشان المتصفح ميعرضش نسخة قديمة من الصورة
  charts.hidden = false;
  charts.innerHTML = entries
    .map(
      ([key, file]) => `
      <figure class="chart">
        <img src="/charts/${file}?v=${stamp}" alt="${CHART_TITLES[key] || key}" loading="lazy" />
        <figcaption>${CHART_TITLES[key] || key}</figcaption>
      </figure>`
    )
    .join("");
}

on("statsBtn", "click", async () => {
  const button = $("statsBtn");
  const hint = $("statsHint");

  button.disabled = true;
  hint.textContent = "بيحسب 10,000 محاكاة ويرسم…";

  try {
    const stats = await callApi("/api/stats", { charts: true });
    renderStats(stats, "جنيه");
    hint.textContent = `آخر تحديث ${stats.generated_at}`;
  } catch (error) {
    hint.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});

on("checkBtn", "click", async () => {
  try {
    const result = await callApi("/api/check", {
      amount: Number($("checkAmount").value),
      category: $("checkCategory").value,
    });
    const isOdd = Math.abs(result.z) >= 2;
    showMessage(
      $("checkMsg"),
      `Z = ${result.z} — ${result.verdict}. متوسطك ${money(result.mean)} ± ${money(result.std)}،` +
        ` والمبلغ ده أكبر من ${result.percentile}٪ من مصاريفك.`,
      isOdd
    );
  } catch (error) {
    showMessage($("checkMsg"), error.message, true);
  }
});

/* ------------ أول تحميل ------------ */
(async function init() {
  try {
    render(await callApi("/api/state"));
  } catch (error) {
    console.error(error);
  }
})();


/* =========================================================
   التحليل الإحصائي الشامل — 12 مرحلة  (/api/analysis)
   ========================================================= */

const PIPE = { data: null, active: "phase1", rows: null };

const fixed = (value, digits = 0) =>
  Number(value || 0).toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });

/* p-value الصغيرة أوي بتتكتب كده بدل 0.0 */

/* الأرقام الصغيرة (زي ميل 0.127) بتتقرّب لصفر لو عرضناها من غير كسور،
   فبنزوّد الخانات العشرية كل ما الرقم صغر. */
/* مسميات مكتوبة جوه الرسومات نفسها (SVG).
   صفحة التحليل الإنجليزية بتستبدلها من views-en.js */
const CHART_TEXT = {
  median: "وسيط",
  axisStart: "اليوم 1",
  axisEnd: (n) => `اليوم ${n}`,
  rowsWord: "صف",
};

const smart = (value) => {
  const size = Math.abs(Number(value) || 0);
  if (size === 0) return "0";
  if (size < 1) return fixed(value, 3);
  if (size < 100) return fixed(value, 2);
  return fixed(value, 0);
};

const showP = (value) => (value < 0.0001 ? "< 0.0001" : Number(value).toFixed(4));

/* ---------- عناصر بناء بسيطة ---------- */
/* بياخد المسمى من البيانات نفسها لو بعتته، وإلا بيستخدم الافتراضي.
   كده نفس العارض بيشتغل على بيانات المصاريف وعلى أي داتاست تانية. */
const label = (data, key, fallback) =>
  (data && data.labels && data.labels[key]) || fallback;

const statRow = (label, value) =>
  `<div class="prow"><span>${label}</span><b>${value}</b></div>`;

const note = (text) => `<p class="pnote">${text}</p>`;

/* الجدول بيتلف في حاوية بتتزحلق أفقياً لوحدها — من غير كده الجداول
   العريضة (زي مصفوفة الشهور) بتمدّ الصفحة كلها على الموبايل. */
const table = (headers, rows) => `
  <div class="ptable-wrap">
    <table class="ptable">
      <thead><tr>${headers.map((head) => `<th>${head}</th>`).join("")}</tr></thead>
      <tbody>${rows
        .map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join("")}</tr>`)
        .join("")}</tbody>
    </table>
  </div>`;

/* ---------- رسومات SVG ---------- */
function barChart(labels, values) {
  const W = 320, H = 150, PAD = 26, BASE = H - 22;
  const peak = Math.max(...values) || 1;
  const width = (W - PAD * 2) / values.length - 10;

  const bars = values
    .map((value, index) => {
      const x = PAD + index * ((W - PAD * 2) / values.length) + 5;
      const height = (value / peak) * (BASE - 16);
      return `
        <rect x="${x}" y="${BASE - height}" width="${width}" height="${height}"
              rx="3" fill="url(#gGold)" />
        <text x="${x + width / 2}" y="${BASE - height - 5}" font-size="9"
              fill="var(--gold-soft)" text-anchor="middle">${fixed(value)}</text>
        <text x="${x + width / 2}" y="${H - 6}" font-size="9"
              fill="var(--muted)" text-anchor="middle">${labels[index]}</text>`;
    })
    .join("");

  return svgWrap(W, H, bars);
}

function histogramChart(bins) {
  const W = 320, H = 150, PAD = 12, BASE = H - 24;
  const peak = Math.max(...bins.map((bin) => bin.count)) || 1;
  const width = (W - PAD * 2) / bins.length - 2;

  const bars = bins
    .map((bin, index) => {
      const x = PAD + index * ((W - PAD * 2) / bins.length);
      const height = (bin.count / peak) * (BASE - 10);
      return `<rect x="${x}" y="${BASE - height}" width="${width}" height="${height}"
                    rx="2" fill="url(#gGold)"><title>${bin.label}: ${bin.count}</title></rect>`;
    })
    .join("");

  const labels =
    `<text x="${PAD}" y="${H - 8}" font-size="9" fill="var(--muted)" text-anchor="start">${fixed(bins[0].start)}</text>` +
    `<text x="${W - PAD}" y="${H - 8}" font-size="9" fill="var(--muted)" text-anchor="end">${fixed(bins[bins.length - 1].end)}</text>`;

  return svgWrap(W, H, bars + labels);
}

function boxPlot(box, outliers) {
  const W = 320, H = 110, PAD = 18;
  const all = [box.min, box.max, ...(outliers || [])];
  const low = Math.min(...all);
  const high = Math.max(...all) || 1;
  const scale = (value) => PAD + ((value - low) / (high - low || 1)) * (W - PAD * 2);
  const mid = 46;

  const dots = (outliers || [])
    .map((value) => `<circle cx="${scale(value)}" cy="${mid}" r="3"
                       fill="none" stroke="var(--over)" stroke-width="1.5" />`)
    .join("");

  /* لما الشواذ بعيدة أوي، الصندوق بيبقى ضيق والأرقام بتتداخل فوق بعض.
     في الحالة دي بنكتب الملخص سطر واحد تحت الرسمة بدل 3 أرقام متلزقين. */
  const boxWidth = scale(box.q3) - scale(box.q1);
  const labels =
    boxWidth >= 70
      ? `<text x="${scale(box.q1)}" y="${mid + 34}" font-size="9" fill="var(--muted)" text-anchor="middle">Q1 ${fixed(box.q1)}</text>
         <text x="${scale(box.median)}" y="${mid - 24}" font-size="9" fill="var(--gold-soft)" text-anchor="middle">${CHART_TEXT.median} ${fixed(box.median)}</text>
         <text x="${scale(box.q3)}" y="${mid + 34}" font-size="9" fill="var(--muted)" text-anchor="middle">Q3 ${fixed(box.q3)}</text>`
      : `<text x="${W / 2}" y="${H - 6}" font-size="9" fill="var(--muted)" text-anchor="middle">Q1 ${fixed(box.q1)}  ·  ${CHART_TEXT.median} ${fixed(box.median)}  ·  Q3 ${fixed(box.q3)}</text>`;

  return svgWrap(
    W,
    H,
    `<line x1="${scale(box.min)}" y1="${mid}" x2="${scale(box.q1)}" y2="${mid}"
           stroke="var(--muted)" stroke-dasharray="3 3" />
     <line x1="${scale(box.q3)}" y1="${mid}" x2="${scale(box.max)}" y2="${mid}"
           stroke="var(--muted)" stroke-dasharray="3 3" />
     <line x1="${scale(box.min)}" y1="${mid - 9}" x2="${scale(box.min)}" y2="${mid + 9}" stroke="var(--muted)" />
     <line x1="${scale(box.max)}" y1="${mid - 9}" x2="${scale(box.max)}" y2="${mid + 9}" stroke="var(--muted)" />
     <rect x="${scale(box.q1)}" y="${mid - 17}" width="${Math.max(scale(box.q3) - scale(box.q1), 2)}"
           height="34" rx="4" fill="var(--gold)" fill-opacity="0.22" stroke="var(--gold)" />
     <line x1="${scale(box.median)}" y1="${mid - 17}" x2="${scale(box.median)}" y2="${mid + 17}"
           stroke="var(--gold-soft)" stroke-width="2.5" />
     ${dots}
     ${labels}`
  );
}

function scatterChart(points) {
  const W = 320, H = 150, PAD = 22, BASE = H - 20;
  const xs = points.map((point) => point.x);
  const ys = points.map((point) => point.y);
  const maxX = Math.max(...xs) || 1;
  const maxY = Math.max(...ys) || 1;

  const dots = points
    .map(
      (point) =>
        `<circle cx="${PAD + (point.x / maxX) * (W - PAD * 2)}"
                 cy="${BASE - (point.y / maxY) * (BASE - 12)}" r="2.6"
                 fill="var(--gold)" fill-opacity="0.75" />`
    )
    .join("");

  return svgWrap(
    W,
    H,
    `<line x1="${PAD}" y1="${BASE}" x2="${W - PAD}" y2="${BASE}" stroke="rgba(255,255,255,0.16)" />
     ${dots}
     <text x="${PAD}" y="${H - 5}" font-size="9" fill="var(--muted)">${CHART_TEXT.axisStart}</text>
     <text x="${W - PAD}" y="${H - 5}" font-size="9" fill="var(--muted)" text-anchor="end">${CHART_TEXT.axisEnd(maxX)}</text>`
  );
}

function lineChart(points) {
  const W = 320, H = 150, PAD = 22, BASE = H - 20;
  if (!points.length) return "";

  const maxX = Math.max(...points.map((point) => point.t)) || 1;
  const maxY = Math.max(...points.map((point) => point.s)) || 1;
  const sx = (t) => PAD + (t / maxX) * (W - PAD * 2);
  const sy = (s) => BASE - (s / maxY) * (BASE - 12);

  const path = points
    .map((point, index) => `${index ? "L" : "M"}${sx(point.t).toFixed(1)},${sy(point.s).toFixed(1)}`)
    .join(" ");

  return svgWrap(
    W,
    H,
    `<path d="${path} L${sx(maxX)},${BASE} L${sx(points[0].t)},${BASE} Z" fill="url(#gArea)" />
     <path d="${path}" fill="none" stroke="var(--gold)" stroke-width="2" stroke-linejoin="round" />
     <text x="${W - PAD}" y="18" font-size="9" fill="var(--gold-soft)" text-anchor="end">${fixed(maxY)}</text>`
  );
}

function svgWrap(width, height, body) {
  return `
    <svg class="pchart" viewBox="0 0 ${width} ${height}" role="img">
      <defs>
        <linearGradient id="gGold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="var(--gold-soft)" /><stop offset="100%" stop-color="var(--gold-deep)" />
        </linearGradient>
        <linearGradient id="gArea" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="var(--gold)" stop-opacity="0.4" />
          <stop offset="100%" stop-color="var(--gold)" stop-opacity="0.02" />
        </linearGradient>
      </defs>
      ${body}
    </svg>`;
}

/* ---------- عرض كل مرحلة ---------- */
const PHASE_VIEWS = {
  phase1(data) {
    const dropped = data.dropped_detail;
    return (
      statRow("صفوف خام", fixed(data.raw_rows)) +
      statRow("صفوف نضيفة", fixed(data.clean_rows)) +
      statRow("اتشال", `${fixed(data.dropped_total)} صف`) +
      table(
        ["سبب الاستبعاد", "عدد"],
        [
          ["قيم ناقصة", dropped.missing],
          ["مبلغ غير صحيح", dropped.invalid_amount],
          ["تصنيف مجهول", dropped.unknown_category],
          ["صف مكرر", dropped.duplicate],
        ]
      ) +
      `<h4 class="phead">المتغيرات</h4>` +
      table(
        ["المتغيّر", "النوع"],
        [
          ...data.variables.numerical.map((item) => [item.label, `رقمي — ${item.type}`]),
          ...data.variables.categorical.map((item) => [
            item.label,
            `فئوي — ${item.levels.length} مستويات`,
          ]),
        ]
      ) +
      note(data.interpretation)
    );
  },

  phase2(data) {
    return (
      `<div class="pgrid">
        ${statRow("المتوسط", fixed(data.mean))}
        ${statRow("الوسيط", fixed(data.median))}
        ${statRow("المنوال", `${fixed(data.mode.value)} (${data.mode.range})`)}
        ${statRow("المدى", fixed(data.range))}
        ${statRow("التباين", fixed(data.variance))}
        ${statRow("الانحراف المعياري", fixed(data.std))}
        ${statRow("Q1", fixed(data.q1))}
        ${statRow("Q3", fixed(data.q3))}
        ${statRow("المدى الربيعي IQR", fixed(data.iqr))}
        ${statRow("معامل الاختلاف", `${data.cv}٪`)}
      </div>` +
      `<h4 class="phead">حسب التصنيف</h4>` +
      table(
        ["التصنيف", "عدد", "متوسط", "وسيط", "انحراف", "إجمالي"],
        data.per_category.map((row) => [
          row.label,
          row.n,
          fixed(row.mean),
          fixed(row.median),
          fixed(row.std),
          fixed(row.total),
        ])
      ) +
      note(data.interpretation)
    );
  },

  phase3(data) {
    return (
      `<h4 class="phead">التوزيع التكراري</h4>` +
      histogramChart(data.frequency) +
      table(
        ["الفئة", "تكرار", "٪", "تراكمي ٪"],
        data.frequency
          .filter((bin) => bin.count > 0)
          .map((bin) => [bin.label, bin.count, bin.percent, bin.cumulative_percent])
      ) +
      `<h4 class="phead">البوكس بلوت</h4>` +
      boxPlot(data.box_plot, data.outliers.map((item) => item.amount)) +
      `<div class="pgrid">
        ${statRow("أقل قيمة (بدون شواذ)", fixed(data.box_plot.min))}
        ${statRow("Q1", fixed(data.box_plot.q1))}
        ${statRow("الوسيط", fixed(data.box_plot.median))}
        ${statRow("Q3", fixed(data.box_plot.q3))}
        ${statRow("أكبر قيمة (بدون شواذ)", fixed(data.box_plot.max))}
        ${statRow("الحد الأدنى للشذوذ", fixed(data.box_plot.lower_fence))}
        ${statRow("الحد الأعلى للشذوذ", fixed(data.box_plot.upper_fence))}
        ${statRow("عدد الشواذ", data.outliers_count)}
        ${statRow("الالتواء", data.shape.skewness)}
        ${statRow("التفلطح", data.shape.kurtosis)}
        ${statRow("شكل التوزيع", data.shape.label)}
      </div>` +
      (data.outliers.length
        ? table(
            label(data, "outlierHeaders", ["المبلغ", "التاريخ", "التصنيف", "الوصف"]),
            data.outliers.map((item) => [
              fixed(item.amount),
              item.day,
              item.label,
              item.description || "—",
            ])
          )
        : "") +
      note(data.interpretation)
    );
  },

  phase4(data) {
    const matrix = data.matrix;
    return (
      `<h4 class="phead">متجه الإنفاق والضرب النقطي</h4>` +
      table(
        ["", ...data.labels],
        [
          ["متجه الإنفاق", ...data.spend_vector.map((value) => fixed(value))],
          ["متجه الأوزان", ...data.weight_vector],
          ["× 1.10 (ضرب قياسي)", ...data.scaled_vector.map((value) => fixed(value))],
        ]
      ) +
      `<div class="pgrid">
        ${statRow("حاصل الضرب النقطي", fixed(data.dot_product))}
        ${statRow("طول المتجه ‖v‖", fixed(data.magnitude))}
        ${statRow("تكلفة زيادة 10٪", fixed(data.extra_cost))}
        ${statRow("جيب تمام الزاوية", data.alignment.cosine)}
        ${statRow("الزاوية عن الخطة", `${data.alignment.angle_degrees}°`)}
      </div>` +
      `<h4 class="phead">المصفوفة (${matrix.shape}) — شهور × تصنيفات</h4>` +
      table(
        ["الشهر", ...matrix.columns, "إجمالي"],
        matrix.values.map((row, index) => [
          matrix.rows[index],
          ...row.map((value) => fixed(value)),
          `<b>${fixed(matrix.row_totals[index])}</b>`,
        ])
      ) +
      note(data.interpretation)
    );
  },

  phase5(data) {
    return (
      `<h4 class="phead">احتمالات بسيطة</h4>` +
      table(
        ["الحدث", "الرمز", "الحساب", "الاحتمال"],
        data.simple.map((item) => [
          item.event,
          item.notation,
          `${item.count} / ${item.of}`,
          `${item.percent}٪`,
        ])
      ) +
      `<h4 class="phead">احتمالات شرطية</h4>` +
      table(
        ["الحدث", "الرمز", "الحساب", "الاحتمال"],
        data.conditional.map((item) => [
          item.event,
          item.notation,
          `${item.count} / ${item.of}`,
          `${item.percent}٪`,
        ])
      ) +
      statRow(
        "هل الحدثين مستقلين؟",
        data.independence.independent ? "تقريباً مستقلين" : "لأ — مرتبطين"
      ) +
      `<h4 class="phead">القيمة المتوقعة E(X)</h4>` +
      table(
        ["التصنيف", "P(X)", "متوسط", "المساهمة"],
        data.expected_value.table.map((row) => [
          row.label,
          row.probability,
          fixed(row.mean),
          fixed(row.contribution),
        ])
      ) +
      statRow(label(data, "expected_one", "E(X) للمصروف الواحد"), smart(data.expected_value.per_expense)) +
      statRow(label(data, "expected_day", "E(X) لليوم"), smart(data.expected_value.per_day)) +
      note(data.interpretation)
    );
  },

  phase6(data) {
    return (
      table(
        ["", "المجتمع", "العيّنة"],
        [
          ["الحجم n", data.population.n, data.sample.n],
          ["المتوسط", fixed(data.population.mean), fixed(data.sample.mean)],
          ["الانحراف", fixed(data.population.std), fixed(data.sample.std)],
        ]
      ) +
      `<div class="pgrid">
        ${statRow("الخطأ المعياري SE", fixed(data.sample.standard_error, 2))}
        ${statRow("نسبة العيّنة", `${data.sample.fraction}٪`)}
        ${statRow("فرق التقدير", fixed(data.comparison.error, 2))}
        ${statRow("نسبة الخطأ", `${data.comparison.error_percent}٪`)}
        ${statRow("SE فعلي (400 عيّنة)", fixed(data.sampling_distribution.observed_se, 2))}
        ${statRow("SE نظري σ/√n", fixed(data.sampling_distribution.theoretical_se, 2))}
      </div>` +
      note(data.interpretation)
    );
  },

  phase7(data) {
    const main = data.expense_mean;
    return (
      `<div class="ci">
        <div class="ci__bar">
          <span>${fixed(main.low)}</span>
          <div class="ci__track"><i></i><b>${fixed(main.mean)}</b></div>
          <span>${fixed(main.high)}</span>
        </div>
      </div>` +
      `<div class="pgrid">
        ${statRow("مستوى الثقة", `${main.confidence}٪`)}
        ${statRow("المتوسط", fixed(main.mean))}
        ${statRow("الخطأ المعياري", fixed(main.standard_error, 2))}
        ${statRow("t الحرجة", main.t_critical)}
        ${statRow("هامش الخطأ", `± ${fixed(main.margin)}`)}
        ${statRow(label(data, "second", "الفترة اليومية"), `${smart(data.daily_mean.low)} — ${smart(data.daily_mean.high)}`)}
      </div>` +
      (data.per_category.length
        ? `<h4 class="phead">فترات الثقة حسب التصنيف</h4>` +
          table(
            ["التصنيف", "n", "المتوسط", "الفترة 95٪"],
            data.per_category.map((row) => [
              row.label,
              row.n,
              fixed(row.mean),
              `${fixed(row.low)} — ${fixed(row.high)}`,
            ])
          )
        : "") +
      note(data.interpretation)
    );
  },

  phase8(data) {
    return (
      `<div class="hyp">
        <p class="hyp__h">${data.h0}</p>
        <p class="hyp__h">${data.h1}</p>
      </div>` +
      `<div class="pgrid">
        ${statRow("الاختبار", data.test)}
        ${statRow("مستوى الدلالة α", data.alpha)}
        ${statRow("حجم العيّنة n", data.n)}
        ${statRow("متوسط العيّنة", fixed(data.sample_mean))}
        ${statRow("القيمة المرجعية μ₀", fixed(data.reference))}
        ${statRow("الخطأ المعياري", fixed(data.standard_error, 2))}
        ${statRow("إحصائية الاختبار t", data.t_statistic)}
        ${statRow("درجات الحرية df", data.df)}
        ${statRow("t الحرجة", `± ${data.t_critical}`)}
        ${statRow("p-value", showP(data.p_value))}
      </div>` +
      `<p class="verdict ${data.reject_null ? "verdict--reject" : "verdict--keep"}">${data.decision}</p>` +
      note(data.conclusion)
    );
  },

  phase9(data) {
    if (data.unavailable) return note(data.unavailable);
    return (
      `<div class="hyp">
        <p class="hyp__h">${data.h0}</p>
        <p class="hyp__h">${data.h1}</p>
      </div>` +
      table(
        ["المجموعة", "n", "المتوسط", "الانحراف"],
        data.groups.map((row) => [row.name, row.n, fixed(row.mean), fixed(row.std)])
      ) +
      `<h4 class="phead">جدول تحليل التباين</h4>` +
      table(
        ["المصدر", "SS", "df", "MS"],
        [
          ["بين المجموعات", fixed(data.table.between.ss), data.table.between.df, fixed(data.table.between.ms)],
          ["داخل المجموعات", fixed(data.table.within.ss), data.table.within.df, fixed(data.table.within.ms)],
        ]
      ) +
      `<div class="pgrid">
        ${statRow("المتوسط العام", fixed(data.grand_mean))}
        ${statRow("إحصائية F", data.f_statistic)}
        ${statRow("p-value", showP(data.p_value))}
        ${statRow("α", data.alpha)}
      </div>` +
      `<p class="verdict ${data.reject_null ? "verdict--reject" : "verdict--keep"}">${data.decision}</p>` +
      note(data.conclusion)
    );
  },

  phase10(data) {
    if (data.unavailable) return note(data.unavailable);
    return (
      lineChart(data.points) +
      `<div class="pgrid">
        ${statRow(label(data, "period", "الشهر المدروس"), data.month)}
        ${statRow(label(data, "count", "عدد الأيام"), data.days)}
        ${statRow("الدالة الخطية", data.linear.equation)}
        ${statRow("المشتقة", data.linear.derivative)}
        ${statRow("R²", data.linear.r_squared)}
        ${statRow("الدالة التربيعية", data.quadratic.equation)}
        ${statRow("مشتقتها", data.quadratic.derivative)}
        ${statRow("المشتقة الثانية", smart(data.quadratic.second_derivative))}
        ${statRow(label(data, "rateStart", "معدل أول الشهر"), smart(data.rates.at_start))}
        ${statRow(label(data, "rateEnd", "معدل آخر الشهر"), smart(data.rates.at_end))}
        ${statRow("الاتجاه", data.trend)}
        ${data.reach_income_day ? statRow("متوقع تستهلك دخلك يوم", data.reach_income_day) : ""}
      </div>` +
      note(data.interpretation)
    );
  },

  phase11(data) {
    return (
      `<div class="pviz">
        <div class="pviz__item">
          <h4 class="phead">${data.bar.title}</h4>
          ${barChart(data.bar.labels, data.bar.values)}
          <p class="pwhy">${data.bar.why}</p>
        </div>
        <div class="pviz__item">
          <h4 class="phead">${data.histogram.title}</h4>
          ${histogramChart(data.histogram.bins)}
          <p class="pwhy">${data.histogram.why}</p>
        </div>
        <div class="pviz__item">
          <h4 class="phead">${data.box.title}</h4>
          ${boxPlot(data.box.data, data.box.outliers)}
          <p class="pwhy">${data.box.why}</p>
        </div>
        <div class="pviz__item">
          <h4 class="phead">${data.scatter.title}</h4>
          ${scatterChart(data.scatter.points)}
          <p class="pwhy">${data.scatter.why}</p>
        </div>
        <div class="pviz__item">
          <h4 class="phead">${data.line.title}</h4>
          ${lineChart(data.line.points)}
          <p class="pwhy">${data.line.why}</p>
        </div>
      </div>` + note(data.interpretation)
    );
  },

  phase12(data) {
    return (
      `<h4 class="phead">أهم النتائج</h4>
       <ul class="plist">${data.findings.map((item) => `<li>${item}</li>`).join("")}</ul>` +
      `<h4 class="phead">النتائج الإحصائية</h4>` +
      table(
        ["الاختبار", "النتيجة", "القرار"],
        data.statistical_results.map((row) => [row.name, row.result, row.decision])
      ) +
      `<h4 class="phead">العلاقات المهمة</h4>
       <ul class="plist">${data.relationships.map((item) => `<li>${item}</li>`).join("")}</ul>` +
      `<h4 class="phead">الخلاصة</h4>${note(data.conclusion)}` +
      `<h4 class="phead">تطويرات مستقبلية</h4>
       <ul class="plist">${data.improvements.map((item) => `<li>${item}</li>`).join("")}</ul>`
    );
  },
};


/* بيعلّم الجداول اللي أعرض من الشاشة عشان تظهر ملاحظة «اسحب».
   بنقيس بعد الرسم مش قبله — عشان منقولش للمستخدم اسحب وهو شايف كله. */
function markScrollableTables() {
  document.querySelectorAll(".ptable-wrap").forEach((wrap) => {
    wrap.classList.toggle("is-scrollable", wrap.scrollWidth > wrap.clientWidth + 2);
  });
}


/* بتعرض نتيجة الـ 12 مرحلة أياً كان مصدرها: السيرفر، المحرك المحلي،
   أو المحرك العام اللي بيشتغل على أي داتاست. */
function showPipeline(data) {
  PIPE.data = data;

  $("pipeNav").innerHTML = Object.keys(data.titles)
    .map(
      (key) =>
        `<button type="button" data-phase="${key}" class="${key === "phase1" ? "on" : ""}">${data.titles[key]}</button>`
    )
    .join("");

  $("pipeBody").hidden = false;
  if ($("pipeRows")) $("pipeRows").textContent = `${fixed(data.rows)} ${CHART_TEXT.rowsWord}`;
  renderPhase("phase1");
}

function renderPhase(key) {
  PIPE.active = key;
  const data = PIPE.data[key];
  const panel = $("pipePanel");

  $("pipeNav")
    .querySelectorAll("button")
    .forEach((button) => button.classList.toggle("on", button.dataset.phase === key));

  if (!data || data.error) {
    panel.innerHTML = note(data ? data.error : "المرحلة دي مفيهاش نتائج.");
    return;
  }

  panel.innerHTML =
    `<h3 class="ptitle">${PIPE.data.titles[key]}</h3>` + PHASE_VIEWS[key](data);

  markScrollableTables();
}

on("pipeBtn", "click", async () => {
    const button = $("pipeBtn");
    const hint = $("pipeHint");
    button.disabled = true;
    hint.textContent = "بيشغّل الـ 12 مرحلة…";

    try {
      /* قائمة المصدر موجودة في الصفحة الكاملة بس — في صفحة التحليل
         البيانات بتكون متحمّلة في المحرك فبنستخدمها زي ما هي. */
      const sourceSelect = $("pipeSource");
      const data = await callApi("/api/analysis", {
        source: PIPE.rows ? "upload" : sourceSelect ? sourceSelect.value : "app",
        rows: PIPE.rows || null,
      });

      showPipeline(data);
      hint.textContent = `اتحلّل ${fixed(data.rows)} صف`;
    } catch (error) {
      hint.textContent = error.message;
    } finally {
      button.disabled = false;
    }
  });

on("pipeNav", "click", (event) => {
    const button = event.target.closest("[data-phase]");
    if (button) renderPhase(button.dataset.phase);
  });

/* رفع ملف CSV: بيتقرا في المتصفح وبيتبعت كصفوف — بيشتغل في الوضعين */
on("pipeFile", "change", async (event) => {
    const file = event.target.files && event.target.files[0];
    if (!file) return;

    try {
      const text = await file.text();
      PIPE.rows = window.OfflineAnalysis.parseCsv(text);
      $("pipeHint").textContent = `${file.name}: ${PIPE.rows.length} صف جاهز — دوس شغّل`;
      $("pipeSource").disabled = true;
    } catch (error) {
      $("pipeHint").textContent = `مقدرتش أقرا الملف: ${error.message}`;
    }
  });

on("pipeSource", "change", () => {
    PIPE.rows = null;
    if ($("pipeFile")) $("pipeFile").value = "";
  });

window.addEventListener("resize", markScrollableTables);


/* =========================================================
   زرار الرجوع لأول الصفحة
   ========================================================= */

const TOP_BUTTON_OFFSET = 420;        // بعد كام بكسل يظهر الزرار

(function setupScrollToTop() {
  const button = $("toTopBtn");
  if (!button) return;

  /* بنستخدم requestAnimationFrame عشان الحساب ميتعملش مع كل بكسل
     أثناء التمرير — ده بيخلي التمرير ناعم على الموبايل. */
  let ticking = false;

  function update() {
    const scrolled = window.scrollY || document.documentElement.scrollTop;
    const show = scrolled > TOP_BUTTON_OFFSET;

    button.hidden = !show;
    button.classList.toggle("is-visible", show);
    ticking = false;
  }

  window.addEventListener(
    "scroll",
    () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(update);
    },
    { passive: true }
  );

  button.addEventListener("click", () => {
    /* لو المستخدم مفعّل «تقليل الحركة» في إعدادات جهازه، بنرجع فوراً */
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    window.scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" });
  });

  update();
})();
