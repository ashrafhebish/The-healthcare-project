/* =========================================================
   analysis-page.js — صفحة الـ 12 مرحلة على أي داتاست

   الصفحة دي مش مربوطة بالمصاريف: بتاخد أي ملف CSV، بتكتشف أعمدته،
   وبتسيب المستخدم يختار:
     • العمود الرقمي المدروس        (كل الإحصاء الوصفي والتوزيع عليه)
     • عمود التجميع                 (المقارنة و ANOVA والاحتمال الشرطي)
     • عمود المقارنة                (التفاضل والانتشار)

   الحسابات في generic-analysis.js، والعرض في app.js — الملف ده بيوصّل بينهم.
   ========================================================= */

(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);

  let rows = null;        // صفوف الملف المرفوع
  let profile = null;     // وصف كل عمود
  let sourceName = "";

  function say(text, bad) {
    const box = $("dataMsg");
    box.textContent = text;
    box.className = "msg " + (bad ? "bad" : "good");
  }

  /* ---------- عرض جدول الأعمدة عشان المستخدم يفهم داتاه ---------- */
  function renderProfile() {
    const body = profile
      .map(
        (column) => `
        <tr>
          <td>${column.name}</td>
          <td>${column.numeric ? "numeric" : "categorical"}${column.id ? " · id" : ""}</td>
          <td>${column.distinct}</td>
          <td>${column.missingPercent}%</td>
          <td>${column.sample}</td>
        </tr>`
      )
      .join("");

    $("profileBox").innerHTML = `
      <table class="ptable">
        <thead>
          <tr><th>Column</th><th>Type</th><th>Distinct</th><th>Missing</th><th>Example</th></tr>
        </thead>
        <tbody>${body}</tbody>
      </table>`;
  }

  /* ---------- ملا القوائم بالأعمدة المناسبة لكل دور ---------- */
  function fillSelects() {
    const suggestion = window.GenericAnalysis.suggestColumns(profile);

    const numeric = profile.filter((c) => c.numeric && !c.id);
    const groupable = profile.filter((c) => c.categorical && c.distinct >= 2 && c.distinct <= 20);

    const options = (list, selected, extra) =>
      (extra ? `<option value="">${extra}</option>` : "") +
      list
        .map(
          (c) =>
            `<option value="${c.name}" ${c.name === selected ? "selected" : ""}>` +
            `${c.name} (${c.distinct} values)</option>`
        )
        .join("");

    $("colValue").innerHTML = options(numeric, suggestion.value);
    $("colGroup").innerHTML = options(groupable, suggestion.group, "— no grouping —");
    $("colCompare").innerHTML = options(numeric, suggestion.compare, "— no comparison —");

    if (!numeric.length) {
      say("This file has no numeric column — statistical analysis needs numbers.", true);
      return false;
    }
    return true;
  }

  /* ---------- تحميل صفوف جاهزة ---------- */
  function loadRows(parsed, name) {
    if (!parsed.length) {
      say("No rows found — the file must be a CSV with a header line.", true);
      return;
    }

    rows = parsed;
    sourceName = name;
    profile = window.GenericAnalysis.profileColumns(rows);

    renderProfile();
    if (!fillSelects()) return;

    $("columnBox").hidden = false;
    $("fileHint").textContent = `${name} · ${rows.length} rows · ${profile.length} columns`;
    say(`${name}: ${rows.length} rows read. Review the columns below, then run the analysis.`, false);
  }

  /* ---------- رفع ملف ---------- */
  $("dataFile").addEventListener("change", async (event) => {
    const file = event.target.files && event.target.files[0];
    if (!file) return;

    try {
      /* false = خلّي أسماء الأعمدة زي ما هي (مش small letters) */
      const parsed = window.OfflineAnalysis.parseCsv(await file.text(), false);
      loadRows(parsed, file.name);
    } catch (error) {
      say(`Could not read the file: ${error.message}`, true);
    }
  });

  /* ---------- داتاست جاهزة للتجربة ---------- */
  $("demoBtn").addEventListener("click", () => {
    if (!window.EMBEDDED_DATASET) {
      say("No sample dataset bundled in this build — upload a CSV instead.", true);
      return;
    }
    loadRows(
      window.OfflineAnalysis.parseCsv(window.EMBEDDED_DATASET, false),
      "Sample dataset"
    );
  });

  /* ---------- التشغيل ---------- */
  $("runBtn").addEventListener("click", () => {
    if (!rows) {
      say("Upload a file first.", true);
      return;
    }

    const options = {
      value: $("colValue").value,
      group: $("colGroup").value || null,
      compare: $("colCompare").value || null,
      reference: $("refValue").value,
    };

    if (!options.value) {
      say("Pick the numeric column to analyse.", true);
      return;
    }

    const button = $("runBtn");
    button.disabled = true;

    try {
      const result = window.GenericAnalysis.run(rows, options);

      /* showPipeline متعرّفة في app.js — نفس العرض بتاع الصفحة الكاملة */
      showPipeline(result);

      say(
        `${sourceName}: analysed ${result.rows} rows on "${options.value}"` +
          (options.group ? `, grouped by "${options.group}"` : "") +
          (options.compare ? `, compared against "${options.compare}"` : "") + ".",
        false
      );

      $("pipeline").scrollIntoView({ behavior: "smooth", block: "nearest" });
    } catch (error) {
      say(error.message, true);
    } finally {
      button.disabled = false;
    }
  });
})();
