/* =========================================================
   themes.js — تبديل ألوان الصفحة

   كل ثيم مجرد مجموعة متغيّرات CSS بتتحط على <html>، فالتبديل
   لحظي ومفيش إعادة تحميل. الاختيار بيتحفظ على الجهاز.

   اللون المميّز متعرّف مرتين عن قصد:
     --gold      →  للاستخدام المباشر (حدود، نصوص)
     --accent-rgb →  للشفافيات rgba(...) لأن CSS مبتعرفش
                     تفكّك اللون لمكوّناته لوحدها
   ========================================================= */

(function () {
  "use strict";

  const THEMES = {
    gold: {
      name: "Gold",
      swatch: "#e0a54a",
      vars: {
        "--bg": "#071522",
        "--accent-rgb": "224, 165, 74",
        "--gold": "#e0a54a",
        "--gold-soft": "#f2ca8a",
        "--gold-deep": "#b9822c",
      },
    },

    ocean: {
      name: "Ocean",
      swatch: "#38bdf8",
      vars: {
        "--bg": "#061520",
        "--accent-rgb": "56, 189, 248",
        "--gold": "#38bdf8",
        "--gold-soft": "#7dd3fc",
        "--gold-deep": "#0284a8",
      },
    },

    indigo: {
      name: "Indigo",
      swatch: "#a78bfa",
      vars: {
        "--bg": "#0d0b1f",
        "--accent-rgb": "167, 139, 250",
        "--gold": "#a78bfa",
        "--gold-soft": "#c9b8ff",
        "--gold-deep": "#6d4fd0",
      },
    },

    emerald: {
      name: "Emerald",
      swatch: "#34d399",
      vars: {
        "--bg": "#04160f",
        "--accent-rgb": "52, 211, 153",
        "--gold": "#34d399",
        "--gold-soft": "#8af0c6",
        "--gold-deep": "#12876a",
      },
    },

    slate: {
      name: "Slate",
      swatch: "#cbd5e1",
      vars: {
        "--bg": "#0b0f14",
        "--accent-rgb": "203, 213, 225",
        "--gold": "#cbd5e1",
        "--gold-soft": "#e8eef5",
        "--gold-deep": "#8fa0b3",
      },
    },
  };

  /* الأشكال: كل واحد بيغيّر الطابع كله (خطوط، حواف، كثافة)،
     واللون المميّز بيفضل مستقل عنه فتقدر تركّب أي لون على أي شكل. */
  const SKINS = [
    { key: "", name: "Modern" },
    { key: "soft", name: "Soft" },
    { key: "mono", name: "Mono" },
    { key: "paper", name: "Paper" },
  ];

  const STORAGE_KEY = "analysis_theme";
  const SKIN_KEY = "analysis_skin";

  /* الأشكال الفاتحة بتحدد خلفيتها بنفسها، والثيم بيحدد اللون المميّز بس.
     من غير الاستثناء ده، الخلفية الداكنة بتاعة الثيم (بتتكتب inline)
     كانت بتتغلّب على الشكل الفاتح ويطلع نص غامق على خلفية غامقة. */
  const LIGHT_SKINS = new Set(["paper"]);

  const state = { theme: "gold", skin: "" };

  function apply(key) {
    state.theme = THEMES[key] ? key : "gold";
    const theme = THEMES[state.theme];
    const root = document.documentElement;

    const light = LIGHT_SKINS.has(state.skin);

    Object.entries(theme.vars).forEach(([name, value]) => {
      /* الخلفية: الشكل الفاتح بيحددها بنفسه */
      if (name === "--bg" && light) {
        root.style.removeProperty(name);
        return;
      }

      /* --gold-soft معمولة عشان تبان على خلفية داكنة، وعلى الورق
         الفاتح بتبقى شبه مختفية. فبنبدّلها بالدرجة الغامقة. */
      if (name === "--gold-soft" && light) {
        root.style.setProperty(name, theme.vars["--gold-deep"]);
        return;
      }

      root.style.setProperty(name, value);
    });

    /* شريط المتصفح على الموبايل ياخد نفس لون الخلفية */
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) {
      /* الشكل الفاتح بيتجاهل خلفية الثيم، فبناخد القيمة المحسوبة الفعلية */
      meta.setAttribute(
        "content",
        getComputedStyle(root).getPropertyValue("--bg").trim() || theme.vars["--bg"]
      );
    }

    try {
      localStorage.setItem(STORAGE_KEY, key);
    } catch (error) {
      /* بعض المتصفحات بتقفل التخزين على file:// — التبديل بيفضل شغال */
    }

    document.querySelectorAll(".theme__dot").forEach((dot) => {
      dot.classList.toggle("on", dot.dataset.theme === state.theme);
      dot.setAttribute("aria-pressed", dot.dataset.theme === state.theme ? "true" : "false");
    });
  }

  function applySkin(key) {
    const root = document.documentElement;
    state.skin = key;

    if (key) root.setAttribute("data-skin", key);
    else root.removeAttribute("data-skin");

    try {
      localStorage.setItem(SKIN_KEY, key);
    } catch (error) {
      /* التخزين مقفول — التبديل لسه شغال */
    }

    document.querySelectorAll(".skins button").forEach((button) => {
      button.classList.toggle("on", button.dataset.skin === key);
      button.setAttribute("aria-pressed", button.dataset.skin === key ? "true" : "false");
    });

    /* إعادة تطبيق الثيم: هو اللي بيقرر يحط خلفية ولا يسيبها للشكل */
    apply(state.theme);
  }

  function buildSkins() {
    const holder = document.getElementById("skinBar");
    if (!holder) return;

    holder.innerHTML = SKINS.map(
      (skin) =>
        `<button type="button" data-skin="${skin.key}">${skin.name}</button>`
    ).join("");

    holder.addEventListener("click", (event) => {
      const button = event.target.closest("[data-skin]");
      if (button) applySkin(button.dataset.skin);
    });

    let saved = "";
    try {
      saved = localStorage.getItem(SKIN_KEY) || "";
    } catch (error) {
      /* أول زيارة */
    }
    state.skin = saved;
    if (saved) document.documentElement.setAttribute("data-skin", saved);

    document.querySelectorAll(".skins button").forEach((button) => {
      button.classList.toggle("on", button.dataset.skin === saved);
    });
  }

  function build() {
    buildSkins();

    const holder = document.getElementById("themeBar");
    if (!holder) return;

    holder.innerHTML = Object.entries(THEMES)
      .map(
        ([key, theme]) =>
          `<button class="theme__dot" type="button" data-theme="${key}"
                   style="--dot:${theme.swatch}" title="${theme.name}"
                   aria-label="${theme.name} theme"></button>`
      )
      .join("");

    holder.addEventListener("click", (event) => {
      const dot = event.target.closest("[data-theme]");
      if (dot) apply(dot.dataset.theme);
    });

    let saved = "gold";
    try {
      saved = localStorage.getItem(STORAGE_KEY) || "gold";
    } catch (error) {
      /* مفيش تخزين — بنبدأ بالافتراضي */
    }
    apply(saved);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", build);
  } else {
    build();
  }
})();
