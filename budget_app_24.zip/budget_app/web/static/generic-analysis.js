/* =========================================================
   generic-analysis.js — الـ 12 مرحلة على أي داتاست

   المحرك الأصلي (offline-analysis.js) متخصص في بيانات المصاريف:
   بيتوقع أعمدة اسمها date و category و amount. الملف ده بيعمّم الفكرة:
   بياخد أي ملف CSV، بيكتشف الأعمدة الرقمية والفئوية لوحده، وبيشغّل
   نفس الـ 12 مرحلة عليها.

   الرياضيات مش متكررة — بتتاخد من OfflineAnalysis.math (نسخة
   app/inference.py). الجديد هنا هو **اكتشاف الأعمدة** وتطويع كل
   مرحلة على عمود رقمي + عمود تجميع + عمود مقارنة.
   ========================================================= */

window.GenericAnalysis = (function () {
  "use strict";

  const M = window.OfflineAnalysis.math;
  const { sum, mean, round, fmt, signed, showP, quantile, sampleStd,
          moments, shapeLabel, confidenceInterval, tCritical, tTwoTailedP,
          fPValue, linearRegression, quadraticFit, toNumber } = M;

  /* وصف شكل التوزيع بالإنجليزي — النسخة العربية موجودة في المحرك التاني */
  function shapeText(skew) {
    if (skew > 1) return "strongly right-skewed";
    if (skew > 0.5) return "right-skewed";
    if (skew < -1) return "strongly left-skewed";
    if (skew < -0.5) return "left-skewed";
    return "roughly symmetric";
  }

  const ALPHA = 0.05;
  const MIN_ROWS = 12;

  /* القيم دي معناها «فاضي» فعلاً.
     ملحوظة مهمة: "Unknown" **مش** في القايمة دي عن قصد — في داتاستات كتير
     دي فئة حقيقية (زي حالة تدخين غير معروفة)، ولو اعتبرناها ناقصة هنرمي
     ربع البيانات من غير سبب. */
  const MISSING = new Set(["", "n/a", "na", "null", "nan", "?", "--"]);

  const isMissing = (value) =>
    value === null || value === undefined || MISSING.has(String(value).trim().toLowerCase());

  /* =======================================================
     1) اكتشاف نوع كل عمود
     ======================================================= */
  function profileColumns(rows) {
    const headers = Object.keys(rows[0] || {});
    const total = rows.length;

    return headers.map((name) => {
      const values = rows.map((row) => row[name]);
      const present = values.filter((value) => !isMissing(value));
      const numbers = present.filter((value) => Number.isFinite(toNumber(value)));
      const distinct = new Set(present.map((value) => String(value).trim()));

      const numericRatio = present.length ? numbers.length / present.length : 0;
      const isNumeric = numericRatio >= 0.8 && present.length > 0;

      /* عمود المعرّف: رقمي وكل قيمه مختلفة تقريباً — مالوش معنى إحصائي */
      const looksLikeId =
        isNumeric &&
        distinct.size > total * 0.9 &&
        /(^id$|_id$|^index$|^no$|^رقم)/i.test(name);

      return {
        name,
        numeric: isNumeric,
        /* الأعمدة الرقمية اللي قيمها قليلة (زي 0/1) بتنفع تجميع كمان */
        categorical: !isNumeric || distinct.size <= 10,
        distinct: distinct.size,
        missing: total - present.length,
        missingPercent: round((1 - present.length / total) * 100, 1),
        id: looksLikeId,
        levels: distinct.size <= 20 ? [...distinct].sort() : [],
        sample: present.length ? String(present[0]).slice(0, 20) : "—",
      };
    });
  }

  /* اقتراح أفضل أعمدة للتحليل من غير ما المستخدم يفكر */
  function suggestColumns(profile) {
    const numeric = profile.filter((column) => column.numeric && !column.id);

    /* العمود الرقمي الأساسي: أكتر واحد قيمه متنوعة (يعني فيه معلومة فعلاً) */
    const value = [...numeric].sort((a, b) => b.distinct - a.distinct)[0];

    /* عمود المقارنة: تاني أكتر تنوعاً، غير العمود الأساسي */
    const compare = [...numeric].filter((c) => c.name !== (value && value.name))
                                .sort((a, b) => b.distinct - a.distinct)[0];

    /* عمود التجميع: فئوي بين مجموعتين و 8 — عشان ANOVA يبقى له معنى */
    const group = profile
      .filter((column) => column.categorical && column.distinct >= 2 && column.distinct <= 8)
      .sort((a, b) => {
        const score = (c) => (c.numeric ? 1 : 0) + Math.abs(c.distinct - 3) * 0.1;
        return score(a) - score(b);
      })[0];

    return {
      value: value ? value.name : null,
      compare: compare ? compare.name : null,
      group: group ? group.name : null,
    };
  }

  /* =======================================================
     المرحلة 1 — التنظيف
     ======================================================= */
  function phase1(rows, options, profile) {
    const { value, group } = options;
    const dropped = { missing: 0, invalid_amount: 0, unknown_category: 0, duplicate: 0 };
    const seen = new Set();
    const clean = [];

    rows.forEach((row, index) => {
      const raw = row[value];

      if (isMissing(raw)) {
        dropped.missing += 1;
        return;
      }

      const number = toNumber(raw);
      if (!Number.isFinite(number)) {
        dropped.invalid_amount += 1;
        return;
      }

      const level = group ? String(row[group] ?? "").trim() : "All";
      if (group && isMissing(level)) {
        dropped.unknown_category += 1;
        return;
      }

      /* التكرار: الصف كله بنفس القيم */
      const signature = JSON.stringify(row);
      if (seen.has(signature)) {
        dropped.duplicate += 1;
        return;
      }
      seen.add(signature);

      clean.push({ index: index + 1, row, value: number, group: level || "All" });
    });

    if (clean.length < MIN_ROWS) {
      throw new Error(
        `Only ${clean.length} valid rows remain; the analysis needs at least ${MIN_ROWS}.`
      );
    }

    const droppedTotal = Object.values(dropped).reduce((a, b) => a + b, 0);
    const numericColumns = profile.filter((c) => c.numeric && !c.id);
    const categoricalColumns = profile.filter((c) => c.categorical && !c.numeric);

    return {
      records: clean,
      summary: {
        raw_rows: rows.length,
        clean_rows: clean.length,
        dropped_total: droppedTotal,
        dropped_detail: dropped,
        variables: {
          numerical: numericColumns.map((c) => ({
            label: c.name,
            type: c.distinct > 20 ? "continuous" : "discrete",
          })),
          categorical: categoricalColumns.map((c) => ({
            label: c.name,
            levels: c.levels.length ? c.levels : [`${c.distinct} levels`],
          })),
        },
        interpretation:
          `Loaded ${rows.length} rows. Analysed column: "${value}"` +
          (group ? `, grouped by "${group}"` : "") + ". " +
          `Removed ${droppedTotal} rows (${dropped.missing} missing values, ` +
          `${dropped.invalid_amount} non-numeric, ${dropped.duplicate} duplicates` +
          (dropped.unknown_category ? `, ${dropped.unknown_category} missing group` : "") +
          `), leaving ${clean.length} rows for analysis.`,
      },
    };
  }

  const valuesOf = (records, level) =>
    records.filter((r) => !level || r.group === level).map((r) => r.value);

  const levelsOf = (records) => [...new Set(records.map((r) => r.group))].sort();

  /* =======================================================
     المرحلة 2 — الإحصاء الوصفي
     ======================================================= */
  function phase2(records, options) {
    const values = valuesOf(records).sort((a, b) => a - b);
    const count = values.length;
    const average = mean(values);
    const median = quantile(values, 50);

    /* المنوال: بنجمّع في 20 فئة ونشوف أكترهم تكراراً */
    const low = values[0];
    const high = values[count - 1];
    const width = (high - low) / 20 || 1;
    const buckets = {};
    values.forEach((v) => {
      const key = Math.floor((v - low) / width);
      buckets[key] = (buckets[key] || 0) + 1;
    });
    const top = Object.entries(buckets).sort((a, b) => b[1] - a[1])[0];
    const bucketStart = low + Number(top[0]) * width;

    const variance = sum(values.map((v) => Math.pow(v - average, 2))) / (count - 1);
    const std = Math.sqrt(variance);
    const q1 = quantile(values, 25);
    const q3 = quantile(values, 75);

    const perGroup = levelsOf(records).map((level) => {
      const group = valuesOf(records, level).sort((a, b) => a - b);
      return {
        label: level,
        n: group.length,
        mean: round(mean(group)),
        median: round(quantile(group, 50)),
        std: round(sampleStd(group)),
        total: round(sum(group)),
      };
    });

    const gap = average - median;

    return {
      n: count,
      mean: round(average),
      median: round(median),
      mode: {
        value: round(bucketStart + width / 2),
        count: top[1],
        range: `${fmt(bucketStart, 1)} — ${fmt(bucketStart + width, 1)}`,
      },
      min: round(low),
      max: round(high),
      range: round(high - low),
      variance: round(variance),
      std: round(std),
      cv: average ? round((std / Math.abs(average)) * 100, 1) : 0,
      q1: round(q1),
      q2: round(median),
      q3: round(q3),
      iqr: round(q3 - q1),
      per_category: perGroup,
      interpretation:
        `Mean of "${options.value}" = ${fmt(average, 2)}, median = ${fmt(median, 2)}. ` +
        (Math.abs(gap) > std * 0.15
          ? `The mean sits ${fmt(Math.abs(gap), 2)} away from the median, so the distribution ` +
            "is not symmetric — extreme values are pulling the mean in one direction."
          : "Mean and median are close, so the distribution is balanced with no distorting outliers.") +
        ` Half the data falls between ${fmt(q1, 2)} and ${fmt(q3, 2)} ` +
        `(IQR = ${fmt(q3 - q1, 2)}), and the coefficient of variation is ` +
        `${average ? ((std / Math.abs(average)) * 100).toFixed(1) : 0}%.`,
    };
  }

  /* =======================================================
     المرحلة 3 — التوزيع
     ======================================================= */
  function phase3(records, options, bins = 12) {
    const values = valuesOf(records).sort((a, b) => a - b);
    const count = values.length;
    const low = values[0];
    const high = values[count - 1];
    const width = high > low ? (high - low) / bins : 1;

    const frequency = [];
    let cumulative = 0;
    for (let i = 0; i < bins; i += 1) {
      const start = low + i * width;
      const end = start + width;
      const inside = values.filter(
        (v) => (v >= start && v < end) || (i === bins - 1 && v === high)
      );
      cumulative += inside.length;
      frequency.push({
        start: round(start, 2),
        end: round(end, 2),
        label: `${fmt(start, 1)}—${fmt(end, 1)}`,
        count: inside.length,
        percent: round((inside.length / count) * 100, 1),
        cumulative_percent: round((cumulative / count) * 100, 1),
      });
    }

    const q1 = quantile(values, 25);
    const q3 = quantile(values, 75);
    const iqr = q3 - q1;
    const lowerFence = q1 - 1.5 * iqr;
    const upperFence = q3 + 1.5 * iqr;
    const inliers = values.filter((v) => v >= lowerFence && v <= upperFence);

    const outliers = records
      .filter((r) => r.value > upperFence || r.value < lowerFence)
      .sort((a, b) => Math.abs(b.value - mean(values)) - Math.abs(a.value - mean(values)))
      .map((r) => ({
        amount: round(r.value, 2),
        day: `#${r.index}`,
        label: r.group,
        description: options.compare ? `${options.compare} = ${r.row[options.compare]}` : "—",
      }));

    const { skew, kurt } = moments(values);

    return {
      frequency,
      box_plot: {
        min: round(inliers.length ? Math.min(...inliers) : low, 2),
        q1: round(q1, 2),
        median: round(quantile(values, 50), 2),
        q3: round(q3, 2),
        max: round(inliers.length ? Math.max(...inliers) : high, 2),
        iqr: round(iqr, 2),
        lower_fence: round(lowerFence, 2),
        upper_fence: round(upperFence, 2),
      },
      outliers: outliers.slice(0, 8),
      outliers_count: outliers.length,
      labels: { outlierHeaders: ["Value", "Row", "Group", "Comparison column"] },
      shape: {
        skewness: round(skew, 3),
        kurtosis: round(kurt, 3),
        label: shapeText(skew),
        tails: kurt > 0.5 ? "Heavy tails (more extremes than a normal curve)" : "Normal tails",
      },
      mean: round(mean(values), 2),
      std: round(sampleStd(values), 2),
      interpretation:
        `"${options.value}" is ${shapeText(skew)} (skewness ${skew.toFixed(2)}, ` +
        `kurtosis ${kurt.toFixed(2)}). By Tukey's rule, any value above ${fmt(upperFence, 2)} ` +
        `or below ${fmt(lowerFence, 2)} counts as an outlier — ` +
        (outliers.length
          ? `and ${outliers.length} values qualify (${((outliers.length / count) * 100).toFixed(1)}% of the data).`
          : "and none of the values qualify."),
    };
  }

  /* =======================================================
     المرحلة 4 — الجبر الخطي
     ======================================================= */
  function phase4(records, options, profile) {
    const levels = levelsOf(records);

    /* متجه المتوسطات: كل مجموعة بمتوسطها */
    const meanVector = levels.map((level) => round(mean(valuesOf(records, level)), 2));
    const countVector = levels.map((level) => valuesOf(records, level).length);

    /* متجه الأوزان: حجم كل مجموعة كنسبة — يعني وزنها في المجتمع */
    const totalCount = sum(countVector);
    const weightVector = countVector.map((c) => round(c / totalCount, 3));

    /* الضرب النقطي = المتوسط العام الموزون */
    const dot = sum(meanVector.map((m, i) => m * weightVector[i]));
    const magnitude = Math.sqrt(sum(meanVector.map((v) => v * v)));

    const scalar = 1.1;
    const scaledVector = meanVector.map((v) => round(v * scalar, 2));

    /* المصفوفة: صف لكل مجموعة، وعمود لكل متغيّر رقمي */
    const numericColumns = profile
      .filter((c) => c.numeric && !c.id)
      .slice(0, 4)
      .map((c) => c.name);

    const matrix = levels.map((level) =>
      numericColumns.map((column) => {
        const nums = records
          .filter((r) => r.group === level)
          .map((r) => toNumber(r.row[column]))
          .filter(Number.isFinite);
        return round(mean(nums), 2);
      })
    );

    /* الزاوية بين متجه متوسطاتك ومتجه «كل المجموعات متساوية» */
    const flat = levels.map(() => mean(valuesOf(records)));
    const flatMagnitude = Math.sqrt(sum(flat.map((v) => v * v)));
    const flatDot = sum(meanVector.map((v, i) => v * flat[i]));
    const cosine = magnitude && flatMagnitude ? flatDot / (magnitude * flatMagnitude) : 0;
    const angle = (Math.acos(Math.max(Math.min(cosine, 1), -1)) * 180) / Math.PI;

    return {
      labels: levels,
      spend_vector: meanVector,
      weight_vector: weightVector,
      dot_product: round(dot, 2),
      magnitude: round(magnitude, 2),
      scalar,
      scaled_vector: scaledVector,
      scaled_total: round(sum(scaledVector), 2),
      extra_cost: round(sum(scaledVector) - sum(meanVector), 2),
      matrix: {
        rows: levels,
        columns: numericColumns,
        values: matrix,
        row_totals: matrix.map((row) => round(sum(row), 2)),
        column_totals: numericColumns.map((_, i) =>
          round(sum(matrix.map((row) => row[i])), 2)
        ),
        shape: `${matrix.length}×${numericColumns.length}`,
      },
      alignment: {
        ideal_vector: flat.map((v) => round(v, 2)),
        cosine: round(cosine, 4),
        angle_degrees: round(angle, 2),
      },
      interpretation:
        `The mean vector of "${options.value}" by "${options.group}" is ` +
        `[${meanVector.map((v) => fmt(v, 1)).join(", ")}] with magnitude ${fmt(magnitude, 2)}. ` +
        `Its dot product with the weight vector (group sizes) = ${fmt(dot, 2)}, ` +
        "which is exactly the weighted overall mean. The angle between the mean vector and " +
        `a "all groups equal" vector is ${angle.toFixed(2)}° ` +
        (angle < 2
          ? "(near zero means the group means are very close to each other)."
          : "(the wider the angle, the more the groups differ).") +
        ` The ${matrix.length}×${numericColumns.length} matrix summarises every numeric variable per group.`,
    };
  }

  /* =======================================================
     المرحلة 5 — الاحتمالات
     ======================================================= */
  function phase5(records, options) {
    const total = records.length;
    const values = valuesOf(records);
    /* العتبة = المتوسط + انحراف واحد.
       (الربيع الأعلى كان بيخلي P(A) = 25٪ دايماً — تحصيل حاصل مالوش معنى) */
    const limit = round(mean(values) + sampleStd(values), 2);

    const levels = levelsOf(records);
    const mainLevel = levels
      .map((level) => ({ level, n: valuesOf(records, level).length }))
      .sort((a, b) => b.n - a.n)[0].level;

    const high = records.filter((r) => r.value >= limit);
    const inGroup = records.filter((r) => r.group === mainLevel);
    const highInGroup = inGroup.filter((r) => r.value >= limit);

    const pHigh = high.length / total;
    const pGroup = inGroup.length / total;
    const pHighGivenGroup = inGroup.length ? highInGroup.length / inGroup.length : 0;
    const pGroupGivenHigh = high.length ? highInGroup.length / high.length : 0;
    const gap = Math.abs(pHighGivenGroup - pHigh);

    let expected = 0;
    const table = levels.map((level) => {
      const group = valuesOf(records, level);
      const probability = group.length / total;
      const groupMean = mean(group);
      const contribution = probability * groupMean;
      expected += contribution;
      return {
        label: level,
        probability: round(probability, 4),
        mean: round(groupMean, 2),
        contribution: round(contribution, 2),
      };
    });

    return {
      threshold: limit,
      simple: [
        {
          event: `${options.value} ≥ ${fmt(limit, 2)}  (μ + σ)`,
          notation: "P(A)",
          count: high.length,
          of: total,
          probability: round(pHigh, 4),
          percent: round(pHigh * 100, 1),
        },
        {
          event: `${options.group} = ${mainLevel}`,
          notation: "P(B)",
          count: inGroup.length,
          of: total,
          probability: round(pGroup, 4),
          percent: round(pGroup * 100, 1),
        },
      ],
      conditional: [
        {
          event: `High value given ${mainLevel}`,
          notation: "P(A|B)",
          count: highInGroup.length,
          of: inGroup.length,
          probability: round(pHighGivenGroup, 4),
          percent: round(pHighGivenGroup * 100, 1),
        },
        {
          event: `${mainLevel} given a high value`,
          notation: "P(B|A)",
          count: highInGroup.length,
          of: high.length,
          probability: round(pGroupGivenHigh, 4),
          percent: round(pGroupGivenHigh * 100, 1),
        },
      ],
      independence: {
        p_a: round(pHigh, 4),
        p_a_given_b: round(pHighGivenGroup, 4),
        gap: round(gap, 4),
        independent: gap < 0.05,
      },
      expected_value: {
        per_expense: round(expected, 2),
        per_day: round(mean(values), 2),
        expenses_per_day: total,
        table,
      },
      labels: {
        expected_one: `Weighted E(X) of ${options.value}`,
        expected_day: "Plain arithmetic mean",
      },
      interpretation:
        `The probability that a row has a high "${options.value}" (≥ ${fmt(limit, 2)}) is ` +
        `${(pHigh * 100).toFixed(1)}%. Given "${options.group}" = ${mainLevel}, ` +
        `that probability becomes ${(pHighGivenGroup * 100).toFixed(1)}% — ` +
        (gap >= 0.05
          ? "so the group does change the odds, and the two events are not independent."
          : "a small difference, so the two events are close to independent.") +
        ` The weighted expected value E(X) = ${fmt(expected, 2)}.`,
    };
  }

  /* =======================================================
     المرحلة 6 — المعاينة
     ======================================================= */
  function phase6(records) {
    const population = valuesOf(records);
    const size = population.length;
    const sampleSize = Math.min(Math.max(10, Math.floor(size / 4)), 60, size);

    const pick = (source, howMany) => {
      const pool = [...source];
      const chosen = [];
      for (let i = 0; i < howMany; i += 1) {
        chosen.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
      }
      return chosen;
    };

    const sample = pick(population, sampleSize);
    const populationMean = mean(population);
    const populationStd = Math.sqrt(
      sum(population.map((v) => Math.pow(v - populationMean, 2))) / size
    );

    const sampleMean = mean(sample);
    const sampleDeviation = sampleStd(sample);
    const standardError = sampleDeviation / Math.sqrt(sampleSize);
    const error = sampleMean - populationMean;
    const errorPercent = populationMean ? (Math.abs(error) / Math.abs(populationMean)) * 100 : 0;

    const repeated = [];
    for (let run = 0; run < 400; run += 1) repeated.push(mean(pick(population, sampleSize)));
    const meansStd = sampleStd(repeated);
    const theoretical = populationStd / Math.sqrt(sampleSize);

    return {
      population: {
        definition: "All valid rows after cleaning",
        n: size,
        mean: round(populationMean, 2),
        std: round(populationStd, 2),
      },
      sample: {
        definition: `Simple random sample of ${sampleSize} rows (every row equally likely)`,
        n: sampleSize,
        mean: round(sampleMean, 2),
        std: round(sampleDeviation, 2),
        standard_error: round(standardError, 2),
        fraction: round((sampleSize / size) * 100, 1),
      },
      comparison: {
        error: round(error, 2),
        error_percent: round(errorPercent, 2),
        within_2se: Math.abs(error) <= 2 * standardError,
      },
      sampling_distribution: {
        repeats: 400,
        mean_of_means: round(mean(repeated), 2),
        observed_se: round(meansStd, 3),
        theoretical_se: round(theoretical, 3),
      },
      interpretation:
        `The sample (${sampleSize} rows = ${((sampleSize / size) * 100).toFixed(0)}% of the data) ` +
        `gave a mean of ${fmt(sampleMean, 2)} against ${fmt(populationMean, 2)} for the whole ` +
        `population — a gap of ${fmt(Math.abs(error), 2)} (${errorPercent.toFixed(1)}%). ` +
        (Math.abs(error) <= 2 * standardError
          ? "That gap sits inside the standard error, so the sample represents the population well."
          : "That gap is wider than expected — this particular sample landed in the tail.") +
        ` Repeating the draw 400 times gave an observed spread of ${meansStd.toFixed(2)} ` +
        `against the theoretical σ/√n = ${theoretical.toFixed(2)} — their agreement is the Central Limit Theorem at work.`,
    };
  }

  /* =======================================================
     المرحلة 7 — فترات الثقة
     ======================================================= */
  function phase7(records, options) {
    const values = valuesOf(records);
    const main = confidenceInterval(values);

    const compareValues = options.compare
      ? records.map((r) => toNumber(r.row[options.compare])).filter(Number.isFinite)
      : [];
    const second = compareValues.length > 1 ? confidenceInterval(compareValues) : main;

    const perGroup = levelsOf(records)
      .map((level) => {
        const group = valuesOf(records, level);
        if (group.length < 2) return null;
        const interval = confidenceInterval(group);
        return {
          label: level,
          n: interval.n,
          mean: round(interval.mean, 2),
          low: round(interval.low, 2),
          high: round(interval.high, 2),
          margin: round(interval.margin, 2),
        };
      })
      .filter(Boolean);

    return {
      expense_mean: {
        confidence: 95,
        n: main.n,
        mean: round(main.mean, 2),
        std: round(main.std, 2),
        standard_error: round(main.standard_error, 3),
        t_critical: round(main.t_critical, 3),
        margin: round(main.margin, 3),
        low: round(main.low, 2),
        high: round(main.high, 2),
      },
      daily_mean: {
        n: second.n,
        mean: round(second.mean, 2),
        low: round(second.low, 2),
        high: round(second.high, 2),
        margin: round(second.margin, 3),
      },
      per_category: perGroup,
      labels: {
        second: options.compare ? `CI for "${options.compare}"` : "Secondary interval",
      },
      interpretation:
        `The 95% confidence interval for the mean of "${options.value}" is ` +
        `[${fmt(main.low, 2)} — ${fmt(main.high, 2)}], with a margin of error of ±${fmt(main.margin, 2)}. ` +
        "It means: if we repeated this study 100 times the same way, about 95 of the resulting " +
        "intervals would contain the true population mean. " +
        "The margin narrows as the sample grows, because it is divided by √n.",
    };
  }

  /* =======================================================
     المرحلة 8 — اختبار الفروض
     ======================================================= */
  function phase8(records, options) {
    const values = valuesOf(records);
    const reference =
      options.reference !== undefined && options.reference !== null && options.reference !== ""
        ? Number(options.reference)
        : round(quantile([...values].sort((a, b) => a - b), 50), 1);

    const count = values.length;
    const average = mean(values);
    const std = sampleStd(values);
    const standardError = std / Math.sqrt(count);
    const t = standardError ? (average - reference) / standardError : 0;
    const df = count - 1;
    const pValue = tTwoTailedP(t, df);
    const reject = pValue < ALPHA;
    const decision = reject ? "Reject H₀" : "Fail to reject H₀";

    return {
      subject: `mean of ${options.value}`,
      h0: `H₀: mean of "${options.value}" = ${fmt(reference, 2)}  (μ = μ₀)`,
      h1: `H₁: mean of "${options.value}" ≠ ${fmt(reference, 2)}  (μ ≠ μ₀)`,
      test: "One-sample t-test, two-tailed",
      alpha: ALPHA,
      n: count,
      sample_mean: round(average, 2),
      reference: round(reference, 2),
      std: round(std, 2),
      standard_error: round(standardError, 3),
      t_statistic: round(t, 4),
      df,
      t_critical: round(tCritical(df, 1 - ALPHA), 3),
      p_value: round(pValue, 6),
      reject_null: reject,
      decision,
      conclusion:
        `p-value ${showP(pValue)} ` +
        (reject
          ? `< α = ${ALPHA} → ${decision}. The gap between the observed mean (${fmt(average, 2)}) ` +
            `and the reference value (${fmt(reference, 2)}) is statistically real; chance is an unlikely explanation.`
          : `> α = ${ALPHA} → ${decision}. The data gives no sufficient evidence that the true mean ` +
            `differs from ${fmt(reference, 2)} — the observed gap could be chance.`),
    };
  }

  /* =======================================================
     المرحلة 9 — ANOVA
     ======================================================= */
  function phase9(records, options) {
    const levels = levelsOf(records);
    const usable = levels
      .map((level) => ({ name: level, values: valuesOf(records, level) }))
      .filter((g) => g.values.length >= 2);

    if (usable.length < 2) {
      return { unavailable: "Needs at least two groups with two values each — pick a different grouping column." };
    }

    const all = usable.flatMap((g) => g.values);
    const grandMean = mean(all);

    let ssBetween = 0;
    let ssWithin = 0;
    const groups = usable.map((g) => {
      const groupMean = mean(g.values);
      ssBetween += g.values.length * Math.pow(groupMean - grandMean, 2);
      ssWithin += sum(g.values.map((v) => Math.pow(v - groupMean, 2)));
      return { name: g.name, n: g.values.length, mean: round(groupMean, 2), std: round(sampleStd(g.values), 2) };
    });

    const dfBetween = usable.length - 1;
    const dfWithin = all.length - usable.length;
    const msBetween = dfBetween ? ssBetween / dfBetween : 0;
    const msWithin = dfWithin ? ssWithin / dfWithin : 0;
    const f = msWithin ? msBetween / msWithin : 0;
    const pValue = fPValue(f, dfBetween, dfWithin);
    const reject = pValue < ALPHA;
    const decision = reject ? "Reject H₀" : "Fail to reject H₀";
    const ordered = [...groups].sort((a, b) => b.mean - a.mean);

    return {
      h0: `H₀: the mean of "${options.value}" is equal across all "${options.group}" groups`,
      h1: "H₁: at least one group mean differs",
      alpha: ALPHA,
      groups,
      grand_mean: round(grandMean, 2),
      table: {
        between: { ss: round(ssBetween, 2), df: dfBetween, ms: round(msBetween, 2) },
        within: { ss: round(ssWithin, 2), df: dfWithin, ms: round(msWithin, 2) },
      },
      f_statistic: round(f, 4),
      p_value: round(pValue, 8),
      reject_null: reject,
      decision,
      conclusion:
        `F = ${f.toFixed(2)}, p-value ${showP(pValue)} ` +
        (reject
          ? `< α = ${ALPHA} → ${decision}. "${options.group}" really does make a difference in ` +
            `"${options.value}": the highest mean is ${ordered[0].name} (${fmt(ordered[0].mean, 2)}) ` +
            `and the lowest is ${ordered[ordered.length - 1].name} ` +
            `(${fmt(ordered[ordered.length - 1].mean, 2)}).`
          : `> α = ${ALPHA} → ${decision}. No sufficient evidence that the group means differ — ` +
            "the spread inside each group is larger than the gap between them."),
    };
  }

  /* =======================================================
     المرحلة 10 — التفاضل
     ======================================================= */
  function phase10(records, options) {
    if (!options.compare) {
      return { unavailable: "Pick a numeric comparison column to study the rate of change against it." };
    }

    /* بنرتب حسب عمود المقارنة (x) وناخد متوسط y لكل قيمة x */
    const pairs = records
      .map((r) => ({ x: toNumber(r.row[options.compare]), y: r.value }))
      .filter((p) => Number.isFinite(p.x) && Number.isFinite(p.y))
      .sort((a, b) => a.x - b.x);

    if (pairs.length < 5) {
      return { unavailable: "Not enough paired values between the two columns." };
    }

    /* بنجمّع القيم المتكررة عشان المنحنى يبقى مقروء */
    const grouped = new Map();
    pairs.forEach((p) => {
      if (!grouped.has(p.x)) grouped.set(p.x, []);
      grouped.get(p.x).push(p.y);
    });

    const xs = [...grouped.keys()].sort((a, b) => a - b);
    const ys = xs.map((x) => round(mean(grouped.get(x)), 2));

    const line = linearRegression(xs, ys);
    const curve = quadraticFit(xs, ys);

    const firstX = xs[0];
    const lastX = xs[xs.length - 1];
    const derivativeStart = 2 * curve.a * firstX + curve.b;
    const derivativeEnd = 2 * curve.a * lastX + curve.b;
    const secondDerivative = 2 * curve.a;

    /* المقارنة لازم تكون نسبية: انحناء 0.001 مالوش معنى لو الميل 1.6،
       فبنقيسه بالنسبة للمدى الكامل للمتغيّر. */
    const span = lastX - firstX || 1;
    const curvatureEffect = Math.abs(secondDerivative * span);
    const slopeScale = Math.abs(line.slope) || 1;

    const trend =
      curvatureEffect < slopeScale * 0.1
        ? "Near-linear — the rate of change stays constant"
        : secondDerivative > 0
        ? "Accelerating — the rate of change grows as x increases"
        : "Decelerating — the rate of change shrinks as x increases";

    const direction =
      line.slope > 0 ? "positive (both rise together)" : line.slope < 0 ? "negative (one rises as the other falls)" : "flat";

    return {
      function: `y = ${options.value} as a function of x = ${options.compare}`,
      month: `${options.compare} from ${fmt(firstX, 1)} to ${fmt(lastX, 1)}`,
      days: xs.length,
      points: xs.map((x, i) => ({ t: x, s: ys[i] })),
      linear: {
        equation: `y = ${fmt(line.slope, 3)}·x ${signed(line.intercept, 2)}`,
        slope: round(line.slope, 4),
        intercept: round(line.intercept, 2),
        r_squared: round(line.r_squared, 4),
        derivative: `dy/dx = ${fmt(line.slope, 3)} (constant)`,
      },
      quadratic: {
        equation: `y = ${curve.a.toFixed(4)}·x² ${signed(curve.b, 3)}·x ${signed(curve.c, 2)}`,
        a: round(curve.a, 5),
        b: round(curve.b, 4),
        c: round(curve.c, 2),
        derivative: `dy/dx = ${(2 * curve.a).toFixed(4)}·x ${signed(curve.b, 3)}`,
        second_derivative: round(secondDerivative, 5),
      },
      rates: {
        average: round((ys[ys.length - 1] - ys[0]) / (lastX - firstX || 1), 4),
        at_start: round(derivativeStart, 4),
        at_end: round(derivativeEnd, 4),
        change: round(derivativeEnd - derivativeStart, 4),
      },
      reach_income_day: null,
      trend,
      labels: {
        period: `Range of ${options.compare}`,
        count: "Data points",
        rateStart: "Rate of change at start",
        rateEnd: "Rate of change at end",
      },
      interpretation:
        `The relationship between "${options.compare}" and "${options.value}" is ${direction}. ` +
        `The slope is ${fmt(line.slope, 3)}: every 1-unit rise in "${options.compare}" changes ` +
        `"${options.value}" by ${fmt(line.slope, 3)} on average — that is the first derivative. ` +
        `R2 = ${line.r_squared.toFixed(3)}, ` +
        (line.r_squared > 0.5
          ? "so the line explains a large share of the variation."
          : "so the line explains only a small share — the relationship is weak or non-linear.") +
        ` The second derivative is ${secondDerivative.toFixed(4)}: ${trend.toLowerCase()}.`,
    };
  }

  /* =======================================================
     المرحلة 11 و 12
     ======================================================= */
  function phase11(records, options, phases) {
    const levels = levelsOf(records);

    const scatter = records
      .map((r) => ({
        x: options.compare ? toNumber(r.row[options.compare]) : r.index,
        y: r.value,
      }))
      .filter((p) => Number.isFinite(p.x) && Number.isFinite(p.y))
      .slice(0, 600);

    return {
      bar: {
        title: `Mean ${options.value} by ${options.group}`,
        why: "Comparing categories — a bar chart is the clearest comparison",
        labels: levels,
        values: levels.map((level) => round(mean(valuesOf(records, level)), 2)),
      },
      histogram: {
        title: `Distribution of ${options.value}`,
        why: "Shows the shape: where values pile up and where the tail runs",
        bins: phases.phase3.frequency,
      },
      box: {
        title: "Box plot — quartiles and outliers",
        why: "Five-number summary plus outliers in one picture",
        data: phases.phase3.box_plot,
        outliers: phases.phase3.outliers.map((o) => o.amount),
      },
      scatter: {
        title: options.compare ? `${options.compare} vs ${options.value}` : "Row index vs value",
        why: "Reveals whether the two variables are related, and whether it is linear",
        points: scatter,
      },
      line: {
        title: `${options.value} as a function of ${options.compare || "row index"}`,
        why: "Shows the trend — the slope of this line is the derivative",
        points: phases.phase10.points || [],
      },
      interpretation:
        "Each chart answers a different question: the bar chart compares groups, the histogram " +
        "shows shape, the box plot exposes outliers, the scatter reveals relationships, the line shows trend.",
    };
  }

  function phase12(phases, options) {
    const d = phases.phase2;
    const dist = phases.phase3;
    const prob = phases.phase5;
    const samp = phases.phase6;
    const ci = phases.phase7.expense_mean;
    const test = phases.phase8;
    const anova = phases.phase9 || {};
    const calc = phases.phase10 || {};

    const statistical = [
      { name: "t-test", result: `t = ${test.t_statistic}, p ${showP(test.p_value)}`, decision: test.decision },
    ];
    if (anova.f_statistic !== undefined) {
      statistical.push({
        name: "ANOVA",
        result: `F = ${anova.f_statistic}, p ${showP(anova.p_value)}`,
        decision: anova.decision,
      });
    }

    const relationships = [];
    if (calc.linear) {
      relationships.push(
        `"${options.compare}" vs "${options.value}": slope ${calc.linear.slope}, ` +
          `R2 = ${calc.linear.r_squared} — ${calc.trend.toLowerCase()}.`
      );
    }
    if (!prob.independence.independent) {
      relationships.push(
        `"${options.group}" and "${options.value}" are not independent — the group shifts the odds of high values.`
      );
    }
    if (anova.reject_null) {
      relationships.push(`Differences in mean "${options.value}" across "${options.group}" groups are statistically real.`);
    }

    return {
      findings: [
        `Column "${options.value}": mean ${d.mean}, median ${d.median}, SD ${d.std} (CV ${d.cv}%).`,
        `The distribution is ${dist.shape.label} with ${dist.outliers_count} outliers by the IQR rule.`,
        `Probability of a high value is ${prob.simple[0].percent}%, weighted E(X) = ${prob.expected_value.per_expense}.`,
        `A sample of ${samp.sample.n} rows estimated the mean within ${samp.comparison.error_percent}% of the population.`,
        `95% confidence interval for the mean: [${ci.low} — ${ci.high}].`,
      ],
      statistical_results: statistical,
      relationships: relationships.length ? relationships : ["No clearly significant relationships in this dataset."],
      calculus: calc.interpretation || "—",
      conclusion:
        `Analysed ${d.n} rows on "${options.value}". The distribution is ${dist.shape.label}` +
        (dist.outliers_count ? ` with ${dist.outliers_count} outliers` : "") + ". " +
        (anova.reject_null
          ? `"${options.group}" genuinely shifts the mean, `
          : `No confirmed difference between "${options.group}" groups, `) +
        (test.reject_null
          ? "and the overall mean differs statistically from the reference value."
          : "and the overall mean is not confirmed to differ from the reference value.") +
        " Recommendation: review the outliers before acting on the mean — they move it.",
      improvements: [
        "Collect more rows so the tests carry more statistical power",
        "Run a Tukey post-hoc test after ANOVA to pinpoint which pairs differ",
        "Try a log transform if the distribution is heavily skewed",
        "Build a multiple regression combining several predictors",
      ],
    };
  }

  const TITLES = {
    phase1: "1. Data Collection & Preparation",
    phase2: "2. Descriptive Statistics",
    phase3: "3. Distribution Analysis",
    phase4: "4. Linear Algebra",
    phase5: "5. Probability",
    phase6: "6. Sampling & Inference",
    phase7: "7. Confidence Intervals",
    phase8: "8. Hypothesis Testing",
    phase9: "9. One-Way ANOVA",
    phase10: "10. Calculus",
    phase11: "11. Visualization",
    phase12: "12. Findings & Conclusion",
  };

  /* =======================================================
     التشغيل
     ======================================================= */
  function run(rows, options) {
    if (!rows || !rows.length) throw new Error("No data.");
    if (!options.value) throw new Error("Pick the numeric column to analyse.");

    const profile = profileColumns(rows);
    const prepared = phase1(rows, options, profile);
    const records = prepared.records;
    const phases = { phase1: prepared.summary };

    const steps = [
      ["phase2", () => phase2(records, options)],
      ["phase3", () => phase3(records, options)],
      ["phase4", () => phase4(records, options, profile)],
      ["phase5", () => phase5(records, options)],
      ["phase6", () => phase6(records)],
      ["phase7", () => phase7(records, options)],
      ["phase8", () => phase8(records, options)],
      ["phase9", () => phase9(records, options)],
      ["phase10", () => phase10(records, options)],
    ];

    steps.forEach(([key, fn]) => {
      try {
        phases[key] = fn();
      } catch (error) {
        phases[key] = { error: `This phase failed: ${error.message}` };
      }
    });

    phases.phase11 = phase11(records, options, phases);
    phases.phase12 = phase12(phases, options);

    return {
      generated_at: new Date().toISOString().slice(0, 10),
      rows: records.length,
      currency: "",
      columns: options,
      titles: TITLES,
      ...phases,
    };
  }

  return { run, profileColumns, suggestColumns };
})();
