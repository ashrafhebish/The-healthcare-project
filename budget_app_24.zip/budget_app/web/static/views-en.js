/* =========================================================
   views-en.js — عرض إنجليزي للـ 12 مرحلة

   الملف ده بيستبدل دوال العرض اللي في app.js بنسخ إنجليزية.
   بيتحمّل في صفحة التحليل بس، فالصفحة العربية (index.html) مبتتأثرش.

   الحسابات مش بتتكرر هنا — بيتاخدوا زي ما هم من generic-analysis.js،
   والدوال المساعدة (statRow, table, drawCurve...) من app.js.
   ========================================================= */

(function () {
  "use strict";

  /* مسميات الرسومات كمان لازم تتترجم — دي مكتوبة جوه الـ SVG */
  CHART_TEXT.median = "median";
  CHART_TEXT.axisStart = "first";
  CHART_TEXT.axisEnd = (n) => `n = ${n}`;
  CHART_TEXT.rowsWord = "rows";

  /* شريط «بدون سيرفر» وختم النسخة */
  window.OFFLINE_BANNER_TEXT =
    "<b>Offline mode</b> — everything runs inside your browser and your data stays on this " +
    "device. Nothing is uploaded anywhere.";

  document.addEventListener("DOMContentLoaded", () => {
    const stamp = document.getElementById("buildStamp");
    if (stamp) stamp.textContent = stamp.textContent.replace("نسخة ملف واحد ·", "single-file build ·");
  });

  document.documentElement.lang = "en";
  document.documentElement.dir = "ltr";

  const money = (value) => fixed(value, 2);

  /* ---------- 1. Data preparation ---------- */
  PHASE_VIEWS.phase1 = (data) => {
    const dropped = data.dropped_detail;
    return (
      statRow("Raw rows", fixed(data.raw_rows)) +
      statRow("Clean rows", fixed(data.clean_rows)) +
      statRow("Removed", `${fixed(data.dropped_total)} rows`) +
      table(
        ["Reason for removal", "Count"],
        [
          ["Missing value", dropped.missing],
          ["Not a number", dropped.invalid_amount],
          ["Missing group", dropped.unknown_category],
          ["Duplicate row", dropped.duplicate],
        ]
      ) +
      `<h4 class="phead">Variables</h4>` +
      table(
        ["Variable", "Type"],
        [
          ...data.variables.numerical.map((item) => [item.label, `numeric — ${item.type}`]),
          ...data.variables.categorical.map((item) => [
            item.label,
            `categorical — ${item.levels.length} levels`,
          ]),
        ]
      ) +
      note(data.interpretation)
    );
  };

  /* ---------- 2. Descriptive statistics ---------- */
  PHASE_VIEWS.phase2 = (data) =>
    `<div class="pgrid">
      ${statRow("Mean", smart(data.mean))}
      ${statRow("Median", smart(data.median))}
      ${statRow("Mode", `${smart(data.mode.value)} (${data.mode.range})`)}
      ${statRow("Minimum", smart(data.min))}
      ${statRow("Maximum", smart(data.max))}
      ${statRow("Range", smart(data.range))}
      ${statRow("Variance", smart(data.variance))}
      ${statRow("Standard deviation", smart(data.std))}
      ${statRow("Q1", smart(data.q1))}
      ${statRow("Q3", smart(data.q3))}
      ${statRow("IQR", smart(data.iqr))}
      ${statRow("Coefficient of variation", `${data.cv}%`)}
    </div>` +
    `<h4 class="phead">By group</h4>` +
    table(
      ["Group", "n", "Mean", "Median", "SD", "Total"],
      data.per_category.map((row) => [
        row.label,
        row.n,
        smart(row.mean),
        smart(row.median),
        smart(row.std),
        smart(row.total),
      ])
    ) +
    note(data.interpretation);

  /* ---------- 3. Distribution ---------- */
  PHASE_VIEWS.phase3 = (data) =>
    `<h4 class="phead">Frequency distribution</h4>` +
    histogramChart(data.frequency) +
    table(
      ["Bin", "Frequency", "%", "Cumulative %"],
      data.frequency
        .filter((bin) => bin.count > 0)
        .map((bin) => [bin.label, bin.count, bin.percent, bin.cumulative_percent])
    ) +
    `<h4 class="phead">Box plot</h4>` +
    boxPlot(data.box_plot, data.outliers.map((item) => item.amount)) +
    `<div class="pgrid">
      ${statRow("Minimum (excl. outliers)", smart(data.box_plot.min))}
      ${statRow("Q1", smart(data.box_plot.q1))}
      ${statRow("Median", smart(data.box_plot.median))}
      ${statRow("Q3", smart(data.box_plot.q3))}
      ${statRow("Maximum (excl. outliers)", smart(data.box_plot.max))}
      ${statRow("Lower fence", smart(data.box_plot.lower_fence))}
      ${statRow("Upper fence", smart(data.box_plot.upper_fence))}
      ${statRow("Outliers", data.outliers_count)}
      ${statRow("Skewness", data.shape.skewness)}
      ${statRow("Kurtosis", data.shape.kurtosis)}
      ${statRow("Shape", data.shape.label)}
      ${statRow("Tails", data.shape.tails)}
    </div>` +
    (data.outliers.length
      ? table(
          ["Value", "Row", "Group", "Detail"],
          data.outliers.map((item) => [
            smart(item.amount),
            item.day,
            item.label,
            item.description || "—",
          ])
        )
      : "") +
    note(data.interpretation);

  /* ---------- 4. Linear algebra ---------- */
  PHASE_VIEWS.phase4 = (data) => {
    const matrix = data.matrix;
    return (
      `<h4 class="phead">Vectors and the dot product</h4>` +
      table(
        ["", ...data.labels],
        [
          ["Mean vector", ...data.spend_vector.map((value) => smart(value))],
          ["Weight vector (group share)", ...data.weight_vector],
          ["× 1.10 (scalar multiplication)", ...data.scaled_vector.map((value) => smart(value))],
        ]
      ) +
      `<div class="pgrid">
        ${statRow("Dot product", smart(data.dot_product))}
        ${statRow("Vector magnitude ‖v‖", smart(data.magnitude))}
        ${statRow("Change after ×1.10", smart(data.extra_cost))}
        ${statRow("Cosine of angle", data.alignment.cosine)}
        ${statRow("Angle vs equal-groups vector", `${data.alignment.angle_degrees}°`)}
      </div>` +
      `<h4 class="phead">Matrix (${matrix.shape}) — groups × numeric variables</h4>` +
      table(
        ["Group", ...matrix.columns, "Row total"],
        matrix.values.map((row, index) => [
          matrix.rows[index],
          ...row.map((value) => smart(value)),
          `<b>${smart(matrix.row_totals[index])}</b>`,
        ])
      ) +
      note(data.interpretation)
    );
  };

  /* ---------- 5. Probability ---------- */
  PHASE_VIEWS.phase5 = (data) =>
    `<h4 class="phead">Simple probability</h4>` +
    table(
      ["Event", "Notation", "Calculation", "Probability"],
      data.simple.map((item) => [
        item.event,
        item.notation,
        `${item.count} / ${item.of}`,
        `${item.percent}%`,
      ])
    ) +
    `<h4 class="phead">Conditional probability</h4>` +
    table(
      ["Event", "Notation", "Calculation", "Probability"],
      data.conditional.map((item) => [
        item.event,
        item.notation,
        `${item.count} / ${item.of}`,
        `${item.percent}%`,
      ])
    ) +
    statRow(
      "Are the events independent?",
      data.independence.independent ? "Approximately independent" : "No — they are dependent"
    ) +
    `<h4 class="phead">Expected value E(X)</h4>` +
    table(
      ["Group", "P(X)", "Mean", "Contribution"],
      data.expected_value.table.map((row) => [
        row.label,
        row.probability,
        smart(row.mean),
        smart(row.contribution),
      ])
    ) +
    statRow(label(data, "expected_one", "Weighted E(X)"), smart(data.expected_value.per_expense)) +
    statRow(label(data, "expected_day", "Arithmetic mean"), smart(data.expected_value.per_day)) +
    note(data.interpretation);

  /* ---------- 6. Sampling ---------- */
  PHASE_VIEWS.phase6 = (data) =>
    table(
      ["", "Population", "Sample"],
      [
        ["Size n", data.population.n, data.sample.n],
        ["Mean", smart(data.population.mean), smart(data.sample.mean)],
        ["Standard deviation", smart(data.population.std), smart(data.sample.std)],
      ]
    ) +
    `<div class="pgrid">
      ${statRow("Standard error SE", smart(data.sample.standard_error))}
      ${statRow("Sampling fraction", `${data.sample.fraction}%`)}
      ${statRow("Estimation error", smart(data.comparison.error))}
      ${statRow("Error %", `${data.comparison.error_percent}%`)}
      ${statRow("Observed SE (400 samples)", smart(data.sampling_distribution.observed_se))}
      ${statRow("Theoretical SE σ/√n", smart(data.sampling_distribution.theoretical_se))}
    </div>` +
    `<p class="pwhy">${data.population.definition} · ${data.sample.definition}</p>` +
    note(data.interpretation);

  /* ---------- 7. Confidence intervals ---------- */
  PHASE_VIEWS.phase7 = (data) => {
    const main = data.expense_mean;
    return (
      `<div class="ci">
        <div class="ci__bar">
          <span>${smart(main.low)}</span>
          <div class="ci__track"><i></i><b>${smart(main.mean)}</b></div>
          <span>${smart(main.high)}</span>
        </div>
      </div>` +
      `<div class="pgrid">
        ${statRow("Confidence level", `${main.confidence}%`)}
        ${statRow("Sample size n", main.n)}
        ${statRow("Mean", smart(main.mean))}
        ${statRow("Standard deviation", smart(main.std))}
        ${statRow("Standard error", smart(main.standard_error))}
        ${statRow("Critical t", main.t_critical)}
        ${statRow("Margin of error", `± ${smart(main.margin)}`)}
        ${statRow(
          label(data, "second", "Secondary interval"),
          `${smart(data.daily_mean.low)} — ${smart(data.daily_mean.high)}`
        )}
      </div>` +
      (data.per_category.length
        ? `<h4 class="phead">Confidence intervals by group</h4>` +
          table(
            ["Group", "n", "Mean", "95% interval"],
            data.per_category.map((row) => [
              row.label,
              row.n,
              smart(row.mean),
              `${smart(row.low)} — ${smart(row.high)}`,
            ])
          )
        : "") +
      note(data.interpretation)
    );
  };

  /* ---------- 8. Hypothesis test ---------- */
  PHASE_VIEWS.phase8 = (data) =>
    `<div class="hyp">
      <p class="hyp__h">${data.h0}</p>
      <p class="hyp__h">${data.h1}</p>
    </div>` +
    `<div class="pgrid">
      ${statRow("Test", data.test)}
      ${statRow("Significance level α", data.alpha)}
      ${statRow("Sample size n", data.n)}
      ${statRow("Sample mean", smart(data.sample_mean))}
      ${statRow("Reference value μ₀", smart(data.reference))}
      ${statRow("Standard deviation", smart(data.std))}
      ${statRow("Standard error", smart(data.standard_error))}
      ${statRow("Test statistic t", data.t_statistic)}
      ${statRow("Degrees of freedom df", data.df)}
      ${statRow("Critical t", `± ${data.t_critical}`)}
      ${statRow("p-value", showP(data.p_value))}
    </div>` +
    `<p class="verdict ${data.reject_null ? "verdict--reject" : "verdict--keep"}">${data.decision}</p>` +
    note(data.conclusion);

  /* ---------- 9. ANOVA ---------- */
  PHASE_VIEWS.phase9 = (data) => {
    if (data.unavailable) return note(data.unavailable);
    return (
      `<div class="hyp">
        <p class="hyp__h">${data.h0}</p>
        <p class="hyp__h">${data.h1}</p>
      </div>` +
      table(
        ["Group", "n", "Mean", "SD"],
        data.groups.map((row) => [row.name, row.n, smart(row.mean), smart(row.std)])
      ) +
      `<h4 class="phead">ANOVA table</h4>` +
      table(
        ["Source", "SS", "df", "MS"],
        [
          ["Between groups", smart(data.table.between.ss), data.table.between.df, smart(data.table.between.ms)],
          ["Within groups", smart(data.table.within.ss), data.table.within.df, smart(data.table.within.ms)],
        ]
      ) +
      `<div class="pgrid">
        ${statRow("Grand mean", smart(data.grand_mean))}
        ${statRow("F statistic", data.f_statistic)}
        ${statRow("p-value", showP(data.p_value))}
        ${statRow("α", data.alpha)}
      </div>` +
      `<p class="verdict ${data.reject_null ? "verdict--reject" : "verdict--keep"}">${data.decision}</p>` +
      note(data.conclusion)
    );
  };

  /* ---------- 10. Calculus ---------- */
  PHASE_VIEWS.phase10 = (data) => {
    if (data.unavailable) return note(data.unavailable);
    return (
      lineChart(data.points) +
      `<div class="pgrid">
        ${statRow("Function", data.function)}
        ${statRow(label(data, "period", "Range"), data.month)}
        ${statRow(label(data, "count", "Data points"), data.days)}
        ${statRow("Linear fit", data.linear.equation)}
        ${statRow("First derivative", data.linear.derivative)}
        ${statRow("R²", data.linear.r_squared)}
        ${statRow("Quadratic fit", data.quadratic.equation)}
        ${statRow("Its derivative", data.quadratic.derivative)}
        ${statRow("Second derivative", smart(data.quadratic.second_derivative))}
        ${statRow(label(data, "rateStart", "Rate at start"), smart(data.rates.at_start))}
        ${statRow(label(data, "rateEnd", "Rate at end"), smart(data.rates.at_end))}
        ${statRow("Trend", data.trend)}
      </div>` +
      note(data.interpretation)
    );
  };

  /* ---------- 11. Visualization ---------- */
  PHASE_VIEWS.phase11 = (data) =>
    `<div class="pviz">
      <div class="pviz__item">
        <h4 class="phead">${data.bar.title}</h4>
        ${barChart(data.bar.labels, data.bar.values)}
        <p class="pwhy">${data.bar.why}</p>
      </div>
      <div class="pviz__item">
        <h4 class="phead">${data.histogram.title}</h4>
        ${histogramChart(data.histogram.bins)}
        <p class="pwhy">${data.histogram.why}</p>
      </div>
      <div class="pviz__item">
        <h4 class="phead">${data.box.title}</h4>
        ${boxPlot(data.box.data, data.box.outliers)}
        <p class="pwhy">${data.box.why}</p>
      </div>
      <div class="pviz__item">
        <h4 class="phead">${data.scatter.title}</h4>
        ${scatterChart(data.scatter.points)}
        <p class="pwhy">${data.scatter.why}</p>
      </div>
      <div class="pviz__item">
        <h4 class="phead">${data.line.title}</h4>
        ${lineChart(data.line.points)}
        <p class="pwhy">${data.line.why}</p>
      </div>
    </div>` + note(data.interpretation);

  /* ---------- 12. Conclusion ---------- */
  PHASE_VIEWS.phase12 = (data) =>
    `<h4 class="phead">Main findings</h4>
     <ul class="plist">${data.findings.map((item) => `<li>${item}</li>`).join("")}</ul>` +
    `<h4 class="phead">Statistical results</h4>` +
    table(
      ["Test", "Result", "Decision"],
      data.statistical_results.map((row) => [row.name, row.result, row.decision])
    ) +
    `<h4 class="phead">Significant relationships</h4>
     <ul class="plist">${data.relationships.map((item) => `<li>${item}</li>`).join("")}</ul>` +
    `<h4 class="phead">Conclusion</h4>${note(data.conclusion)}` +
    `<h4 class="phead">Future improvements</h4>
     <ul class="plist">${data.improvements.map((item) => `<li>${item}</li>`).join("")}</ul>`;
})();
