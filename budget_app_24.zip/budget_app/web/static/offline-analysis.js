/* =========================================================
   offline-analysis.js — الـ 12 مرحلة جوه المتصفح

   نسخة مطابقة لـ app/analysis.py + app/inference.py عشان الصفحة
   تشتغل بالدبل كليك من غير سيرفر بايثون. نفس المعادلات ونفس أسماء
   الحقول بالظبط، فالواجهة مبتفرقش بين النسختين.

   بايثون يفضل هو الأصل: أي تعديل في المعادلات يتعمل هناك الأول.
   ========================================================= */

window.OfflineAnalysis = (function () {
  "use strict";

  const CATS = ["needs", "wants", "savings"];
  const LABELS = { needs: "احتياجات", wants: "كماليات", savings: "توفير" };
  const CURRENCY = "جنيه";
  const MIN_ROWS = 12;
  const ALPHA = 0.05;

  const round = (value, digits = 2) => {
    const factor = Math.pow(10, digits);
    return Math.round((Number(value) + Number.EPSILON) * factor) / factor;
  };

  const sum = (values) => values.reduce((total, value) => total + value, 0);
  const mean = (values) => (values.length ? sum(values) / values.length : 0);

  const fmt = (value, digits = 0) =>
    Number(value || 0).toLocaleString("en-US", {
      minimumFractionDigits: digits,
      maximumFractionDigits: digits,
    });

  /* =======================================================
     رياضيات الاستدلال (نسخة inference.py)
     ======================================================= */
  function lgamma(x) {
    const c = [
      676.5203681218851, -1259.1392167224028, 771.32342877765313,
      -176.61502916214059, 12.507343278686905, -0.13857109526572012,
      9.9843695780195716e-6, 1.5056327351493116e-7,
    ];
    if (x < 0.5) return Math.log(Math.PI / Math.sin(Math.PI * x)) - lgamma(1 - x);
    x -= 1;
    let a = 0.99999999999980993;
    const t = x + 7.5;
    c.forEach((value, index) => {
      a += value / (x + index + 1);
    });
    return 0.5 * Math.log(2 * Math.PI) + (x + 0.5) * Math.log(t) - t + Math.log(a);
  }

  /* الكسر المستمر بتاع دالة بيتا الناقصة (Lentz) */
  function betaContinuedFraction(a, b, x) {
    const tiny = 1e-30;
    const qab = a + b;
    const qap = a + 1;
    const qam = a - 1;

    let c = 1;
    let d = 1 - (qab * x) / qap;
    if (Math.abs(d) < tiny) d = tiny;
    d = 1 / d;
    let result = d;

    for (let step = 1; step <= 300; step += 1) {
      const even = 2 * step;
      let numerator = (step * (b - step) * x) / ((qam + even) * (a + even));

      d = 1 + numerator * d;
      if (Math.abs(d) < tiny) d = tiny;
      c = 1 + numerator / c;
      if (Math.abs(c) < tiny) c = tiny;
      d = 1 / d;
      result *= d * c;

      numerator = (-(a + step) * (qab + step) * x) / ((a + even) * (qap + even));
      d = 1 + numerator * d;
      if (Math.abs(d) < tiny) d = tiny;
      c = 1 + numerator / c;
      if (Math.abs(c) < tiny) c = tiny;
      d = 1 / d;
      const delta = d * c;
      result *= delta;

      if (Math.abs(delta - 1) < 3e-16) break;
    }

    return result;
  }

  function incompleteBeta(a, b, x) {
    if (x <= 0) return 0;
    if (x >= 1) return 1;

    const front = Math.exp(
      lgamma(a + b) - lgamma(a) - lgamma(b) + a * Math.log(x) + b * Math.log(1 - x)
    );

    if (x < (a + 1) / (a + b + 2)) return (front * betaContinuedFraction(a, b, x)) / a;
    return 1 - (front * betaContinuedFraction(b, a, 1 - x)) / b;
  }

  const tTwoTailedP = (t, df) =>
    df <= 0 ? 1 : Math.min(1, incompleteBeta(df / 2, 0.5, df / (df + t * t)));

  function tCritical(df, confidence = 0.95) {
    if (df <= 0) return 1.96;
    const target = 1 - confidence;
    let low = 0;
    let high = 100;
    for (let step = 0; step < 200; step += 1) {
      const middle = (low + high) / 2;
      if (tTwoTailedP(middle, df) > target) low = middle;
      else high = middle;
    }
    return round((low + high) / 2, 6);
  }

  function fPValue(f, df1, df2) {
    if (f <= 0 || df1 <= 0 || df2 <= 0) return 1;
    const x = (df1 * f) / (df1 * f + df2);
    return Math.max(0, Math.min(1, 1 - incompleteBeta(df1 / 2, df2 / 2, x)));
  }

  const normalCdf = (x, mu, sigma) =>
    0.5 * (1 + erf((x - mu) / (sigma * Math.SQRT2)));

  function erf(x) {
    const sign = x < 0 ? -1 : 1;
    x = Math.abs(x);
    const t = 1 / (1 + 0.3275911 * x);
    const y =
      1 -
      ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
        0.254829592) *
        t *
        Math.exp(-x * x);
    return sign * y;
  }

  function linearRegression(xs, ys) {
    const count = xs.length;
    if (count < 2) return { slope: 0, intercept: 0, r: 0, r_squared: 0, n: count };

    const meanX = mean(xs);
    const meanY = mean(ys);
    let covariance = 0;
    let varianceX = 0;
    let varianceY = 0;

    xs.forEach((x, index) => {
      covariance += (x - meanX) * (ys[index] - meanY);
      varianceX += Math.pow(x - meanX, 2);
      varianceY += Math.pow(ys[index] - meanY, 2);
    });

    const slope = varianceX ? covariance / varianceX : 0;
    const denominator = Math.sqrt(varianceX * varianceY);
    const r = denominator ? covariance / denominator : 0;

    return { slope, intercept: meanY - slope * meanX, r, r_squared: r * r, n: count };
  }

  /* حل نظام 3×3 بحذف جاوس — للمنحنى التربيعي */
  function solveSystem(matrix) {
    const size = matrix.length;
    const rows = matrix.map((row) => [...row]);

    for (let column = 0; column < size; column += 1) {
      let pivot = column;
      for (let index = column; index < size; index += 1) {
        if (Math.abs(rows[index][column]) > Math.abs(rows[pivot][column])) pivot = index;
      }
      if (Math.abs(rows[pivot][column]) < 1e-12) return null;
      [rows[column], rows[pivot]] = [rows[pivot], rows[column]];

      for (let target = 0; target < size; target += 1) {
        if (target === column) continue;
        const factor = rows[target][column] / rows[column][column];
        for (let position = column; position <= size; position += 1) {
          rows[target][position] -= factor * rows[column][position];
        }
      }
    }

    return rows.map((row, index) => row[size] / row[index]);
  }

  function quadraticFit(xs, ys) {
    if (xs.length < 3) return { a: 0, b: 0, c: 0, n: xs.length };

    const power = (exponent) => sum(xs.map((x) => Math.pow(x, exponent)));
    const cross = (exponent) => sum(xs.map((x, index) => Math.pow(x, exponent) * ys[index]));

    const solution = solveSystem([
      [power(4), power(3), power(2), cross(2)],
      [power(3), power(2), power(1), cross(1)],
      [power(2), power(1), xs.length, cross(0)],
    ]);

    if (!solution) return { a: 0, b: 0, c: 0, n: xs.length };
    return { a: solution[0], b: solution[1], c: solution[2], n: xs.length };
  }

  function moments(values) {
    const count = values.length;
    const average = mean(values);
    const variance = sum(values.map((value) => Math.pow(value - average, 2))) / count;
    const std = Math.sqrt(variance);

    const skew =
      count < 3 || !std
        ? 0
        : sum(values.map((value) => Math.pow((value - average) / std, 3))) / count;

    const kurt =
      count < 4 || !variance
        ? 0
        : sum(values.map((value) => Math.pow(value - average, 4))) /
            (count * variance * variance) -
          3;

    return { skew, kurt };
  }

  function shapeLabel(skew) {
    if (skew > 1) return "ملتوي بشدة ناحية اليمين";
    if (skew > 0.5) return "ملتوي ناحية اليمين";
    if (skew < -1) return "ملتوي بشدة ناحية الشمال";
    if (skew < -0.5) return "ملتوي ناحية الشمال";
    return "متماثل تقريباً";
  }

  function quantile(sorted, percent) {
    if (!sorted.length) return 0;
    const position = (sorted.length - 1) * (percent / 100);
    const low = Math.floor(position);
    const high = Math.ceil(position);
    if (low === high) return sorted[low];
    return sorted[low] + (sorted[high] - sorted[low]) * (position - low);
  }

  function sampleStd(values) {
    const count = values.length;
    if (count < 2) return 0;
    const average = mean(values);
    return Math.sqrt(sum(values.map((value) => Math.pow(value - average, 2))) / (count - 1));
  }

  function confidenceInterval(values, confidence = 0.95) {
    const count = values.length;
    const average = mean(values);
    if (count < 2) {
      return { mean: average, std: 0, standard_error: 0, t_critical: 0, margin: 0, low: average, high: average, confidence: confidence * 100, n: count };
    }
    const std = sampleStd(values);
    const standardError = std / Math.sqrt(count);
    const critical = tCritical(count - 1, confidence);
    const margin = critical * standardError;

    return {
      mean: average,
      std,
      standard_error: standardError,
      t_critical: critical,
      margin,
      low: average - margin,
      high: average + margin,
      confidence: confidence * 100,
      n: count,
    };
  }

  const showP = (value) => (value < 0.0001 ? "< 0.0001" : `= ${value.toFixed(5)}`);

  const signed = (value, digits = 1) =>
    `${value < 0 ? "−" : "+"} ${fmt(Math.abs(value), digits)}`;

  /* الأرقام العربية والفارسية لازم تتقرا زي اللاتينية بالظبط —
     لأن بايثون بيقراها، ولو المتصفح مقراهاش النسختين هيختلفوا. */
  const ARABIC_DIGITS = { "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4", "٥": "5",
    "٦": "6", "٧": "7", "٨": "8", "٩": "9", "۰": "0", "۱": "1", "۲": "2", "۳": "3",
    "۴": "4", "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9", "٫": "." };

  function toNumber(raw) {
    if (typeof raw === "number") return Number.isFinite(raw) ? raw : null;
    if (raw === null || raw === undefined) return null;

    const text = String(raw)
      .replace(/[٠-٩۰-۹٫]/g, (char) => ARABIC_DIGITS[char])
      .replace(/,/g, "")
      .trim();

    if (!text) return null;
    const value = Number(text);
    return Number.isFinite(value) ? value : null;
  }

  /* =======================================================
     المرحلة 1 — تجهيز البيانات
     ======================================================= */
  function phase1(rows) {
    const dropped = { missing: 0, invalid_amount: 0, unknown_category: 0, duplicate: 0 };
    const seen = new Set();
    const records = [];

    rows.forEach((row, index) => {
      const day = String(row.date || row.day || "").trim();
      const category = String(row.category || "").trim().toLowerCase();
      const description = String(row.description || "").trim();
      const rawAmount = row.amount;

      if (!day || !category || rawAmount === undefined || rawAmount === null || rawAmount === "") {
        dropped.missing += 1;
        return;
      }

      const amount = toNumber(rawAmount);
      if (amount === null || amount <= 0) {
        dropped.invalid_amount += 1;
        return;
      }

      if (!CATS.includes(category)) {
        dropped.unknown_category += 1;
        return;
      }

      const signature = `${day}|${category}|${round(amount)}|${description}`;
      if (seen.has(signature)) {
        dropped.duplicate += 1;
        return;
      }
      seen.add(signature);

      records.push({
        row_id: index + 1,
        day,
        month: day.slice(0, 7),
        category,
        amount: round(amount),
        description,
      });
    });

    if (records.length < MIN_ROWS) {
      throw new Error(
        `الداتاست فيها ${records.length} صف بس، والتحليل محتاج ${MIN_ROWS} على الأقل عشان النتايج تبقى ذات دلالة.`
      );
    }

    const months = [...new Set(records.map((record) => record.month))].sort();
    const droppedTotal = Object.values(dropped).reduce((a, b) => a + b, 0);
    const days = new Set(records.map((record) => record.day));

    return {
      records,
      summary: {
        raw_rows: rows.length,
        clean_rows: records.length,
        dropped_total: droppedTotal,
        dropped_detail: dropped,
        months,
        days_covered: days.size,
        variables: {
          numerical: [
            { name: "amount", label: "مبلغ المصروف", type: "متصل" },
            { name: "day_index", label: "رقم اليوم في الشهر", type: "متقطع" },
          ],
          categorical: [
            { name: "category", label: "التصنيف", levels: CATS.map((key) => LABELS[key]) },
            { name: "month", label: "الشهر", levels: months },
          ],
        },
        interpretation:
          `اتحمّل ${rows.length} صف، واتشال منهم ${droppedTotal} ` +
          `(${dropped.missing} ناقص، ${dropped.invalid_amount} مبلغ غلط، ` +
          `${dropped.duplicate} مكرر، ${dropped.unknown_category} تصنيف مجهول). ` +
          `باقي ${records.length} صف نضاف على ${months.length} شهر.`,
      },
    };
  }

  const amountsOf = (records, category) =>
    records.filter((record) => !category || record.category === category).map((record) => record.amount);

  function dailyTotals(records) {
    const totals = {};
    records.forEach((record) => {
      totals[record.day] = (totals[record.day] || 0) + record.amount;
    });
    return Object.fromEntries(Object.entries(totals).sort(([a], [b]) => a.localeCompare(b)));
  }

  /* =======================================================
     المرحلة 2 — الإحصاء الوصفي
     ======================================================= */
  function phase2(records) {
    const values = amountsOf(records).sort((a, b) => a - b);
    const count = values.length;
    const average = mean(values);
    const median = quantile(values, 50);

    /* المنوال للبيانات المتصلة: أكتر فئة تكراراً */
    const binWidth = 50;
    const buckets = {};
    values.forEach((value) => {
      const key = Math.floor(value / binWidth);
      buckets[key] = (buckets[key] || 0) + 1;
    });
    const topBucket = Object.entries(buckets).sort((a, b) => b[1] - a[1])[0];
    const low = Number(topBucket[0]) * binWidth;

    const variance = sum(values.map((value) => Math.pow(value - average, 2))) / (count - 1);
    const std = Math.sqrt(variance);
    const q1 = quantile(values, 25);
    const q3 = quantile(values, 75);

    const perCategory = CATS.map((key) => {
      const group = amountsOf(records, key);
      return {
        key,
        label: LABELS[key],
        n: group.length,
        mean: round(mean(group)),
        median: round(quantile([...group].sort((a, b) => a - b), 50)),
        std: round(sampleStd(group)),
        total: round(sum(group)),
      };
    });

    const gap = average - median;

    return {
      n: count,
      mean: round(average),
      median: round(median),
      mode: {
        value: round(low + binWidth / 2),
        count: topBucket[1],
        range: `${fmt(low)} — ${fmt(low + binWidth)}`,
        bin_width: binWidth,
      },
      min: round(values[0]),
      max: round(values[count - 1]),
      range: round(values[count - 1] - values[0]),
      variance: round(variance),
      std: round(std),
      cv: average ? round((std / average) * 100, 1) : 0,
      q1: round(q1),
      q2: round(median),
      q3: round(q3),
      iqr: round(q3 - q1),
      per_category: perCategory,
      interpretation:
        `متوسط المصروف ${fmt(average)} ${CURRENCY} والوسيط ${fmt(median)}. ` +
        (gap > std * 0.15
          ? `المتوسط أعلى من الوسيط بـ ${fmt(gap)} — يعني فيه مصاريف كبيرة قليلة بتشد المتوسط لفوق، والوسيط أصدق في وصف يومك العادي.`
          : "المتوسط والوسيط قريبين من بعض، يعني مفيش قيم متطرفة بتشوّه الصورة.") +
        ` ونص مصاريفك بتقع بين ${fmt(q1)} و ${fmt(q3)} (المدى الربيعي = ${fmt(q3 - q1)}).`,
    };
  }

  /* =======================================================
     المرحلة 3 — تحليل التوزيع
     ======================================================= */
  function phase3(records, bins = 12) {
    const values = amountsOf(records).sort((a, b) => a - b);
    const count = values.length;
    const low = values[0];
    const high = values[count - 1];
    const width = high > low ? (high - low) / bins : 1;

    const frequency = [];
    let cumulative = 0;
    for (let index = 0; index < bins; index += 1) {
      const start = low + index * width;
      const end = start + width;
      const inside = values.filter(
        (value) => (value >= start && value < end) || (index === bins - 1 && value === high)
      );
      cumulative += inside.length;
      frequency.push({
        start: round(start),
        end: round(end),
        label: `${fmt(start)}—${fmt(end)}`,
        count: inside.length,
        percent: round((inside.length / count) * 100, 1),
        cumulative_percent: round((cumulative / count) * 100, 1),
      });
    }

    const q1 = quantile(values, 25);
    const q3 = quantile(values, 75);
    const iqr = q3 - q1;
    const lowerFence = q1 - 1.5 * iqr;
    const upperFence = q3 + 1.5 * iqr;
    const inliers = values.filter((value) => value >= lowerFence && value <= upperFence);

    const outliers = [...records]
      .filter((record) => record.amount > upperFence || record.amount < lowerFence)
      .sort((a, b) => b.amount - a.amount)
      .map((record) => ({
        amount: record.amount,
        day: record.day,
        label: LABELS[record.category],
        description: record.description,
      }));

    const { skew, kurt } = moments(values);

    return {
      frequency,
      box_plot: {
        min: round(inliers.length ? Math.min(...inliers) : low),
        q1: round(q1),
        median: round(quantile(values, 50)),
        q3: round(q3),
        max: round(inliers.length ? Math.max(...inliers) : high),
        iqr: round(iqr),
        lower_fence: round(Math.max(lowerFence, 0)),
        upper_fence: round(upperFence),
      },
      outliers: outliers.slice(0, 8),
      outliers_count: outliers.length,
      shape: {
        skewness: round(skew, 3),
        kurtosis: round(kurt, 3),
        label: shapeLabel(skew),
        tails: kurt > 0.5 ? "ذيول تقيلة (قيم متطرفة أكتر من الطبيعي)" : "ذيول عادية",
      },
      mean: round(mean(values)),
      std: round(sampleStd(values)),
      interpretation:
        `التوزيع ${shapeLabel(skew)} (معامل التواء ${skew.toFixed(2)}). ` +
        `حسب قاعدة الربيعات، أي مصروف فوق ${fmt(upperFence)} يعتبر شاذ — ` +
        (outliers.length ? `ولقينا ${outliers.length} مصروف زي كده.` : "ومفيش ولا مصروف تعدّى الحد ده.") +
        (skew > 0.5
          ? " الالتواء لليمين طبيعي في بيانات المصاريف: أغلب الصرف صغير ومتكرر، وفيه صرفات كبيرة نادرة."
          : ""),
    };
  }

  /* =======================================================
     المرحلة 4 — الجبر الخطي
     ======================================================= */
  function phase4(records, income) {
    const spendVector = CATS.map((key) => round(sum(amountsOf(records, key))));
    const weightVector = [1.0, 0.4, 1.5];
    const dot = sum(spendVector.map((value, index) => value * weightVector[index]));
    const totalSpend = sum(spendVector);
    const magnitude = Math.sqrt(sum(spendVector.map((value) => value * value)));

    const scalar = 1.1;
    const scaledVector = spendVector.map((value) => round(value * scalar));

    const months = [...new Set(records.map((record) => record.month))].sort();
    const matrix = months.map((month) =>
      CATS.map((key) =>
        round(
          sum(
            records
              .filter((record) => record.month === month && record.category === key)
              .map((record) => record.amount)
          )
        )
      )
    );

    const rowTotals = matrix.map((row) => round(sum(row)));
    const columnTotals = CATS.map((_, index) =>
      round(sum(matrix.map((row) => row[index])))
    );

    const ideal = [0.5, 0.3, 0.2];
    const idealVector = ideal.map((share) => (income || totalSpend) * share);
    const idealMagnitude = Math.sqrt(sum(idealVector.map((value) => value * value)));
    const idealDot = sum(spendVector.map((value, index) => value * idealVector[index]));
    const cosine = magnitude && idealMagnitude ? idealDot / (magnitude * idealMagnitude) : 0;
    const angle = (Math.acos(Math.max(Math.min(cosine, 1), -1)) * 180) / Math.PI;

    return {
      labels: CATS.map((key) => LABELS[key]),
      spend_vector: spendVector,
      weight_vector: weightVector,
      dot_product: round(dot),
      magnitude: round(magnitude),
      scalar,
      scaled_vector: scaledVector,
      scaled_total: round(sum(scaledVector)),
      extra_cost: round(sum(scaledVector) - totalSpend),
      matrix: {
        rows: months,
        columns: CATS.map((key) => LABELS[key]),
        values: matrix,
        row_totals: rowTotals,
        column_totals: columnTotals,
        shape: `${matrix.length}×${CATS.length}`,
      },
      alignment: {
        ideal_vector: idealVector.map((value) => round(value)),
        cosine: round(cosine, 4),
        angle_degrees: round(angle, 2),
      },
      interpretation:
        `متجه إنفاقك [${spendVector.map((value) => fmt(value)).join(", ")}] وطوله ${fmt(magnitude)}. ` +
        `حاصل الضرب النقطي مع أوزان الأولوية = ${fmt(dot)} — الرقم ده بيوزن جنيه التوفير بـ 1.5 ` +
        `وجنيه الكماليات بـ 0.4، فبيبقى مقياس لجودة إنفاقك مش حجمه. ` +
        `الزاوية بين إنفاقك الفعلي والخطة المثالية ${angle.toFixed(1)}° ` +
        (angle < 10
          ? "(قريبة من صفر = إنفاقك يوازي الخطة تقريباً)."
          : "(كل ما الزاوية كبرت، كل ما إنفاقك بعد عن شكل الخطة).") +
        ` ولو زوّدت كل بند 10٪ هتدفع ${fmt(sum(scaledVector) - totalSpend)} زيادة.`,
    };
  }

  /* =======================================================
     المرحلة 5 — الاحتمالات
     ======================================================= */
  function phase5(records) {
    const total = records.length;
    const values = amountsOf(records);
    const limit = round(mean(values) * 2);

    const large = records.filter((record) => record.amount >= limit);
    const wants = records.filter((record) => record.category === "wants");
    const largeWants = wants.filter((record) => record.amount >= limit);

    const pLarge = large.length / total;
    const pWants = wants.length / total;
    const pLargeGivenWants = wants.length ? largeWants.length / wants.length : 0;
    const pWantsGivenLarge = large.length ? largeWants.length / large.length : 0;
    const gap = Math.abs(pLargeGivenWants - pLarge);

    const days = Object.keys(dailyTotals(records)).length;
    const perDay = days ? total / days : 0;

    let expectedValue = 0;
    const expectedTable = [];
    CATS.forEach((key) => {
      const group = amountsOf(records, key);
      if (!group.length) return;
      const probability = group.length / total;
      const groupMean = mean(group);
      const contribution = probability * groupMean;
      expectedValue += contribution;
      expectedTable.push({
        label: LABELS[key],
        probability: round(probability, 4),
        mean: round(groupMean),
        contribution: round(contribution),
      });
    });

    return {
      threshold: limit,
      simple: [
        {
          event: `المصروف ≥ ${fmt(limit)} ${CURRENCY}`,
          notation: "P(A)",
          count: large.length,
          of: total,
          probability: round(pLarge, 4),
          percent: round(pLarge * 100, 1),
        },
        {
          event: "المصروف من الكماليات",
          notation: "P(B)",
          count: wants.length,
          of: total,
          probability: round(pWants, 4),
          percent: round(pWants * 100, 1),
        },
      ],
      conditional: [
        {
          event: "مصروف كبير بشرط إنه كماليات",
          notation: "P(A|B)",
          count: largeWants.length,
          of: wants.length,
          probability: round(pLargeGivenWants, 4),
          percent: round(pLargeGivenWants * 100, 1),
        },
        {
          event: "كماليات بشرط إنه مصروف كبير",
          notation: "P(B|A)",
          count: largeWants.length,
          of: large.length,
          probability: round(pWantsGivenLarge, 4),
          percent: round(pWantsGivenLarge * 100, 1),
        },
      ],
      independence: {
        p_a: round(pLarge, 4),
        p_a_given_b: round(pLargeGivenWants, 4),
        gap: round(gap, 4),
        independent: gap < 0.05,
      },
      expected_value: {
        per_expense: round(expectedValue),
        per_day: round(expectedValue * perDay),
        expenses_per_day: round(perDay),
        table: expectedTable,
      },
      interpretation:
        `احتمال إن أي مصروف يبقى كبير (≥ ${fmt(limit)}) هو ${(pLarge * 100).toFixed(1)}٪، ` +
        `لكن لو عرفنا إنه كماليات الاحتمال بيبقى ${(pLargeGivenWants * 100).toFixed(1)}٪ — ` +
        (gap >= 0.05
          ? "يعني التصنيف بيغيّر الاحتمال فعلاً، والحدثين مش مستقلين."
          : "الفرق صغير، يعني التصنيف تقريباً مش بيأثر على حجم المصروف.") +
        ` والقيمة المتوقعة للمصروف الواحد ${fmt(expectedValue)} ${CURRENCY}، ` +
        `يعني في اليوم متوقع تصرف حوالي ${fmt(expectedValue * perDay)}.`,
    };
  }

  /* =======================================================
     المرحلة 6 — المعاينة والاستدلال
     ======================================================= */
  function phase6(records) {
    const population = amountsOf(records);
    const size = population.length;
    const sampleSize = Math.min(Math.max(10, Math.floor(size / 3)), 40, size);

    const pick = (source, howMany) => {
      const pool = [...source];
      const chosen = [];
      for (let index = 0; index < howMany; index += 1) {
        chosen.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
      }
      return chosen;
    };

    const sample = pick(population, sampleSize);
    const populationMean = mean(population);
    const populationStd = Math.sqrt(
      sum(population.map((value) => Math.pow(value - populationMean, 2))) / size
    );

    const sampleMean = mean(sample);
    const sampleDeviation = sampleStd(sample);
    const standardError = sampleDeviation / Math.sqrt(sampleSize);

    const error = sampleMean - populationMean;
    const errorPercent = populationMean ? (Math.abs(error) / populationMean) * 100 : 0;

    const repeatedMeans = [];
    for (let run = 0; run < 400; run += 1) {
      repeatedMeans.push(mean(pick(population, sampleSize)));
    }
    const meansMean = mean(repeatedMeans);
    const meansStd = sampleStd(repeatedMeans);
    const theoreticalSe = populationStd / Math.sqrt(sampleSize);

    return {
      population: {
        definition: "كل المصاريف المسجّلة في الداتاست بعد التنظيف",
        n: size,
        mean: round(populationMean),
        std: round(populationStd),
      },
      sample: {
        definition: `عيّنة عشوائية بسيطة حجمها ${sampleSize} (كل مصروف له نفس فرصة الاختيار)`,
        n: sampleSize,
        mean: round(sampleMean),
        std: round(sampleDeviation),
        standard_error: round(standardError),
        fraction: round((sampleSize / size) * 100, 1),
      },
      comparison: {
        error: round(error),
        error_percent: round(errorPercent, 2),
        within_2se: Math.abs(error) <= 2 * standardError,
      },
      sampling_distribution: {
        repeats: repeatedMeans.length,
        mean_of_means: round(meansMean),
        observed_se: round(meansStd),
        theoretical_se: round(theoreticalSe),
      },
      interpretation:
        `العيّنة (${sampleSize} مصروف = ${((sampleSize / size) * 100).toFixed(0)}٪ من الداتا) ` +
        `دّت متوسط ${fmt(sampleMean)} مقابل ${fmt(populationMean)} للمجتمع كله — ` +
        `فرق ${fmt(Math.abs(error))} فقط (${errorPercent.toFixed(1)}٪). ` +
        (Math.abs(error) <= 2 * standardError
          ? "الفرق ده جوه حدود الخطأ المعياري المتوقع، يعني العيّنة ممثّلة."
          : "الفرق أكبر من المتوقع — العيّنة دي وقعت في طرف التوزيع.") +
        ` ولما كررنا السحب 400 مرة، انحراف المتوسطات طلع ${meansStd.toFixed(1)} ` +
        `والنظري σ/√n = ${theoreticalSe.toFixed(1)} — الاتنين قريبين، وده الـ CLT بيشتغل.`,
    };
  }

  /* =======================================================
     المرحلة 7 — فترات الثقة
     ======================================================= */
  function phase7(records) {
    const amounts = amountsOf(records);
    const daily = Object.values(dailyTotals(records));

    const expenseCi = confidenceInterval(amounts);
    const dailyCi = daily.length > 1 ? confidenceInterval(daily) : expenseCi;

    const perCategory = CATS.map((key) => {
      const group = amountsOf(records, key);
      if (group.length < 2) return null;
      const interval = confidenceInterval(group);
      return {
        label: LABELS[key],
        n: interval.n,
        mean: round(interval.mean),
        low: round(interval.low),
        high: round(interval.high),
        margin: round(interval.margin),
      };
    }).filter(Boolean);

    return {
      expense_mean: {
        confidence: 95,
        n: expenseCi.n,
        mean: round(expenseCi.mean),
        std: round(expenseCi.std),
        standard_error: round(expenseCi.standard_error),
        t_critical: round(expenseCi.t_critical, 3),
        margin: round(expenseCi.margin),
        low: round(expenseCi.low),
        high: round(expenseCi.high),
      },
      daily_mean: {
        n: dailyCi.n,
        mean: round(dailyCi.mean),
        low: round(dailyCi.low),
        high: round(dailyCi.high),
        margin: round(dailyCi.margin),
      },
      per_category: perCategory,
      interpretation:
        `فترة الثقة 95٪ لمتوسط المصروف هي [${fmt(expenseCi.low)} — ${fmt(expenseCi.high)}] ${CURRENCY}. ` +
        `معناها: لو كررنا الدراسة 100 مرة بنفس الطريقة، 95 مرة منهم الفترة اللي هتطلع هتكون شايلة ` +
        `المتوسط الحقيقي جواها. وهامش الخطأ ±${fmt(expenseCi.margin)} — كل ما جمّعت بيانات أكتر، ` +
        `كل ما الهامش ضاق (لأنه بيقسم على √n). ` +
        `ومتوسط صرفك اليومي بين ${fmt(dailyCi.low)} و ${fmt(dailyCi.high)}.`,
    };
  }

  /* =======================================================
     المرحلة 8 — اختبار الفروض
     ======================================================= */
  function phase8(records, incomePerDay) {
    const daily = Object.values(dailyTotals(records));
    let values;
    let reference;
    let subject;

    if (incomePerDay > 0 && daily.length >= 3) {
      values = daily;
      reference = incomePerDay;
      subject = "متوسط الصرف اليومي";
    } else {
      values = amountsOf(records);
      reference = Math.round(mean(values) / 10) * 10;
      subject = "متوسط المصروف الواحد";
    }

    const count = values.length;
    const average = mean(values);
    const std = sampleStd(values);
    const standardError = std / Math.sqrt(count);
    const tStatistic = standardError ? (average - reference) / standardError : 0;
    const df = count - 1;
    const pValue = tTwoTailedP(tStatistic, df);
    const reject = pValue < ALPHA;
    const decision = reject ? "نرفض H₀" : "نفشل في رفض H₀";

    return {
      subject,
      h0: `H₀: ${subject} = ${fmt(reference)} ${CURRENCY} (μ = μ₀)`,
      h1: `H₁: ${subject} ≠ ${fmt(reference)} ${CURRENCY} (μ ≠ μ₀)`,
      test: "اختبار t لعيّنة واحدة، ذو طرفين",
      alpha: ALPHA,
      n: count,
      sample_mean: round(average),
      reference: round(reference),
      std: round(std),
      standard_error: round(standardError),
      t_statistic: round(tStatistic, 4),
      df,
      t_critical: round(tCritical(df, 1 - ALPHA), 3),
      p_value: round(pValue, 6),
      reject_null: reject,
      decision,
      conclusion:
        `p-value ${showP(pValue)} ` +
        (reject
          ? `< α = ${ALPHA} → ${decision}. الفرق بين ${subject} الفعلي (${fmt(average)}) ` +
            `والقيمة المرجعية (${fmt(reference)}) فرق حقيقي إحصائياً مش مجرد صدفة.`
          : `> α = ${ALPHA} → ${decision}. البيانات مش بتدّينا دليل كافي إن ${subject} ` +
            `الحقيقي مختلف عن ${fmt(reference)} — الفرق الملاحظ ممكن يكون صدفة.`),
    };
  }

  /* =======================================================
     المرحلة 9 — ANOVA
     ======================================================= */
  function phase9(records) {
    const usable = CATS.map((key) => ({ name: LABELS[key], values: amountsOf(records, key) })).filter(
      (group) => group.values.length >= 2
    );

    if (usable.length < 2) {
      return { unavailable: "محتاج مجموعتين على الأقل، كل واحدة فيها قيمتين" };
    }

    const allValues = usable.flatMap((group) => group.values);
    const totalCount = allValues.length;
    const grandMean = mean(allValues);

    let ssBetween = 0;
    let ssWithin = 0;
    const groups = usable.map((group) => {
      const groupMean = mean(group.values);
      ssBetween += group.values.length * Math.pow(groupMean - grandMean, 2);
      ssWithin += sum(group.values.map((value) => Math.pow(value - groupMean, 2)));
      return {
        name: group.name,
        n: group.values.length,
        mean: round(groupMean),
        std: round(sampleStd(group.values)),
      };
    });

    const dfBetween = usable.length - 1;
    const dfWithin = totalCount - usable.length;
    const msBetween = dfBetween ? ssBetween / dfBetween : 0;
    const msWithin = dfWithin ? ssWithin / dfWithin : 0;
    const fStatistic = msWithin ? msBetween / msWithin : 0;
    const pValue = fPValue(fStatistic, dfBetween, dfWithin);
    const reject = pValue < ALPHA;
    const decision = reject ? "نرفض H₀" : "نفشل في رفض H₀";

    const ordered = [...groups].sort((a, b) => b.mean - a.mean);

    return {
      h0: "H₀: متوسطات المصروف متساوية في كل التصنيفات (μ₁ = μ₂ = μ₃)",
      h1: "H₁: على الأقل تصنيف واحد متوسطه مختلف",
      alpha: ALPHA,
      groups,
      grand_mean: round(grandMean),
      table: {
        between: { ss: round(ssBetween), df: dfBetween, ms: round(msBetween) },
        within: { ss: round(ssWithin), df: dfWithin, ms: round(msWithin) },
      },
      f_statistic: round(fStatistic, 4),
      p_value: round(pValue, 8),
      reject_null: reject,
      decision,
      conclusion:
        `F = ${fStatistic.toFixed(2)} و p-value ${showP(pValue)} ` +
        (reject
          ? `< α = ${ALPHA} → ${decision}. يعني التصنيف بيفرق فعلاً في حجم المصروف: ` +
            `أعلى متوسط عند ${ordered[0].name} (${fmt(ordered[0].mean)}) ` +
            `وأقل متوسط عند ${ordered[ordered.length - 1].name} (${fmt(ordered[ordered.length - 1].mean)}).`
          : `> α = ${ALPHA} → ${decision}. مفيش دليل كافي إن متوسطات التصنيفات مختلفة — ` +
            `التشتت جوه كل تصنيف أكبر من الفرق بينهم.`),
    };
  }

  /* =======================================================
     المرحلة 10 — التفاضل
     ======================================================= */
  function phase10(records, income) {
    const all = dailyTotals(records);
    const months = [...new Set(Object.keys(all).map((day) => day.slice(0, 7)))].sort();
    if (!months.length) return { unavailable: "مفيش بيانات كفاية لدراسة معدل التغير." };

    let target = months[months.length - 1];
    let daily = Object.entries(all).filter(([day]) => day.startsWith(target));

    if (daily.length < 5 && months.length > 1) {
      target = months[months.length - 2];
      daily = Object.entries(all).filter(([day]) => day.startsWith(target));
    }

    if (daily.length < 3) {
      return { unavailable: "محتاجين 3 أيام مختلفة على الأقل لدراسة معدل التغير." };
    }

    const xs = daily.map((_, index) => index + 1);
    let running = 0;
    const cumulative = daily.map(([, value]) => {
      running += value;
      return round(running);
    });

    const line = linearRegression(xs, cumulative);
    const curve = quadraticFit(xs, cumulative);

    const lastDay = xs[xs.length - 1];
    const derivativeEnd = 2 * curve.a * lastDay + curve.b;
    const derivativeStart = 2 * curve.a * xs[0] + curve.b;
    const secondDerivative = 2 * curve.a;
    const averageRate =
      lastDay > 1 ? (cumulative[cumulative.length - 1] - cumulative[0]) / (lastDay - xs[0]) : 0;

    let reachDay = null;
    if (income > 0 && curve.a !== 0) {
      const a = curve.a;
      const b = curve.b;
      const c = curve.c - income;
      const discriminant = b * b - 4 * a * c;
      if (discriminant >= 0) {
        const roots = [
          (-b + Math.sqrt(discriminant)) / (2 * a),
          (-b - Math.sqrt(discriminant)) / (2 * a),
        ].filter((root) => root > 0);
        if (roots.length) reachDay = round(Math.min(...roots), 1);
      }
    } else if (income > 0 && line.slope > 0) {
      reachDay = round((income - line.intercept) / line.slope, 1);
    }

    const trend =
      secondDerivative > 0.5
        ? "بيتسارع — معدل صرفك اليومي بيزيد مع مرور الشهر"
        : secondDerivative < -0.5
        ? "بيهدى — معدل صرفك اليومي بيقل مع مرور الشهر"
        : "ثابت تقريباً — بتصرف بمعدل متساوي";

    return {
      function: "S(t) = الإنفاق التراكمي بعد t يوم",
      month: target,
      days: daily.length,
      points: xs.map((x, index) => ({ t: x, s: cumulative[index] })),
      linear: {
        equation: `S(t) = ${fmt(line.slope, 1)}·t ${signed(line.intercept)}`,
        slope: round(line.slope),
        intercept: round(line.intercept),
        r_squared: round(line.r_squared, 4),
        derivative: `S'(t) = ${fmt(line.slope, 1)} (معدل ثابت)`,
      },
      quadratic: {
        equation: `S(t) = ${curve.a.toFixed(3)}·t² ${signed(curve.b, 2)}·t ${signed(curve.c)}`,
        a: round(curve.a, 4),
        b: round(curve.b, 3),
        c: round(curve.c),
        derivative: `S'(t) = ${(2 * curve.a).toFixed(3)}·t ${signed(curve.b, 2)}`,
        second_derivative: round(secondDerivative, 4),
      },
      rates: {
        average: round(averageRate),
        at_start: round(derivativeStart),
        at_end: round(derivativeEnd),
        change: round(derivativeEnd - derivativeStart),
      },
      reach_income_day: reachDay,
      trend,
      interpretation:
        `التحليل على شهر ${target}. دالة الإنفاق التراكمي ميلها ${fmt(line.slope)} ${CURRENCY}/يوم ` +
        `(R² = ${line.r_squared.toFixed(2)} — كل ما قرب من 1 كل ما الخط بيوصف بياناتك أحسن). ` +
        `المشتقة الأولى هي معدل صرفك اليومي: بدأت الشهر بـ ${fmt(derivativeStart)} ` +
        `ووصلت لـ ${fmt(derivativeEnd)} في اليوم. ` +
        `المشتقة التانية = ${secondDerivative.toFixed(2)}، يعني إنفاقك ${trend}.` +
        (reachDay ? ` وبالمعدل ده متوقع توصل لحد دخلك في اليوم ${reachDay.toFixed(0)} من الشهر.` : ""),
    };
  }

  /* =======================================================
     المرحلة 11 و 12
     ======================================================= */
  function phase11(records, phases) {
    const daily = dailyTotals(records);
    const days = Object.keys(daily);

    return {
      bar: {
        title: "إجمالي الإنفاق حسب التصنيف",
        why: "المقارنة بين فئات — العمود البياني أوضح حاجة للمقارنة الفئوية",
        labels: CATS.map((key) => LABELS[key]),
        values: CATS.map((key) => round(sum(amountsOf(records, key)))),
      },
      histogram: {
        title: "توزيع مبالغ المصاريف",
        why: "بيوري شكل التوزيع: فين بتتكدس مصاريفك وفين الذيل",
        bins: phases.phase3.frequency,
      },
      box: {
        title: "البوكس بلوت — الأرباع والشواذ",
        why: "بيلخّص خمس أرقام + بيحدد الشواذ بصرياً في رسمة واحدة",
        data: phases.phase3.box_plot,
        outliers: phases.phase3.outliers.map((item) => item.amount),
      },
      scatter: {
        title: "اليوم مقابل إجمالي إنفاقه",
        why: "بيكشف هل فيه علاقة بين ترتيب اليوم وحجم الصرف",
        points: days.map((day, index) => ({ x: index + 1, y: round(daily[day]) })),
      },
      line: {
        title: "الإنفاق التراكمي عبر الشهر",
        why: "بيوري اتجاه الصرف مع الوقت — وميل الخط هو المشتقة",
        points: phases.phase10.points || [],
      },
      interpretation:
        "الرسومات مختارة بحيث كل واحدة تجاوب على سؤال مختلف: العمود للمقارنة، " +
        "الهيستوجرام للشكل، البوكس بلوت للشواذ، الانتشار للعلاقة، والخط للاتجاه.",
    };
  }

  function phase12(phases) {
    const descriptive = phases.phase2;
    const distribution = phases.phase3;
    const probability = phases.phase5;
    const sampling = phases.phase6;
    const interval = phases.phase7.expense_mean;
    const test = phases.phase8;
    const anova = phases.phase9 || {};
    const calculus = phases.phase10 || {};

    const statistical = [
      { name: "اختبار t", result: `t = ${test.t_statistic}, p ${showP(test.p_value)}`, decision: test.decision },
    ];
    if (anova.f_statistic !== undefined) {
      statistical.push({
        name: "ANOVA",
        result: `F = ${anova.f_statistic}, p ${showP(anova.p_value)}`,
        decision: anova.decision,
      });
    }

    const relationships = [];
    if (calculus.linear) {
      relationships.push(
        `العلاقة بين اليوم والإنفاق التراكمي خطية بدرجة R² = ${calculus.linear.r_squared} ` +
          `وميل ${fmt(calculus.linear.slope)} ${CURRENCY}/يوم.`
      );
    }
    if (!probability.independence.independent) {
      relationships.push("التصنيف والمبلغ مش مستقلين — نوع المصروف بيأثر على حجمه.");
    }

    return {
      findings: [
        `متوسط المصروف ${fmt(descriptive.mean)} ${CURRENCY} والوسيط ${fmt(descriptive.median)}، بمعامل اختلاف ${descriptive.cv}٪.`,
        `التوزيع ${distribution.shape.label} وفيه ${distribution.outliers_count} مصروف شاذ بقاعدة الربيعات.`,
        `احتمال المصروف الكبير ${probability.simple[0].percent}٪، والقيمة المتوقعة للمصروف الواحد ${fmt(probability.expected_value.per_expense)}.`,
        `عيّنة من ${sampling.sample.n} مصروف قدّرت المتوسط بفرق ${sampling.comparison.error_percent}٪ عن المجتمع كله.`,
        `فترة الثقة 95٪ للمتوسط: [${fmt(interval.low)} — ${fmt(interval.high)}].`,
      ],
      statistical_results: statistical,
      relationships: relationships.length ? relationships : ["مفيش علاقات ذات دلالة واضحة في البيانات الحالية."],
      calculus: calculus.interpretation || "—",
      conclusion:
        `البيانات بتقول إن إنفاقك ${distribution.shape.label} — أغلبه صغير ومتكرر مع صرفات كبيرة نادرة. ` +
        (anova.reject_null
          ? "وتحليل التباين أثبت إن التصنيف بيفرق فعلاً في حجم المصروف، "
          : "وتحليل التباين مالقاش فرق مؤكد بين التصنيفات، ") +
        (calculus.trend ? `وإنفاقك ${calculus.trend}.` : "") +
        " التوصية العملية: راقب الذيل — الصرفات الكبيرة النادرة هي اللي بتكسر الميزانية، " +
        "مش المصاريف اليومية الصغيرة.",
      improvements: [
        "جمع بيانات لشهور أكتر عشان اختبارات الفروض تبقى أقوى إحصائياً",
        "إضافة متغيرات جديدة (يوم الأسبوع، طريقة الدفع) لتحليل أعمق",
        "استخدام اختبار Tukey بعد ANOVA لتحديد أي تصنيفين بالظبط مختلفين",
        "بناء نموذج انحدار متعدد للتنبؤ بالمصروف من أكتر من متغيّر",
      ],
    };
  }

  const TITLES = {
    phase1: "١. جمع البيانات وتجهيزها",
    phase2: "٢. الإحصاء الوصفي",
    phase3: "٣. تحليل التوزيع",
    phase4: "٤. الجبر الخطي",
    phase5: "٥. الاحتمالات",
    phase6: "٦. المعاينة والاستدلال",
    phase7: "٧. فترات الثقة",
    phase8: "٨. اختبار الفروض",
    phase9: "٩. تحليل التباين ANOVA",
    phase10: "١٠. التفاضل",
    phase11: "١١. التصوّر البياني",
    phase12: "١٢. النتائج والخلاصة",
  };

  function runPipeline(rows, income) {
    const prepared = phase1(rows);
    const records = prepared.records;
    const phases = { phase1: prepared.summary };

    const steps = [
      ["phase2", () => phase2(records)],
      ["phase3", () => phase3(records)],
      ["phase4", () => phase4(records, income)],
      ["phase5", () => phase5(records)],
      ["phase6", () => phase6(records)],
      ["phase7", () => phase7(records)],
      ["phase8", () => phase8(records, income ? income / 30 : 0)],
      ["phase9", () => phase9(records)],
      ["phase10", () => phase10(records, income)],
    ];

    steps.forEach(([key, run]) => {
      try {
        phases[key] = run();
      } catch (error) {
        phases[key] = { error: `المرحلة دي وقفت: ${error.message}` };
      }
    });

    phases.phase11 = phase11(records, phases);
    phases.phase12 = phase12(phases);

    return {
      generated_at: new Date().toISOString().slice(0, 10),
      rows: records.length,
      currency: CURRENCY,
      titles: TITLES,
      ...phases,
    };
  }

  /* بيقرأ ملف CSV نصّي لصفوف.
     lowerHeaders=true لبيانات المصاريف (بندوّر على date/category/amount)،
     وfalse للداتاست العامة عشان أسماء الأعمدة تفضل زي ما هي. */
  function parseCsv(text, lowerHeaders = true) {
    const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/).filter((line) => line.trim());
    if (!lines.length) return [];

    const headers = lines[0]
      .split(",")
      .map((head) => {
        const clean = head.trim().replace(/^\uFEFF/, "").replace(/^"|"$/g, "");
        return lowerHeaders ? clean.toLowerCase() : clean;
      });

    return lines.slice(1).map((line) => {
      /* بيحترم علامات التنصيص عشان الوصف اللي فيه فاصلة */
      const cells = [];
      let current = "";
      let quoted = false;

      for (const char of line) {
        if (char === '"') quoted = !quoted;
        else if (char === "," && !quoted) {
          cells.push(current);
          current = "";
        } else current += char;
      }
      cells.push(current);

      return Object.fromEntries(headers.map((head, index) => [head, (cells[index] || "").trim()]));
    });
  }

  /* الرياضيات بتتصدّر كمان عشان المحرك العام (generic-analysis.js)
     يستخدم نفس المعادلات بدل ما يكتبها تاني. */
  return {
    runPipeline,
    parseCsv,
    math: {
      sum, mean, round, fmt, signed, showP,
      quantile, sampleStd, moments, shapeLabel,
      confidenceInterval, tCritical, tTwoTailedP, fPValue,
      linearRegression, quadraticFit, toNumber,
    },
  };
})();
