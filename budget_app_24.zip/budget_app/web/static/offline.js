/* =========================================================
   offline.js — تشغيل الصفحة بالدبل كليك من غير سيرفر بايثون

   لما تفتح index.html مباشرة (file://) مفيش سيرفر يرد على /api/*،
   فالملف ده بيقوم بنفس دور بايثون جوه المتصفح: نفس المعادلات، نفس
   أسماء الحقول، ونفس الردود — عشان app.js ميحسّش بالفرق.

   لما تشغّل `python run_web.py` الملف ده بيقعد ساكت والسيرفر هو اللي
   بيشتغل (بايثون يفضل هو الأصل).
   ========================================================= */

(function () {
  "use strict";

  /* الصفحة تعتبر «بدون سيرفر» في حالتين:
       • مفتوحة كملف مباشرة (file://)
       • أو نسخة الملف الواحد المرفوعة على استضافة ثابتة زي GitHub Pages،
         وساعتها build_single_file.py بيحط window.FORCE_OFFLINE = true
     من غير الشرط التاني، الصفحة على GitHub بتحاول تنادي /api/... وترجع
     صفحة 404 بـ HTML، والكود بيحاول يقراها JSON فيقع. */
  const OFFLINE = location.protocol === "file:" || window.FORCE_OFFLINE === true;
  window.IS_OFFLINE = OFFLINE;
  if (!OFFLINE) return;

  const DATA = window.OFFLINE_DATA;
  const CATS = DATA.categories.map((item) => item.key);
  const LABELS = Object.fromEntries(DATA.categories.map((item) => [item.key, item.label]));

  /* =======================================================
     1) رياضيات التوزيعات — نفس اللي في stats_engine.py
     ======================================================= */

  /* تقريب erf (Abramowitz & Stegun 7.1.26) — مفيش erf جاهزة في JS */
  function erf(x) {
    const sign = x < 0 ? -1 : 1;
    x = Math.abs(x);
    const t = 1 / (1 + 0.3275911 * x);
    const y =
      1 -
      ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
        0.254829592) *
        t *
        Math.exp(-x * x);
    return sign * y;
  }

  /* lgamma بطريقة Lanczos — أساس بيتا وجاما */
  const LANCZOS = [
    676.5203681218851, -1259.1392167224028, 771.32342877765313,
    -176.61502916214059, 12.507343278686905, -0.13857109526572012,
    9.9843695780195716e-6, 1.5056327351493116e-7,
  ];

  function lgamma(x) {
    if (x < 0.5) {
      return Math.log(Math.PI / Math.sin(Math.PI * x)) - lgamma(1 - x);
    }
    x -= 1;
    let a = 0.99999999999980993;
    const t = x + 7.5;
    LANCZOS.forEach((value, index) => {
      a += value / (x + index + 1);
    });
    return 0.5 * Math.log(2 * Math.PI) + (x + 0.5) * Math.log(t) - t + Math.log(a);
  }

  const logComb = (n, k) => lgamma(n + 1) - lgamma(k + 1) - lgamma(n - k + 1);

  const M = {
    bernoulliPmf: (k, p) => (k === 1 ? p : k === 0 ? 1 - p : 0),

    binomialPmf(k, n, p) {
      if (k < 0 || k > n) return 0;
      if (p <= 0) return k === 0 ? 1 : 0;
      if (p >= 1) return k === n ? 1 : 0;
      return Math.exp(logComb(n, k) + k * Math.log(p) + (n - k) * Math.log(1 - p));
    },

    poissonPmf(k, lam) {
      if (lam <= 0 || k < 0) return 0;
      return Math.exp(-lam + k * Math.log(lam) - lgamma(k + 1));
    },

    geometricPmf(k, p) {
      if (k < 1 || p <= 0 || p > 1) return 0;
      return Math.pow(1 - p, k - 1) * p;
    },

    normalPdf(x, mu, sigma) {
      if (sigma <= 0) return 0;
      return (
        (1 / (sigma * Math.sqrt(2 * Math.PI))) *
        Math.exp(-0.5 * Math.pow((x - mu) / sigma, 2))
      );
    },

    normalCdf(x, mu = 0, sigma = 1) {
      if (sigma <= 0) return x >= mu ? 1 : 0;
      return 0.5 * (1 + erf((x - mu) / (sigma * Math.SQRT2)));
    },

    uniformPdf: (x, low, high) =>
      high <= low ? 0 : x >= low && x <= high ? 1 / (high - low) : 0,

    exponentialPdf: (x, rate) => (rate <= 0 || x < 0 ? 0 : rate * Math.exp(-rate * x)),

    exponentialCdf: (x, rate) => (rate <= 0 || x < 0 ? 0 : 1 - Math.exp(-rate * x)),

    betaPdf(x, a, b) {
      if (x <= 0 || x >= 1 || a <= 0 || b <= 0) return 0;
      const logBeta = lgamma(a) + lgamma(b) - lgamma(a + b);
      return Math.exp((a - 1) * Math.log(x) + (b - 1) * Math.log(1 - x) - logBeta);
    },

    gammaPdf(x, shape, scale) {
      if (x <= 0 || shape <= 0 || scale <= 0) return 0;
      return Math.exp(
        (shape - 1) * Math.log(x) - x / scale - lgamma(shape) - shape * Math.log(scale)
      );
    },
  };

  /* عيّنة من التوزيع الطبيعي (Box–Muller) — للمحاكاة */
  function randomNormal(mu, sigma) {
    let u = 0;
    let v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    return mu + sigma * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  /* الأرقام العربية والفارسية لازم تتقرا زي اللاتينية — نفس منطق بايثون */
  const ARABIC_DIGITS = {
    "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4", "٥": "5", "٦": "6", "٧": "7",
    "٨": "8", "٩": "9", "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4", "۵": "5",
    "۶": "6", "۷": "7", "۸": "8", "۹": "9", "٫": ".",
  };

  function toNumber(raw) {
    if (typeof raw === "number") return Number.isFinite(raw) ? raw : NaN;
    if (raw === null || raw === undefined) return NaN;

    const text = String(raw)
      .replace(/[٠-٩۰-۹٫]/g, (char) => ARABIC_DIGITS[char])
      .replace(/,/g, "")
      .trim();

    return text ? Number(text) : NaN;
  }

  const round = (value, digits = 2) => {
    const factor = Math.pow(10, digits);
    return Math.round(value * factor) / factor;
  };

  function describe(values) {
    const count = values.length;
    if (!count) return { count: 0, mean: 0, median: 0, std: 0, min: 0, max: 0 };

    const sorted = [...values].sort((a, b) => a - b);
    const mean = values.reduce((total, value) => total + value, 0) / count;
    const variance =
      count > 1
        ? values.reduce((total, value) => total + Math.pow(value - mean, 2), 0) / (count - 1)
        : 0;
    const middle = Math.floor(count / 2);

    return {
      count,
      mean,
      median: count % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2,
      std: Math.sqrt(variance),
      min: sorted[0],
      max: sorted[count - 1],
    };
  }

  function percentile(sorted, percent) {
    if (!sorted.length) return 0;
    const position = (sorted.length - 1) * (percent / 100);
    const low = Math.floor(position);
    const high = Math.ceil(position);
    if (low === high) return sorted[low];
    return sorted[low] + (sorted[high] - sorted[low]) * (position - low);
  }

  /* =======================================================
     2) حالة البرنامج (نفس دور BudgetManager)
     ======================================================= */
  const STORAGE_KEY = "budget_app_offline";

  const State = {
    income: 0,
    mode: DATA.default_mode,
    split: { ...DATA.split_modes[DATA.default_mode] },
    expenses: [],
    nextId: 1,
    month: new Date().toISOString().slice(0, 7),

    save() {
      try {
        localStorage.setItem(
          STORAGE_KEY,
          JSON.stringify({
            income: this.income,
            mode: this.mode,
            split: this.split,
            expenses: this.expenses,
            nextId: this.nextId,
            month: this.month,
          })
        );
      } catch (error) {
        /* بعض المتصفحات بتقفل التخزين على file:// — البرنامج بيكمل في الذاكرة */
      }
    },

    load() {
      try {
        const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
        if (saved && saved.month === this.month) Object.assign(this, saved);
      } catch (error) {
        /* بيانات قديمة أو تالفة — بنبدأ من الأول */
      }
    },
  };

  State.load();

  const allocation = () =>
    Object.fromEntries(CATS.map((name) => [name, round(State.income * State.split[name])]));

  const spentByCategory = () => {
    const totals = Object.fromEntries(CATS.map((name) => [name, 0]));
    State.expenses.forEach((expense) => {
      totals[expense.category] += expense.amount;
    });
    return Object.fromEntries(CATS.map((name) => [name, round(totals[name])]));
  };

  const totalSpent = () =>
    round(State.expenses.reduce((total, expense) => total + expense.amount, 0));

  const amountsOf = (category) =>
    State.expenses
      .filter((expense) => !category || expense.category === category)
      .map((expense) => expense.amount);

  function elapsedDays() {
    const today = new Date();
    const dates = new Set(State.expenses.map((expense) => expense.date));
    return Math.max(today.getDate(), dates.size, 1);
  }

  function daysInMonth() {
    const today = new Date();
    return new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
  }

  function statusOf(ratio) {
    if (ratio > 1) return "over";
    if (ratio >= DATA.warning_threshold) return "near";
    return "ok";
  }

  function buildState() {
    const plan = allocation();
    const spent = spentByCategory();

    const lines = CATS.map((name) => {
      const planned = plan[name];
      const used = spent[name];
      const ratio = planned > 0 ? round(used / planned, 4) : 0;
      return {
        key: name,
        label: LABELS[name],
        percent_of_income: Math.round(State.split[name] * 100),
        planned,
        spent: used,
        remaining: round(planned - used),
        ratio,
        status: statusOf(ratio),
      };
    });

    const warnings = lines
      .filter((line) => line.status !== "ok")
      .map((line) => ({
        category: line.key,
        level: line.status === "over" ? "danger" : "warning",
        message:
          line.status === "over"
            ? `عدّيت خطة ${line.label}: صرفت ${Math.round(line.spent)} والخطة ${Math.round(line.planned)}`
            : `قربت تخلّص ميزانية ${line.label} — استهلكت ${Math.round(line.ratio * 100)}٪`,
      }));

    return {
      month: State.month,
      income: State.income,
      mode: State.mode,
      currency: DATA.currency,
      lines,
      total_spent: totalSpent(),
      actual_savings: round(State.income - totalSpent()),
      planned_savings: plan.savings,
      on_plan: lines.every((line) => line.ratio <= 1),
      warnings,
      expenses_count: State.expenses.length,
      top_expenses: [...State.expenses]
        .sort((a, b) => b.amount - a.amount)
        .slice(0, 3)
        .map((expense) => ({
          description: expense.description || LABELS[expense.category],
          amount: expense.amount,
        })),
      expenses: [...State.expenses].reverse().map((expense) => ({
        id: expense.id,
        amount: expense.amount,
        category: expense.category,
        label: LABELS[expense.category],
        description: expense.description,
        date: expense.date,
      })),
      categories: DATA.categories,
      modes: Object.keys(DATA.split_modes),
    };
  }

  /* =======================================================
     3) التحليل الإحصائي
     ======================================================= */
  const MIN_SAMPLE = 5;
  const notEnough = (what, have, need) => ({
    unavailable: `البيانات مش كفاية لـ${what}: عندك ${have} والمطلوب ${need} على الأقل.`,
  });

  function anomalyReport() {
    const amounts = amountsOf();
    if (amounts.length < MIN_SAMPLE) return notEnough("كشف المصاريف الشاذة", amounts.length, MIN_SAMPLE);

    const stats = describe(amounts);
    const sigma = stats.std || 1e-9;

    const within = (sigmas) =>
      round(
        (amounts.filter((value) => Math.abs(value - stats.mean) <= sigmas * sigma).length /
          amounts.length) *
          100,
        1
      );

    const flagged = State.expenses
      .map((expense) => ({
        id: expense.id,
        amount: expense.amount,
        z: round((expense.amount - stats.mean) / sigma, 2),
        description: expense.description,
        label: LABELS[expense.category],
      }))
      .filter((item) => Math.abs(item.z) >= 2)
      .sort((a, b) => Math.abs(b.z) - Math.abs(a.z))
      .map((item) => ({
        ...item,
        message: `${item.description || item.label} بمبلغ ${Math.round(item.amount)} — ${
          item.z > 0 ? "أعلى" : "أقل"
        } من متوسطك بـ ${Math.abs(item.z)} انحراف`,
      }));

    return {
      stats: { mean: round(stats.mean), std: round(sigma), count: stats.count },
      normal_range: { low: round(stats.mean - 2 * sigma), high: round(stats.mean + 2 * sigma) },
      empirical_rule: {
        observed: { "1σ": within(1), "2σ": within(2), "3σ": within(3) },
        expected: { "1σ": 68, "2σ": 95, "3σ": 99.7 },
      },
      flagged,
    };
  }

  /* إجمالي المصروف لكل يوم عدّى من الشهر — واليوم اللي مصرفتش فيه = صفر.
     مهم جداً: لو حسبنا المتوسط على الأيام اللي فيها صرف بس، التوقّع بيطلع
     أضعاف الحقيقة. نفس منطق daily_totals في stats_engine.py */
  function dailyTotals() {
    const byDate = {};
    State.expenses.forEach((expense) => {
      byDate[expense.date] = (byDate[expense.date] || 0) + expense.amount;
    });

    const prefix = State.month;
    const passed = elapsedDays();
    const values = [];
    for (let day = 1; day <= passed; day += 1) {
      const key = `${prefix}-${String(day).padStart(2, "0")}`;
      values.push(round(byDate[key] || 0));
    }
    return values;
  }

  function forecast(simulations = 4000) {
    if (State.income <= 0) {
      return { unavailable: "حدد الدخل الشهري الأول عشان نقدر نتوقّع." };
    }

    const values = dailyTotals();
    if (values.length < 3) return notEnough("توقّع آخر الشهر", values.length, 3);

    const totalDays = daysInMonth();
    const passed = values.length;
    const remaining = Math.max(totalDays - passed, 0);
    const current = totalSpent();

    const stats = describe(values);
    const muDay = stats.mean;
    const sigmaDay = stats.std;

    /* (أ) مونت كارلو: بنعيد سحب أيام عشوائية من الأيام اللي عدّت (Bootstrap) */
    const projections = [];
    if (remaining === 0) {
      projections.push(current);
    } else {
      for (let run = 0; run < simulations; run += 1) {
        let future = 0;
        for (let day = 0; day < remaining; day += 1) {
          future += values[Math.floor(Math.random() * values.length)];
        }
        projections.push(current + future);
      }
    }

    const sorted = [...projections].sort((a, b) => a - b);
    const overIncome = projections.filter((value) => value > State.income).length;

    /* (ب) تقريب CLT: مجموع أيام كتير ≈ طبيعي بمتوسط n·μ وانحراف σ√n */
    const cltMean = current + remaining * muDay;
    const cltStd = sigmaDay * Math.sqrt(remaining);
    const cltRisk =
      cltStd > 0
        ? (1 - M.normalCdf(State.income, cltMean, cltStd)) * 100
        : (cltMean > State.income) * 100;

    return {
      days_passed: passed,
      days_remaining: remaining,
      days_total: totalDays,
      current_total: current,
      income: round(State.income),
      daily_mean: round(muDay),
      daily_std: round(sigmaDay),
      simulations: projections.length,
      expected_total: round(projections.reduce((a, b) => a + b, 0) / projections.length),
      p05: round(percentile(sorted, 5)),
      p50: round(percentile(sorted, 50)),
      p95: round(percentile(sorted, 95)),
      risk_over_income: round((overIncome / projections.length) * 100, 1),
      clt_mean: round(cltMean),
      clt_std: round(cltStd),
      clt_risk: round(cltRisk, 1),
      standard_error: passed ? round(sigmaDay / Math.sqrt(passed)) : 0,
      categories: categoryRisk(remaining),
    };
  }

  /* احتمال إن كل تصنيف يعدّي خطته لحد آخر الشهر */
  function categoryRisk(remaining) {
    const plan = allocation();
    const spent = spentByCategory();
    const passed = Math.max(elapsedDays(), 1);

    return CATS.map((name) => {
      const values = amountsOf(name);
      const planned = plan[name];
      const used = spent[name];
      let probability;

      if (used > planned) {
        probability = 100;
      } else if (!values.length || remaining === 0) {
        probability = 0;
      } else {
        const rate = values.length / passed;                 // مرات الصرف في اليوم
        const stats = describe(values);
        const expectedExtra = rate * remaining * stats.mean;
        const sigmaExtra = stats.std * Math.sqrt(Math.max(rate * remaining, 1e-9));
        probability =
          sigmaExtra > 0
            ? (1 - M.normalCdf(planned - used, expectedExtra, sigmaExtra)) * 100
            : (used + expectedExtra > planned) * 100;
      }

      return {
        key: name,
        label: LABELS[name],
        planned,
        spent: used,
        risk: round(Math.min(Math.max(probability, 0), 100), 1),
      };
    });
  }

  function spendingRhythm() {
    const count = State.expenses.length;
    if (count < MIN_SAMPLE) return notEnough("تحليل إيقاع الصرف", count, MIN_SAMPLE);

    const passed = elapsedDays();
    const lam = count / passed;

    return {
      expenses_count: count,
      days_passed: passed,
      lambda: round(lam),
      no_spend_day: round(M.poissonPmf(0, lam) * 100, 1),
      two_or_more: round((1 - M.poissonPmf(0, lam) - M.poissonPmf(1, lam)) * 100, 1),
      mean_gap_days: round(1 / lam),
      within_1_day: round(M.exponentialCdf(1, lam) * 100, 1),
      within_3_days: round(M.exponentialCdf(3, lam) * 100, 1),
    };
  }

  function commitmentReport() {
    /* الوضع الأوفلاين بيشتغل على الشهر الحالي بس، والتحليل ده محتاج تاريخ شهور */
    return {
      unavailable:
        "تحليل الالتزام محتاج أكتر من شهر متسجّل — شغّل نسخة بايثون (python run_web.py) عشان تحفظ شهورك.",
    };
  }

  function cltExperiment() {
    const amounts = amountsOf();
    if (amounts.length < MIN_SAMPLE) return notEnough("تجربة النهاية المركزية", amounts.length, MIN_SAMPLE);

    const stats = describe(amounts);
    const experiments = [2, 5, 10, 30].map((size) => {
      const means = [];
      for (let run = 0; run < 1200; run += 1) {
        let total = 0;
        for (let pick = 0; pick < size; pick += 1) {
          total += amounts[Math.floor(Math.random() * amounts.length)];
        }
        means.push(total / size);
      }
      const meanStats = describe(means);
      return {
        n: size,
        mean_of_means: round(meanStats.mean),
        observed_se: round(meanStats.std),
        theoretical_se: round(stats.std / Math.sqrt(size)),
      };
    });

    return {
      population: { mean: round(stats.mean), std: round(stats.std), count: stats.count },
      experiments,
    };
  }






  /* =======================================================
     5) الراوتر — نفس مسارات web/server.py
     ======================================================= */
  function requireIncome() {
    if (State.income <= 0) throw new Error("لازم تحدد الدخل الشهري الأول قبل ما تسجل مصاريف.");
  }

  function validate(amount, category) {
    const value = Number(amount);
    if (!Number.isFinite(value) || value <= 0) {
      throw new Error(`المبلغ غير صحيح: ${amount} — لازم يكون رقم أكبر من صفر`);
    }
    if (!CATS.includes(category)) {
      throw new Error(`تصنيف غير معروف: ${category}`);
    }
    return value;
  }

  const ROUTES = {
    "/api/state": () => buildState(),
    /* تحميل داتاست جاهزة (من ملف CSV) بدل التسجيل اليدوي.
       بتستخدمها صفحة التحليل المستقلة: ملف واحد + دخل = تحليل كامل. */
    "/api/load-rows": (payload) => {
      const rows = payload.rows || [];
      if (!rows.length) throw new Error("الملف فاضي أو مش متقري.");

      const income = Number(payload.income) || 0;
      if (income > 0) State.income = income;

      State.expenses = [];
      State.nextId = 1;
      let skipped = 0;

      rows.forEach((row) => {
        const day = String(row.date || row.day || "").trim();
        const category = String(row.category || "").trim().toLowerCase();
        const amount = toNumber(row.amount);

        if (!day || !CATS.includes(category) || !Number.isFinite(amount) || amount <= 0) {
          skipped += 1;
          return;
        }

        State.expenses.push({
          id: State.nextId++,
          amount: round(amount),
          category,
          description: String(row.description || "").trim().slice(0, 100),
          date: day,
        });
      });

      if (!State.expenses.length) {
        throw new Error("مفيش ولا صف صالح في الملف — اتأكد من الأعمدة: date, category, amount");
      }

      /* الشهر الحالي بيبقى آخر شهر في الداتا عشان التحليل يشتغل عليه */
      const months = [...new Set(State.expenses.map((e) => e.date.slice(0, 7)))].sort();
      State.month = months[months.length - 1];

      State.save();
      return { loaded: State.expenses.length, skipped, months, month: State.month };
    },

    "/api/analysis": (payload) => {
      /* الأوفلاين مش بيقدر يقرأ data/dataset.csv لوحده (المتصفح بيمنع
         قراءة الملفات من file://)، فالمستخدم بيرفع الملف بنفسه. */
      const rows = payload.rows && payload.rows.length
        ? payload.rows
        : State.expenses.map((expense) => ({
            date: expense.date,
            category: expense.category,
            amount: expense.amount,
            description: expense.description,
          }));

      if (payload.source === "dataset" && !(payload.rows && payload.rows.length)) {
        throw new Error(
          "في الوضع بدون سيرفر، دوس «ارفع CSV» واختار ملف data/dataset.csv من جهازك."
        );
      }

      const result = window.OfflineAnalysis.runPipeline(rows, State.income);
      result.source = payload.source || "app";
      return result;
    },


    "/api/income": (payload) => {
      const value = Number(payload.income);
      if (!Number.isFinite(value) || value <= 0) throw new Error("الدخل لازم يكون رقم أكبر من صفر");

      State.income = value;
      const mode = payload.mode || DATA.default_mode;

      if (DATA.split_modes[mode]) {
        State.mode = mode;
        State.split = { ...DATA.split_modes[mode] };
      } else if (payload.custom) {
        const total = CATS.reduce((sum, name) => sum + Number(payload.custom[name] || 0), 0);
        if (Math.round(total) !== 100 && Math.round(total * 100) !== 100) {
          throw new Error(`نسب التقسيم مجموعها ${total} والمفروض 100`);
        }
        const divisor = total > 1.5 ? 100 : 1;
        State.mode = "custom";
        State.split = Object.fromEntries(
          CATS.map((name) => [name, Number(payload.custom[name]) / divisor])
        );
      }

      State.save();
      return buildState();
    },

    "/api/expense": (payload) => {
      requireIncome();
      const amount = validate(payload.amount, payload.category);
      State.expenses.push({
        id: State.nextId,
        amount,
        category: payload.category,
        description: String(payload.description || "").trim().slice(0, 100),
        date: new Date().toISOString().slice(0, 10),
      });
      State.nextId += 1;
      State.save();
      return buildState();
    },

    "/api/expense/update": (payload) => {
      const expense = State.expenses.find((item) => item.id === Number(payload.id));
      if (!expense) throw new Error(`مفيش مصروف بالرقم ${payload.id}.`);

      const category = payload.category || expense.category;
      expense.amount = validate(
        payload.amount === undefined || payload.amount === null ? expense.amount : payload.amount,
        category
      );
      expense.category = category;
      if (payload.description !== undefined && payload.description !== null) {
        expense.description = String(payload.description).trim().slice(0, 100);
      }
      State.save();
      return buildState();
    },

    "/api/expense/delete": (payload) => {
      const index = State.expenses.findIndex((item) => item.id === Number(payload.id));
      if (index === -1) throw new Error(`مفيش مصروف بالرقم ${payload.id}.`);
      State.expenses.splice(index, 1);
      State.save();
      return buildState();
    },

    "/api/reset": () => {
      State.income = 0;
      State.expenses = [];
      State.nextId = 1;
      State.mode = DATA.default_mode;
      State.split = { ...DATA.split_modes[DATA.default_mode] };
      State.save();
      return buildState();
    },

    /* التصدير في الأوفلاين بينزّل الملف من المتصفح مباشرة */
    "/api/export": () => {
      const header = ["id", "date", "category", "amount", "description"];
      const rows = State.expenses.map((expense) => [
        expense.id,
        expense.date,
        expense.category,
        expense.amount.toFixed(2),
        `"${(expense.description || "").replace(/"/g, '""')}"`,
      ]);
      const csv = "\uFEFF" + [header, ...rows].map((row) => row.join(",")).join("\n");

      const link = document.createElement("a");
      link.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
      link.download = "expenses.csv";
      link.click();
      URL.revokeObjectURL(link.href);

      return buildState();
    },

    "/api/stats": () => ({
      month: State.month,
      generated_at: new Date().toLocaleString("en-GB").slice(0, 17),
      numpy: false,
      offline: true,
      forecast: forecast(),
      anomalies: anomalyReport(),
      rhythm: spendingRhythm(),
      commitment: commitmentReport(),
      clt: cltExperiment(),
      charts: {},
    }),

    "/api/check": (payload) => {
      const amounts = amountsOf(payload.category);
      const pool = amounts.length >= 3 ? amounts : amountsOf();
      if (pool.length < 3) throw new Error("سجّل 3 مصاريف على الأقل عشان نقدر نقيّم المبلغ.");

      const stats = describe(pool);
      const sigma = stats.std || 1e-9;
      const amount = Number(payload.amount);
      const z = round((amount - stats.mean) / sigma, 2);

      return {
        amount: round(amount),
        z,
        mean: round(stats.mean),
        std: round(sigma),
        percentile: round((pool.filter((value) => value <= amount).length / pool.length) * 100, 1),
        verdict:
          Math.abs(z) >= 3
            ? "شاذ جداً بالنسبة لمصاريفك"
            : Math.abs(z) >= 2
            ? "مبلغ شاذ — بره المدى الطبيعي"
            : Math.abs(z) >= 1
            ? "أعلى من المعتاد شوية بس مقبول"
            : "مبلغ طبيعي تماماً",
      };
    },

  };

  /* الواجهة اللي app.js بينادي عليها بدل fetch */
  window.OfflineAPI = {
    call(route, payload) {
      const handler = ROUTES[route];
      if (!handler) throw new Error(`المسار ${route} مش متاح في الوضع بدون سيرفر`);
      return handler(payload || {});
    },
  };

  /* شريط بيوضّح إن الصفحة شغالة من غير بايثون */
  document.addEventListener("DOMContentLoaded", () => {
    const banner = document.createElement("div");
    banner.className = "offline-banner";
    /* النص بيتغيّر حسب لغة الصفحة — views-en.js بيحط النسخة الإنجليزية */
    banner.innerHTML =
      window.OFFLINE_BANNER_TEXT ||
      "<b>وضع بدون سيرفر</b> — الصفحة شغالة بالكامل جوه المتصفح والبيانات محفوظة على جهازك. " +
        "لو عايز حفظ في ملفات JSON و CSV وتقارير الشهور، شغّل <code>python run_web.py</code>.";
    document.querySelector(".shell").prepend(banner);
  });
})();
