/* =========================================================
   offline-data.js — متولّد تلقائياً، متعدلوش بالإيد!
   المصدر: app/config.py
   لإعادة توليده:  python tools/build_offline_data.py
   ========================================================= */

window.OFFLINE_DATA = {
  "app_name": "توفير بذكاء",
  "currency": "جنيه",
  "categories": [
    {
      "key": "needs",
      "label": "احتياجات"
    },
    {
      "key": "wants",
      "label": "كماليات"
    },
    {
      "key": "savings",
      "label": "توفير"
    }
  ],
  "split_modes": {
    "50/30/20": {
      "needs": 0.5,
      "wants": 0.3,
      "savings": 0.2
    },
    "60/20/20": {
      "needs": 0.6,
      "wants": 0.2,
      "savings": 0.2
    }
  },
  "default_mode": "50/30/20",
  "warning_threshold": 0.8
};
