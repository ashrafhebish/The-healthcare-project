"""
web/server.py
-------------
سيرفر بسيط بمكتبات بايثون الأساسية بس (من غير Flask ولا أي تثبيت).
بيقدّم صفحة الويب + API بيكلّم نفس الـ BudgetManager بتاع الكونسول.

بيوضح: Modules, Functions, Type Hints, try/except/finally, JSON, Dictionaries
"""

import csv
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse

from app.analysis import PHASE_TITLES, run_pipeline, rows_from_manager
from app.budget_manager import BudgetManager
from app.charts import CHARTS_AVAILABLE, CHARTS_DIR, build_all_charts
from app.config import (
    DATA_DIR,
    APP_NAME,
    APP_TAGLINE,
    CATEGORIES,
    CATEGORY_LABELS,
    CURRENCY,
    CUSTOM_MODE,
    SPLIT_MODES,
    WEB_DIR,
    WEB_HOST,
    WEB_PORT,
)
from app.exceptions import BudgetError
from app.logger_setup import log
from app.reports import build_report
from app.stats_engine import (
    NUMPY_AVAILABLE,
    build_stats_report,
    expense_amounts,
    z_score_of,
)
from app.storage import export_expenses_csv, load_json, save_json

# مدير واحد للبرنامج كله (Object)
MANAGER: BudgetManager = BudgetManager()

MIME_TYPES: dict[str, str] = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
}


# ---------------------------------------------------------------
# منطق الـ API
# ---------------------------------------------------------------
def current_state() -> dict[str, Any]:
    """كل اللي الواجهة محتاجاه في رد واحد."""
    report: dict[str, Any] = build_report(MANAGER)
    report["expenses"] = [
        {
            "id": expense.expense_id,
            "amount": expense.amount,
            "category": expense.category,
            "label": expense.label(),
            "description": expense.description,
            "date": expense.created_at,
        }
        for expense in reversed(MANAGER.budget.expenses)  # List Comprehension
    ]
    report["categories"] = [
        {"key": name, "label": CATEGORY_LABELS[name]} for name in CATEGORIES
    ]
    report["modes"] = list(SPLIT_MODES.keys()) + [CUSTOM_MODE]
    report["app"] = {"name": APP_NAME, "tagline": APP_TAGLINE, "currency": CURRENCY}
    return report


def api_state(_payload: dict[str, Any]) -> dict[str, Any]:
    return current_state()


def api_set_income(payload: dict[str, Any]) -> dict[str, Any]:
    mode: str = str(payload.get("mode", "50/30/20"))
    custom: dict[str, float] | None = payload.get("custom")
    MANAGER.set_income(payload.get("income"), mode, custom)
    save_json(MANAGER.to_dict())
    return current_state()


def api_add_expense(payload: dict[str, Any]) -> dict[str, Any]:
    MANAGER.add_expense(
        payload.get("amount"),
        str(payload.get("category", "")),
        str(payload.get("description", "")),
    )
    save_json(MANAGER.to_dict())
    return current_state()


def api_update_expense(payload: dict[str, Any]) -> dict[str, Any]:
    MANAGER.update_expense(
        int(payload.get("id", 0)),
        payload.get("amount"),
        payload.get("category"),
        payload.get("description"),
    )
    save_json(MANAGER.to_dict())
    return current_state()


def api_delete_expense(payload: dict[str, Any]) -> dict[str, Any]:
    MANAGER.delete_expense(int(payload.get("id", 0)))
    save_json(MANAGER.to_dict())
    return current_state()


def api_reset(_payload: dict[str, Any]) -> dict[str, Any]:
    """إعادة تعيين الشهر الحالي بالكامل."""
    month: str = MANAGER.current_month
    from app.models import MonthlyBudget

    MANAGER.months[month] = MonthlyBudget(month)
    save_json(MANAGER.to_dict())
    log.warning("Month %s was reset", month)
    return current_state()


def api_export(_payload: dict[str, Any]) -> dict[str, Any]:
    path: Path = export_expenses_csv(MANAGER.budget.expenses)
    state: dict[str, Any] = current_state()
    state["message"] = f"اتصدّر ملف CSV: {path.name}"
    return state


def api_stats(payload: dict[str, Any]) -> dict[str, Any]:
    """
    التحليل الإحصائي الكامل + الرسومات.
    بيرجّع أسماء ملفات الرسومات، والمتصفح بيجيبها من /charts/<file>.png
    """
    MANAGER.require_income()
    stats: dict[str, Any] = build_stats_report(MANAGER)

    charts: dict[str, str] = {}
    if payload.get("charts", True) and CHARTS_AVAILABLE:
        charts = build_all_charts(stats, expense_amounts(MANAGER))

    # الرسومات مبنية على نفس البيانات، فمش محتاجين نبعت العيّنات الخام للمتصفح
    forecast = stats.get("forecast", {})
    if isinstance(forecast, dict):
        forecast.pop("samples", None)
    clt = stats.get("clt", {})
    if isinstance(clt, dict):
        clt.pop("population_sample", None)
        for experiment in clt.get("experiments", []):
            experiment.pop("means", None)

    stats["charts"] = charts
    stats["charts_available"] = CHARTS_AVAILABLE
    stats["numpy"] = NUMPY_AVAILABLE
    return stats


def api_check_expense(payload: dict[str, Any]) -> dict[str, Any]:
    """تقييم مبلغ قبل ما يتصرف: طبيعي ولا شاذ؟ (Z-Score)"""
    return z_score_of(
        MANAGER,
        float(payload.get("amount", 0) or 0),
        str(payload.get("category", "needs")),
    )








def api_analysis(payload: dict[str, Any]) -> dict[str, Any]:
    """
    التحليل الإحصائي الشامل — 12 مرحلة.

    مصدر البيانات: مصاريف البرنامج نفسه، أو ملف data/dataset.csv لو
    المستخدم طلب كده (عشان الداتاست التجريبية).
    """
    source = str(payload.get("source", "app"))
    uploaded = payload.get("rows")

    if uploaded:
        rows = list(uploaded)          # ملف رفعه المستخدم من المتصفح
    elif source == "dataset":
        rows = load_dataset_rows()
    else:
        rows = rows_from_manager(MANAGER)

    result = run_pipeline(
        rows,
        income=MANAGER.budget.income,
        claimed_mean=float(payload["claimed_mean"]) if payload.get("claimed_mean") else None,
    )
    result["source"] = source
    return result


def load_dataset_rows() -> list[dict[str, Any]]:
    """قراءة الداتاست الخام من data/dataset.csv."""
    path = DATA_DIR / "dataset.csv"
    if not path.exists():
        raise BudgetError(
            "ملف data/dataset.csv مش موجود — شغّل: python tools/make_dataset.py"
        )

    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


# Dictionary of functions: الراوت -> الدالة
ROUTES: dict[str, Callable[[dict[str, Any]], dict[str, Any]]] = {
    "/api/state": api_state,
    "/api/income": api_set_income,
    "/api/expense": api_add_expense,
    "/api/expense/update": api_update_expense,
    "/api/expense/delete": api_delete_expense,
    "/api/reset": api_reset,
    "/api/export": api_export,
    "/api/stats": api_stats,
    "/api/check": api_check_expense,
    "/api/analysis": api_analysis,
}


# ---------------------------------------------------------------
# الـ Handler
# ---------------------------------------------------------------
class BudgetRequestHandler(BaseHTTPRequestHandler):
    """بيستقبل طلبات المتصفح ويرد عليها."""

    server_version = "BudgetApp/1.0"

    # ---------- أدوات الرد ----------
    def send_json(self, data: dict[str, Any], status: int = 200) -> None:
        body: bytes = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, path: Path) -> None:
        try:
            body: bytes = path.read_bytes()          # pathlib + Reading Files
        except OSError:
            self.send_error(404, "File not found")
            return

        self.send_response(200)
        self.send_header("Content-Type", MIME_TYPES.get(path.suffix, "text/plain"))
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_payload(self) -> dict[str, Any]:
        length: int = int(self.headers.get("Content-Length", 0))
        if length <= 0:
            return {}
        raw: bytes = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError:
            return {}

    # ---------- GET ----------
    def do_GET(self) -> None:  # noqa: N802
        route: str = urlparse(self.path).path

        if route in ROUTES:
            self.handle_api(route, {})
            return

        if route == "/":
            self.send_file(WEB_DIR / "index.html")
            return

        # صور الرسومات البيانية (data/charts)
        if route.startswith("/charts/"):
            chart_path: Path = (CHARTS_DIR / route.split("/")[-1]).resolve()
            if chart_path.is_file() and str(chart_path).startswith(str(CHARTS_DIR.resolve())):
                self.send_file(chart_path)
            else:
                self.send_error(404, "Chart not found")
            return

        # ملفات static
        candidate: Path = (WEB_DIR / route.lstrip("/")).resolve()
        if candidate.is_file() and str(candidate).startswith(str(WEB_DIR.resolve())):
            self.send_file(candidate)
            return

        self.send_error(404, "Not found")

    # ---------- POST ----------
    def do_POST(self) -> None:  # noqa: N802
        route: str = urlparse(self.path).path
        if route not in ROUTES:
            self.send_error(404, "Unknown API route")
            return
        self.handle_api(route, self.read_payload())

    def handle_api(self, route: str, payload: dict[str, Any]) -> None:
        """try / except / finally حوالين كل نداء API."""
        try:
            result: dict[str, Any] = ROUTES[route](payload)
            self.send_json({"ok": True, "data": result})
        except BudgetError as error:
            # أخطاء البرنامج المخصصة بترجع للمستخدم برسالة مفهومة
            log.error("API error at %s: %s", route, error.message)
            self.send_json({"ok": False, "error": error.message}, status=400)
        except Exception as error:  # pragma: no cover
            log.exception("Unexpected API error at %s", route)
            self.send_json({"ok": False, "error": f"خطأ غير متوقع: {error}"}, status=500)
        finally:
            log.debug("Handled %s", route)

    def log_message(self, format: str, *args: Any) -> None:
        """بنوجّه لوج السيرفر لملف اللوج بدل الشاشة."""
        log.debug("HTTP %s", format % args)


def start_server(host: str = WEB_HOST, port: int = WEB_PORT) -> None:
    """بيشغّل السيرفر."""
    try:
        saved: dict[str, Any] = load_json()
        if saved:
            MANAGER.load_dict(saved)
    except BudgetError as error:
        log.error("Could not load data: %s", error.message)

    server = ThreadingHTTPServer((host, port), BudgetRequestHandler)
    url: str = f"http://{host}:{port}"

    print(f"\n  {APP_NAME} — شغّال على {url}")
    print("  اضغط Ctrl+C عشان توقف السيرفر.\n")
    log.info("Web server started on %s", url)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  تم إيقاف السيرفر. مع السلامة 👋")
    finally:
        server.server_close()
        save_json(MANAGER.to_dict())
        log.info("Web server stopped")
