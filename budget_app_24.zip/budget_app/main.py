"""
main.py
-------
نقطة تشغيل الواجهة النصية (الكونسول).

    python main.py
"""

import os
import sys

# لازم البرنامج يشتغل من جوه فولدر المشروع (جنب فولدر app و web)
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

if not os.path.isdir(os.path.join(_HERE, "app")):
    print("\n" + "=" * 60)
    print("  الملف ده مش في مكانه الصح.")
    print("  لازم يكون جنب فولدر (app) و (web).")
    print(f"  مكانه الحالي: {_HERE}")
    print()
    print("  الحل: فك ضغط budget_app.zip، ادخل جوه الفولدر")
    print("  اللي فيه main.py، وشغّل من هناك.")
    print("=" * 60 + "\n")
    input("اضغط Enter للخروج...")
    sys.exit(1)

from app.config import APP_NAME, APP_VERSION, Color, paint
from app.console_ui import run_console
from app.logger_setup import log


def main() -> None:
    """الدالة الرئيسية."""
    log.info("Starting %s v%s (console)", APP_NAME, APP_VERSION)
    try:
        run_console()
    except KeyboardInterrupt:
        print(paint("\n\n تم إنهاء البرنامج بـ Ctrl+C. مع السلامة 👋", Color.YELLOW))
        log.info("App interrupted by user")
    finally:
        log.info("App finished")
        if os.name == "nt":
            input("\nاضغط Enter للخروج...")


if __name__ == "__main__":
    main()
