# رفع المشروع على GitHub (بونص: Repository + Multiple Commits)

اعمل الكوميتات دي بالترتيب عشان تاريخ الريبو يبان طبيعي ومقسّم، مش كوميت واحد.

```bash
cd budget_app
git init
git branch -M main

# 1
git add .gitignore README.md requirements.txt
git commit -m "chore: project setup, README and gitignore"

# 2
git add app/config.py app/__init__.py
git commit -m "feat: app config, paths and console colors"

# 3
git add app/exceptions.py
git commit -m "feat: custom exception classes"

# 4
git add app/logger_setup.py
git commit -m "feat: file logging setup"

# 5
git add app/models.py
git commit -m "feat: Expense dataclass and MonthlyBudget model with pydantic validation"

# 6
git add app/budget_manager.py
git commit -m "feat: BudgetManager with 50/30/20 split, live comparison and warnings"

# 7
git add app/storage.py
git commit -m "feat: JSON persistence and CSV import/export"

# 8
git add app/reports.py
git commit -m "feat: monthly plan-vs-actual report"

# 9
git add app/console_ui.py main.py
git commit -m "feat: colored console menu"

# 10
git add web/ run_web.py open_web_windows.bat open_web_mac.command open_console_windows.bat
git commit -m "feat: web interface with stdlib http server"

# 11
git add COMMITS_GUIDE.md
git commit -m "docs: requirements coverage table and commit guide"

# 12
git add app/stats_engine.py
git commit -m "feat: probability distributions engine (normal, poisson, binomial, beta, gamma)"

# 13
git add app/charts.py
git commit -m "feat: optional matplotlib charts for the statistics report"

# 14
git add app/inference.py
git commit -m "feat: t and F distributions, ANOVA and regression without scipy"

# 15
git add app/analysis.py
git commit -m "feat: 12-phase statistical analysis pipeline"

# 16
git add tools/make_dataset.py
git commit -m "feat: dataset generator with deliberately dirty rows"

# 17
git add web/static/index.html web/static/app.js web/static/style.css
git commit -m "feat: 12-phase analysis section with SVG charts and CSV upload"

# 18
git add index.html tools/build_single_file.py web/static/offline.js web/static/offline-analysis.js web/static/offline-data.js tools/build_offline_data.py
git commit -m "feat: standalone single-file index.html, runs with no server"

# 19
git add tests/
git commit -m "test: 51 unit tests validated against statistical tables"

# 20
git add README.md
git commit -m "docs: document the analysis pipeline and offline mode"

git remote add origin https://github.com/USERNAME/budget-app.git
git push -u origin main
```

نصيحة: بعد كل feature جديدة تضيفها، اعمل كوميت لوحده برسالة واضحة بالإنجليزي.
